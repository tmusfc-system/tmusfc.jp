-- All In One WP Security & Firewall 4.4.9
-- MySQL dump
-- 2021-09-02 18:17:38

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp20210827044706_aiowps_events`;

CREATE TABLE `wp20210827044706_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_aiowps_failed_logins`;

CREATE TABLE `wp20210827044706_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_aiowps_global_meta`;

CREATE TABLE `wp20210827044706_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_aiowps_login_activity`;

CREATE TABLE `wp20210827044706_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `logout_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_aiowps_login_lockdown`;

CREATE TABLE `wp20210827044706_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_aiowps_permanent_block`;

CREATE TABLE `wp20210827044706_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_amelia_appointments`;

CREATE TABLE `wp20210827044706_amelia_appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('approved','pending','canceled','rejected') DEFAULT NULL,
  `bookingStart` datetime NOT NULL,
  `bookingEnd` datetime NOT NULL,
  `notifyParticipants` tinyint(1) NOT NULL,
  `serviceId` int(11) NOT NULL,
  `packageId` int(11) DEFAULT NULL,
  `providerId` int(11) NOT NULL,
  `locationId` int(11) DEFAULT NULL,
  `internalNotes` text,
  `googleCalendarEventId` varchar(255) DEFAULT NULL,
  `googleMeetUrl` varchar(255) DEFAULT NULL,
  `outlookCalendarEventId` varchar(255) DEFAULT NULL,
  `zoomMeeting` text,
  `parentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_cache`;

CREATE TABLE `wp20210827044706_amelia_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `paymentId` int(11) DEFAULT NULL,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_categories`;

CREATE TABLE `wp20210827044706_amelia_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('hidden','visible','disabled') NOT NULL DEFAULT 'visible',
  `name` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL,
  `translations` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `wp20210827044706_amelia_categories` VALUES("1","visible","大学祭　1日目(11月1日)","1","");
INSERT INTO `wp20210827044706_amelia_categories` VALUES("2","visible","大学祭　2日目(11月2日)","2","");
INSERT INTO `wp20210827044706_amelia_categories` VALUES("3","visible","大学祭　3日目(11月3日)","3","");
INSERT INTO `wp20210827044706_amelia_categories` VALUES("4","visible","大学祭　1日目（11月1日）","1","");
INSERT INTO `wp20210827044706_amelia_categories` VALUES("5","visible","大学祭　1日目（11月1日）","1","");
INSERT INTO `wp20210827044706_amelia_categories` VALUES("6","visible","新規カテゴリー","1","");


DROP TABLE IF EXISTS `wp20210827044706_amelia_coupons`;

CREATE TABLE `wp20210827044706_amelia_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `discount` double NOT NULL,
  `deduction` double NOT NULL,
  `limit` double NOT NULL,
  `customerLimit` double NOT NULL DEFAULT '0',
  `status` enum('hidden','visible') NOT NULL,
  `notificationInterval` int(11) NOT NULL DEFAULT '0',
  `notificationRecurring` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_coupons_to_events`;

CREATE TABLE `wp20210827044706_amelia_coupons_to_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `couponId` int(11) NOT NULL,
  `eventId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_coupons_to_services`;

CREATE TABLE `wp20210827044706_amelia_coupons_to_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `couponId` int(11) NOT NULL,
  `serviceId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_custom_fields`;

CREATE TABLE `wp20210827044706_amelia_custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` text NOT NULL,
  `type` enum('text','text-area','select','checkbox','radio','content','file','datepicker') NOT NULL DEFAULT 'text',
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `translations` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_custom_fields_events`;

CREATE TABLE `wp20210827044706_amelia_custom_fields_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customFieldId` int(11) NOT NULL,
  `eventId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_custom_fields_options`;

CREATE TABLE `wp20210827044706_amelia_custom_fields_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customFieldId` int(11) NOT NULL,
  `label` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL,
  `translations` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_custom_fields_services`;

CREATE TABLE `wp20210827044706_amelia_custom_fields_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customFieldId` int(11) NOT NULL,
  `serviceId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_customer_bookings`;

CREATE TABLE `wp20210827044706_amelia_customer_bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appointmentId` int(11) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `status` enum('approved','pending','canceled','rejected') DEFAULT NULL,
  `price` double NOT NULL,
  `persons` int(11) NOT NULL,
  `couponId` int(11) DEFAULT NULL,
  `token` varchar(10) DEFAULT NULL,
  `customFields` text,
  `info` text,
  `utcOffset` int(3) DEFAULT NULL,
  `aggregatedPrice` tinyint(1) DEFAULT '1',
  `packageCustomerServiceId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_customer_bookings_to_events_periods`;

CREATE TABLE `wp20210827044706_amelia_customer_bookings_to_events_periods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerBookingId` int(11) NOT NULL,
  `eventPeriodId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bookingEventPeriod` (`customerBookingId`,`eventPeriodId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_customer_bookings_to_extras`;

CREATE TABLE `wp20210827044706_amelia_customer_bookings_to_extras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerBookingId` int(11) NOT NULL,
  `extraId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `aggregatedPrice` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bookingExtra` (`customerBookingId`,`extraId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_events`;

CREATE TABLE `wp20210827044706_amelia_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `status` enum('approved','pending','canceled','rejected') NOT NULL,
  `bookingOpens` datetime DEFAULT NULL,
  `bookingCloses` datetime DEFAULT NULL,
  `bookingOpensRec` enum('same','calculate') DEFAULT 'same',
  `bookingClosesRec` enum('same','calculate') DEFAULT 'same',
  `recurringCycle` enum('daily','weekly','monthly','yearly') DEFAULT NULL,
  `recurringOrder` int(11) DEFAULT NULL,
  `recurringInterval` int(11) DEFAULT '1',
  `recurringMonthly` enum('each','on') DEFAULT 'each',
  `monthlyDate` datetime DEFAULT NULL,
  `monthlyOnRepeat` enum('first','second','third','fourth','last') DEFAULT NULL,
  `monthlyOnDay` enum('monday','tuesday','wednesday','thursday','friday','saturday','sunday') DEFAULT NULL,
  `recurringUntil` datetime DEFAULT NULL,
  `maxCapacity` int(11) NOT NULL,
  `price` double NOT NULL,
  `locationId` int(11) DEFAULT NULL,
  `customLocation` varchar(255) DEFAULT NULL,
  `description` text,
  `color` varchar(255) DEFAULT NULL,
  `show` tinyint(1) NOT NULL DEFAULT '1',
  `notifyParticipants` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `settings` text,
  `zoomUserId` varchar(255) DEFAULT NULL,
  `bringingAnyone` tinyint(1) DEFAULT '1',
  `bookMultipleTimes` tinyint(1) DEFAULT '1',
  `translations` text,
  `depositPayment` enum('disabled','fixed','percentage') DEFAULT 'disabled',
  `depositPerPerson` tinyint(1) DEFAULT '1',
  `deposit` double DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_events_periods`;

CREATE TABLE `wp20210827044706_amelia_events_periods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventId` int(11) NOT NULL,
  `periodStart` datetime NOT NULL,
  `periodEnd` datetime NOT NULL,
  `zoomMeeting` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_events_tags`;

CREATE TABLE `wp20210827044706_amelia_events_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_events_to_providers`;

CREATE TABLE `wp20210827044706_amelia_events_to_providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_extras`;

CREATE TABLE `wp20210827044706_amelia_extras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `price` double NOT NULL,
  `maxQuantity` int(11) NOT NULL,
  `duration` int(11) DEFAULT NULL,
  `serviceId` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `aggregatedPrice` tinyint(1) DEFAULT NULL,
  `translations` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_galleries`;

CREATE TABLE `wp20210827044706_amelia_galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entityId` int(11) NOT NULL,
  `entityType` enum('service','event','package') NOT NULL,
  `pictureFullPath` varchar(767) DEFAULT NULL,
  `pictureThumbPath` varchar(767) DEFAULT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_locations`;

CREATE TABLE `wp20210827044706_amelia_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('hidden','visible','disabled') NOT NULL DEFAULT 'visible',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `address` varchar(255) NOT NULL,
  `phone` varchar(63) NOT NULL,
  `latitude` decimal(8,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  `pictureFullPath` varchar(767) DEFAULT NULL,
  `pictureThumbPath` varchar(767) DEFAULT NULL,
  `pin` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_locations_views`;

CREATE TABLE `wp20210827044706_amelia_locations_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locationId` int(11) NOT NULL,
  `date` date NOT NULL,
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_notifications`;

CREATE TABLE `wp20210827044706_amelia_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `customName` varchar(255) DEFAULT NULL,
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'enabled',
  `type` enum('email','sms') NOT NULL,
  `entity` enum('appointment','event') NOT NULL DEFAULT 'appointment',
  `time` time DEFAULT NULL,
  `timeBefore` int(11) DEFAULT NULL,
  `timeAfter` int(11) DEFAULT NULL,
  `sendTo` enum('customer','provider') NOT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `translations` text,
  `sendOnlyMe` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

INSERT INTO `wp20210827044706_amelia_notifications` VALUES("1","customer_appointment_approved","","enabled","email","appointment","","","","customer","【重要】体験‼化学実験2021　ご予約確認メール","<p><strong>%customer_full_name%様</strong></p><p><br></p><p>この度は2021年度体験化学実験にご予約いただき誠にありがとうございます。</p><p><br></p><p>私たち%employee_full_name%入り口でのアルコール消毒や備品の消毒、こまめな手洗いなどを行い万全のコロナ対策を行い%employee_full_name%をお待ちしております。</p><p>%appointment_date%の%appointment_date_time%に心よりお待ちしております。</p><p><br></p><p>早速ですが、ご予約内容にお間違いがないかご確認おねがいします。</p><p>また、予約内容を修正したい場合は下記のURLより再度ご予約をお願いいたします。</p><p><br></p><p>予約修正：https://aaaaa.ne.jp/</p><p>＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿</p><p><br></p><p>代表者氏名　%customer_full_name%</p><p>実験体験日　%appointment_date%</p><p>体験時間帯　%appointment_date_time%</p><p>体験内容 %service_name%</p><p><br></p><p>______________________________________________________</p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("2","customer_appointment_pending","","disabled","email","appointment","","","","customer","%service_name% Appointment Pending","Dear <strong>%customer_full_name%</strong>,<br><br>The <strong>%service_name%</strong> appointment 
                     with <strong>%employee_full_name%</strong> at <strong>%location_address%</strong>, scheduled for
                     <strong>%appointment_date_time%</strong> is waiting for a confirmation.<br><br>Thank you for 
                     choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("3","customer_appointment_rejected","","enabled","email","appointment","","","","customer","%service_name% Appointment Rejected","Dear <strong>%customer_full_name%</strong>,<br><br>Your <strong>%service_name%</strong> 
                     appointment, scheduled on <strong>%appointment_date_time%</strong> at <strong>%location_address%
                     </strong>has been rejected.<br><br>Thank you for choosing our company,
                     <br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("4","customer_appointment_canceled","","enabled","email","appointment","","","","customer","%service_name% Appointment Canceled","Dear <strong>%customer_full_name%</strong>,<br><br>Your <strong>%service_name%</strong> 
                     appointment, scheduled on <strong>%appointment_date_time%</strong> at <strong>%location_address%
                     </strong>has been canceled.<br><br>Thank you for choosing our company,
                     <br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("5","customer_appointment_rescheduled","","enabled","email","appointment","","","","customer","%service_name% Appointment Rescheduled","Dear <strong>%customer_full_name%</strong>,<br><br>The details for your 
                     <strong>%service_name%</strong> appointment with <strong>%employee_full_name%</strong> at 
                     <strong>%location_name%</strong> has been changed. The appointment is now set for 
                     <strong>%appointment_date%</strong> at <strong>%appointment_start_time%</strong>.<br><br>
                     Thank you for choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("6","customer_appointment_next_day_reminder","","enabled","email","appointment","17:00:00","","","customer","%service_name% Appointment Reminder","Dear <strong>%customer_full_name%</strong>,<br><br>We would like to remind you that you have 
                     <strong>%service_name%</strong> appointment tomorrow at <strong>%appointment_start_time%</strong>.
                     We are waiting for you at <strong>%location_name%</strong>.<br><br>Thank you for 
                     choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("7","customer_appointment_follow_up","","enabled","email","appointment","","","1800","customer","%service_name% Appointment Follow Up","Dear <strong>%customer_full_name%</strong>,<br><br>Thank you once again for choosing our company. 
                     We hope you were satisfied with your <strong>%service_name%</strong>.<br><br>We look forward to 
                     seeing you again soon,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("8","customer_birthday_greeting","","enabled","email","appointment","17:00:00","","","customer","Happy Birthday","Dear <strong>%customer_full_name%</strong>,<br><br>Happy birthday!<br>We wish you all the best.
                    <br><br>Thank you for choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("9","provider_appointment_approved","","enabled","email","appointment","","","","provider","%service_name% Appointment Approved","Hi <strong>%employee_full_name%</strong>,<br><br>You have one confirmed 
                     <strong>%service_name%</strong> appointment at <strong>%location_name%</strong> on 
                     <strong>%appointment_date%</strong> at <strong>%appointment_start_time%</strong>. The appointment 
                     is added to your schedule.<br><br>Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("10","provider_appointment_pending","","enabled","email","appointment","","","","provider","%service_name% Appointment Pending","Hi <strong>%employee_full_name%</strong>,<br><br>You have new appointment 
                     in <strong>%service_name%</strong>. The appointment is waiting for a confirmation.<br><br>Thank 
                     you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("11","provider_appointment_rejected","","enabled","email","appointment","","","","provider","%service_name% Appointment Rejected","Hi <strong>%employee_full_name%</strong>,<br><br>Your <strong>%service_name%</strong> appointment 
                     at <strong>%location_name%</strong>, scheduled for <strong>%appointment_date%</strong> at  
                     <strong>%appointment_start_time%</strong> has been rejected.
                     <br><br>Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("12","provider_appointment_canceled","","enabled","email","appointment","","","","provider","%service_name% Appointment Canceled","Hi <strong>%employee_full_name%</strong>,<br><br>Your <strong>%service_name%</strong> appointment,
                     scheduled on <strong>%appointment_date%</strong>, at <strong>%location_name%</strong> has been 
                     canceled.<br><br>Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("13","provider_appointment_rescheduled","","enabled","email","appointment","","","","provider","%service_name% Appointment Rescheduled","Hi <strong>%employee_full_name%</strong>,<br><br>The details for your 
                     <strong>%service_name%</strong> appointment at <strong>%location_name%</strong> has been changed. 
                     The appointment is now set for <strong>%appointment_date%</strong> at 
                     <strong>%appointment_start_time%</strong>.<br><br>Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("14","provider_appointment_next_day_reminder","","enabled","email","appointment","17:00:00","","","provider","%service_name% Appointment Reminder","Dear <strong>%employee_full_name%</strong>,<br><br>We would like to remind you that you have 
                     <strong>%service_name%</strong> appointment tomorrow at <strong>%appointment_start_time%</strong>
                     at <strong>%location_name%</strong>.<br><br>Thank you, 
                     <br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("15","customer_appointment_approved","","enabled","sms","appointment","","","","customer","NULL","Dear %customer_full_name%,

You have successfully scheduled %service_name% appointment with %employee_full_name%. We are waiting for you at %location_address% on %appointment_date_time%.

Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("16","customer_appointment_pending","","enabled","sms","appointment","","","","customer","NULL","Dear %customer_full_name%, 
                    
The %service_name% appointment with %employee_full_name% at %location_address%, scheduled for %appointment_date_time% is waiting for a confirmation.
                    
Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("17","customer_appointment_rejected","","enabled","sms","appointment","","","","customer","NULL","Dear %customer_full_name%,
                    
Your %service_name% appointment, scheduled on %appointment_date_time% at %location_address% has been rejected.
                    
Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("18","customer_appointment_canceled","","enabled","sms","appointment","","","","customer","NULL","Dear %customer_full_name%,
                    
Your %service_name% appointment, scheduled on %appointment_date_time% at %location_address% has been canceled. 
                    
Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("19","customer_appointment_rescheduled","","enabled","sms","appointment","","","","customer","NULL","Dear %customer_full_name%,
                    
The details for your %service_name% appointment with %employee_full_name% at %location_name% has been changed. The appointment is now set for %appointment_date% at %appointment_start_time%.
                    
Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("20","customer_appointment_next_day_reminder","","enabled","sms","appointment","17:00:00","","","customer","NULL","Dear %customer_full_name%,
                    
We would like to remind you that you have %service_name% appointment tomorrow at %appointment_start_time%. We are waiting for you at %location_name%.
                    
Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("21","customer_appointment_follow_up","","enabled","sms","appointment","","","1800","customer","NULL","Dear %customer_full_name%,
                    
Thank you once again for choosing our company. We hope you were satisfied with your %service_name%.
                     
We look forward to seeing you again soon,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("22","customer_birthday_greeting","","enabled","sms","appointment","17:00:00","","","customer","NULL","Dear %customer_full_name%,
                    
Happy birthday! We wish you all the best. 
                    
Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("23","provider_appointment_approved","","enabled","sms","appointment","","","","provider","NULL","Hi %employee_full_name%,
                    
You have one confirmed %service_name% appointment at %location_name% on %appointment_date% at %appointment_start_time%. The appointment is added to your schedule.
                    
Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("24","provider_appointment_pending","","enabled","sms","appointment","","","","provider","NULL","Hi %employee_full_name%,
                    
You have new appointment in %service_name%. The appointment is waiting for a confirmation.
                    
Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("25","provider_appointment_rejected","","enabled","sms","appointment","","","","provider","NULL","Hi %employee_full_name%,
                    
Your %service_name% appointment at %location_name%, scheduled for %appointment_date% at %appointment_start_time% has been rejected. 
                    
Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("26","provider_appointment_canceled","","enabled","sms","appointment","","","","provider","NULL","Hi %employee_full_name%,
                    
Your %service_name% appointment, scheduled on %appointment_date%, at %location_name% has been canceled.
                    
Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("27","provider_appointment_rescheduled","","enabled","sms","appointment","","","","provider","NULL","Hi %employee_full_name%,
                    
The details for your %service_name% appointment at %location_name% has been changed. The appointment is now set for %appointment_date% at %appointment_start_time%.
                    
Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("28","provider_appointment_next_day_reminder","","enabled","sms","appointment","17:00:00","","","provider","NULL","Dear %employee_full_name%, 
                    
We would like to remind you that you have %service_name% appointment tomorrow at %appointment_start_time% at %location_name%.
                    
Thank you, 
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("29","customer_event_approved","","enabled","email","event","","","","customer","%event_name% Event Booked","Dear <strong>%customer_full_name%</strong>,<br><br>You have successfully scheduled
                     <strong>%event_name%</strong> event. We are
                     waiting you at <strong>%event_location% </strong>on <strong>%event_start_date_time%</strong>.
                     <br><br>Thank you for choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("30","customer_event_rejected","","enabled","email","event","","","","customer","%event_name% Event Canceled By Admin","Dear <strong>%customer_full_name%</strong>,<br><br>Your <strong>%event_name%</strong>
                     event, scheduled on <strong>%event_start_date_time%</strong> at <strong>%event_location%
                     </strong>has been canceled.<br><br>Thank you for choosing our company,
                     <br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("31","customer_event_canceled","","enabled","email","event","","","","customer","%event_name% Event Canceled By Attendee","Dear <strong>%customer_full_name%</strong>,<br><br>Your <strong>%event_name%</strong>
                     event, scheduled on <strong>%event_start_date_time%</strong> at <strong>%event_location%
                     </strong>has been canceled.<br><br>Thank you for choosing our company,
                     <br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("32","customer_event_rescheduled","","enabled","email","event","","","","customer","%event_name% Event Rescheduled","Dear <strong>%customer_full_name%</strong>,<br><br>The details for your
                     <strong>%event_name%</strong> event at
                     <strong>%event_location%</strong> has been changed. The event is now set for
                     <strong>%event_start_date_time%</strong>.<br><br>
                     Thank you for choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("33","customer_event_next_day_reminder","","enabled","email","event","17:00:00","","","customer","%event_name% Event Reminder","Dear <strong>%customer_full_name%</strong>,<br><br>We would like to remind you that you have
                     <strong>%event_name%</strong> event tomorrow at <strong>%event_start_date_time%</strong>.
                     We are waiting for you at <strong>%event_location%</strong>.<br><br>Thank you for
                     choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("34","customer_event_follow_up","","enabled","email","event","","","1800","customer","%event_name% Event Follow Up","Dear <strong>%customer_full_name%</strong>,<br><br>Thank you once again for choosing our company.
                     We hope you were satisfied with your <strong>%event_name%</strong>.<br><br>We look forward to
                     seeing you again soon,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("35","provider_event_approved","","enabled","email","event","","","","provider","%event_name% Event Booked","Hi <strong>%employee_full_name%</strong>,<br><br>You have one confirmed
                     <strong>%event_name%</strong> Event at <strong>%event_location%</strong> on
                     <strong>%event_start_date_time%</strong>. The event
                     is added to your schedule.<br><br>Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("36","provider_event_rejected","","enabled","email","event","","","","provider","%event_name% Event Canceled By Admin","Hi <strong>%employee_full_name%</strong>,<br><br>Your <strong>%event_name%</strong> event
                     at <strong>%event_location%</strong>, scheduled for <strong>%event_start_date_time%</strong>
                     has been canceled.<br><br>Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("37","provider_event_canceled","","enabled","email","event","","","","provider","%event_name% Event Canceled By Customer","Hi <strong>%employee_full_name%</strong>,<br><br>Your <strong>%event_name%</strong> event,
                     scheduled on <strong>%event_start_date_time%</strong>, at <strong>%event_location%</strong> has been
                     canceled.<br><br>Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("38","provider_event_rescheduled","","enabled","email","event","","","","provider","%event_name% Event Rescheduled","Hi <strong>%employee_full_name%</strong>,<br><br>The details for your
                     <strong>%event_name%</strong> event at <strong>%event_location%</strong> has been changed.
                     The event is now set for <strong>%event_start_date_time%</strong>.
                     <br><br>Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("39","provider_event_next_day_reminder","","enabled","email","event","17:00:00","","","provider","%event_name% Event Reminder","Dear <strong>%employee_full_name%</strong>,<br><br>We would like to remind you that you have 
                     <strong>%event_name%</strong> event at <strong>%event_start_date_time%</strong>
                     at <strong>%event_location%</strong>.<br><br>Thank you, 
                     <br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("40","customer_event_approved","","enabled","sms","event","","","","customer","NULL","Dear %customer_full_name%,

You have successfully scheduled %event_name% event. We are waiting for you at %event_location% on %event_start_date_time%.

Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("41","customer_event_rejected","","enabled","sms","event","","","","customer","NULL","Dear %customer_full_name%,

Your %event_name% event, scheduled on %event_start_date_time% at %event_location% has been cancelled.

Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("42","customer_event_canceled","","enabled","sms","event","","","","customer","NULL","Dear %customer_full_name%,

Your %event_name% event, scheduled on %event_start_date_time% at %event_location% has been cancelled.

Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("43","customer_event_rescheduled","","enabled","sms","event","","","","customer","NULL","Dear %customer_full_name%,

The details for your %event_name% event at %event_location% has been changed. The event is now set for %event_start_date_time%.

Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("44","customer_event_next_day_reminder","","enabled","sms","event","17:00:00","","","customer","NULL","Dear %customer_full_name%,
                    
We would like to remind you that you have %event_name% event at %event_start_date_time%. We are waiting for you at %event_location%.
                    
Thank you for choosing our company,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("45","customer_event_follow_up","","enabled","sms","event","","","1800","customer","NULL","Dear %customer_full_name%,
                    
Thank you once again for choosing our company. We hope you were satisfied with your %event_name%.
                     
We look forward to seeing you again soon,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("46","provider_event_approved","","enabled","sms","event","","","","provider","NULL","Hi %employee_full_name%,

You have one confirmed %event_name% event at %event_location% on %event_start_date_time%. The event is added to your schedule.

Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("47","provider_event_rejected","","enabled","sms","event","","","","provider","NULL","Hi %employee_full_name%,

Your %event_name% event at %event_location%, scheduled for %event_start_date_time% has been canceled by admin.

Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("48","provider_event_canceled","","enabled","sms","event","","","","provider","NULL","Hi %employee_full_name%,

Your %event_name% event, scheduled on %event_start_date_time%, at %event_location% has been canceled.

Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("49","provider_event_rescheduled","","enabled","sms","event","","","","provider","NULL","Hi %employee_full_name%,

The details for your %event_name% event at %event_location% has been changed. The event is now set for %event_start_date_time%.

Thank you,
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("50","provider_event_next_day_reminder","","enabled","sms","event","17:00:00","","","provider","NULL","Dear %employee_full_name%, 
                    
We would like to remind you that you have %event_name% event at %event_start_date_time% at %event_location%.
                    
Thank you, 
%company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("51","customer_account_recovery","","enabled","email","appointment","","","","customer","Customer Panel Access","Dear <strong>%customer_full_name%</strong>,<br><br>You can access your profile on this <b><a href=\"%customer_panel_url%\">link</a></b>.
                    <br><br>Thank you for choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("52","provider_panel_access","","enabled","email","appointment","","","","provider","Employee Panel Access","Dear <strong>%employee_full_name%</strong>,<br><br>You can access your profile and track your bookings on this <b><a href=\"%employee_panel_url%\">link</a></b>.<br><br>Your login credentials:<br>Email: <b>%employee_email%</b><br>Password: <b>%employee_password%</b>
                    <br><br>Best regards,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("53","customer_package_purchased","","enabled","email","appointment","","","","customer","Package %package_name% purchased","Dear <strong>%customer_full_name%</strong>,<br><br>You have successfully purchased
                     <strong>%package_name%</strong>.
                     <br><br>Thank you for choosing our company,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("54","customer_package_purchased","","enabled","sms","appointment","","","","customer","Package %package_name% purchased","Dear %customer_full_name%,

You have successfully purchased %package_name%.

Thank you for choosing our company, %company_name%","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("55","provider_package_purchased","","enabled","email","appointment","","","","provider","Package %package_name% purchased","Hi <strong>%employee_full_name%</strong>,<br><br>
                     Customer %customer_full_name% has purchased <strong>%package_name%</strong> package.<br><br>
                     Thank you,<br><strong>%company_name%</strong>","","0");
INSERT INTO `wp20210827044706_amelia_notifications` VALUES("56","provider_package_purchased","","enabled","sms","appointment","","","","provider","Package %package_name% purchased","Hi %employee_full_name%,

Customer %customer_full_name% has purchased %package_name% package.
                     
Thank you, %company_name%","","0");


DROP TABLE IF EXISTS `wp20210827044706_amelia_notifications_log`;

CREATE TABLE `wp20210827044706_amelia_notifications_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `appointmentId` int(11) DEFAULT NULL,
  `eventId` int(11) DEFAULT NULL,
  `sentDateTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_notifications_sms_history`;

CREATE TABLE `wp20210827044706_amelia_notifications_sms_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationId` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `appointmentId` int(11) DEFAULT NULL,
  `eventId` int(11) DEFAULT NULL,
  `logId` int(11) DEFAULT NULL,
  `dateTime` datetime DEFAULT NULL,
  `text` varchar(1600) NOT NULL,
  `phone` varchar(63) NOT NULL,
  `alphaSenderId` varchar(11) NOT NULL,
  `status` enum('prepared','accepted','queued','sent','failed','delivered','undelivered') NOT NULL DEFAULT 'prepared',
  `price` double DEFAULT NULL,
  `segments` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_notifications_to_entities`;

CREATE TABLE `wp20210827044706_amelia_notifications_to_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationId` int(11) NOT NULL,
  `entityId` int(11) NOT NULL,
  `entity` enum('appointment','event') NOT NULL DEFAULT 'appointment',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_packages`;

CREATE TABLE `wp20210827044706_amelia_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `color` varchar(255) NOT NULL DEFAULT '',
  `price` double NOT NULL,
  `status` enum('hidden','visible','disabled') NOT NULL DEFAULT 'visible',
  `pictureFullPath` varchar(767) DEFAULT NULL,
  `pictureThumbPath` varchar(767) DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  `calculatedPrice` tinyint(1) DEFAULT '1',
  `discount` double NOT NULL,
  `endDate` datetime DEFAULT NULL,
  `durationType` enum('day','week','month') DEFAULT NULL,
  `durationCount` int(4) DEFAULT NULL,
  `settings` text,
  `translations` text,
  `depositPayment` enum('disabled','fixed','percentage') DEFAULT 'disabled',
  `deposit` double DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_packages_customers_to_services`;

CREATE TABLE `wp20210827044706_amelia_packages_customers_to_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packageCustomerId` int(11) NOT NULL,
  `serviceId` int(11) NOT NULL,
  `providerId` int(11) DEFAULT NULL,
  `locationId` int(11) DEFAULT NULL,
  `bookingsCount` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_packages_services_to_locations`;

CREATE TABLE `wp20210827044706_amelia_packages_services_to_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packageServiceId` int(11) NOT NULL,
  `locationId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_packages_services_to_providers`;

CREATE TABLE `wp20210827044706_amelia_packages_services_to_providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packageServiceId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_packages_to_customers`;

CREATE TABLE `wp20210827044706_amelia_packages_to_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packageId` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `price` double NOT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `purchased` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_packages_to_services`;

CREATE TABLE `wp20210827044706_amelia_packages_to_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serviceId` int(11) NOT NULL,
  `packageId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `minimumScheduled` int(5) DEFAULT '1',
  `maximumScheduled` int(5) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_payments`;

CREATE TABLE `wp20210827044706_amelia_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerBookingId` int(11) DEFAULT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `dateTime` datetime DEFAULT NULL,
  `status` enum('paid','pending','partiallyPaid') NOT NULL,
  `gateway` enum('onSite','payPal','stripe','wc','mollie') NOT NULL,
  `gatewayTitle` varchar(255) DEFAULT NULL,
  `data` text,
  `packageCustomerId` int(11) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_daysoff`;

CREATE TABLE `wp20210827044706_amelia_providers_to_daysoff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `repeat` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_events`;

CREATE TABLE `wp20210827044706_amelia_providers_to_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `eventId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_google_calendar`;

CREATE TABLE `wp20210827044706_amelia_providers_to_google_calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` text NOT NULL,
  `calendarId` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_locations`;

CREATE TABLE `wp20210827044706_amelia_providers_to_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `locationId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_outlook_calendar`;

CREATE TABLE `wp20210827044706_amelia_providers_to_outlook_calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` text NOT NULL,
  `calendarId` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_periods`;

CREATE TABLE `wp20210827044706_amelia_providers_to_periods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weekDayId` int(11) NOT NULL,
  `locationId` int(11) DEFAULT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_periods_services`;

CREATE TABLE `wp20210827044706_amelia_providers_to_periods_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `periodId` int(11) NOT NULL,
  `serviceId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_services`;

CREATE TABLE `wp20210827044706_amelia_providers_to_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `serviceId` int(11) NOT NULL,
  `price` double NOT NULL,
  `minCapacity` int(11) NOT NULL,
  `maxCapacity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `wp20210827044706_amelia_providers_to_services` VALUES("1","1","1","0","1","1");
INSERT INTO `wp20210827044706_amelia_providers_to_services` VALUES("2","1","2","0","1","1");
INSERT INTO `wp20210827044706_amelia_providers_to_services` VALUES("3","1","3","0","1","1");
INSERT INTO `wp20210827044706_amelia_providers_to_services` VALUES("4","1","4","0","1","1");


DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_specialdays`;

CREATE TABLE `wp20210827044706_amelia_providers_to_specialdays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_specialdays_periods`;

CREATE TABLE `wp20210827044706_amelia_providers_to_specialdays_periods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `specialDayId` int(11) NOT NULL,
  `locationId` int(11) DEFAULT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_timeouts`;

CREATE TABLE `wp20210827044706_amelia_providers_to_timeouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weekDayId` int(11) NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_to_weekdays`;

CREATE TABLE `wp20210827044706_amelia_providers_to_weekdays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `dayIndex` tinyint(2) NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `wp20210827044706_amelia_providers_to_weekdays` VALUES("1","1","1","09:00:00","17:00:00");
INSERT INTO `wp20210827044706_amelia_providers_to_weekdays` VALUES("2","1","2","09:00:00","17:00:00");
INSERT INTO `wp20210827044706_amelia_providers_to_weekdays` VALUES("3","1","3","09:00:00","17:00:00");
INSERT INTO `wp20210827044706_amelia_providers_to_weekdays` VALUES("4","1","4","09:00:00","17:00:00");
INSERT INTO `wp20210827044706_amelia_providers_to_weekdays` VALUES("5","1","5","09:00:00","17:00:00");


DROP TABLE IF EXISTS `wp20210827044706_amelia_providers_views`;

CREATE TABLE `wp20210827044706_amelia_providers_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `date` date NOT NULL,
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_services`;

CREATE TABLE `wp20210827044706_amelia_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `color` varchar(255) NOT NULL DEFAULT '',
  `price` double NOT NULL,
  `status` enum('hidden','visible','disabled') NOT NULL DEFAULT 'visible',
  `categoryId` int(11) NOT NULL,
  `minCapacity` int(11) NOT NULL,
  `maxCapacity` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `timeBefore` int(11) DEFAULT '0',
  `timeAfter` int(11) DEFAULT '0',
  `bringingAnyone` tinyint(1) DEFAULT '1',
  `priority` enum('least_expensive','most_expensive','least_occupied','most_occupied') NOT NULL,
  `pictureFullPath` varchar(767) DEFAULT NULL,
  `pictureThumbPath` varchar(767) DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  `show` tinyint(1) DEFAULT '1',
  `aggregatedPrice` tinyint(1) DEFAULT '1',
  `settings` text,
  `recurringCycle` enum('disabled','all','daily','weekly','monthly') DEFAULT 'disabled',
  `recurringSub` enum('disabled','past','future','both') DEFAULT 'future',
  `recurringPayment` int(3) DEFAULT '0',
  `translations` text,
  `depositPayment` enum('disabled','fixed','percentage') DEFAULT 'disabled',
  `depositPerPerson` tinyint(1) DEFAULT '1',
  `deposit` double DEFAULT '0',
  `mandatoryExtra` tinyint(1) DEFAULT '0',
  `minSelectedExtras` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `wp20210827044706_amelia_services` VALUES("1","ビスマス","","#1788FB","0","visible","1","1","1","1800","","","1","least_expensive","http://tmusfc.jp/wp-content/uploads/2021/09/P6223651-1-scaled.jpg","http://tmusfc.jp/wp-content/uploads/2021/09/P6223651-1-150x150.jpg","3","1","1","","disabled","future","0","","disabled","1","0","0","");
INSERT INTO `wp20210827044706_amelia_services` VALUES("2","葉脈標本","","#1788FB","0","visible","1","1","1","1800","","","1","least_expensive","http://tmusfc.jp/wp-content/uploads/2021/09/P6223702-2-1.jpg","http://tmusfc.jp/wp-content/uploads/2021/09/P6223702-2-1-150x150.jpg","2","1","1","","disabled","future","0","","disabled","1","0","0","");
INSERT INTO `wp20210827044706_amelia_services` VALUES("3","電気でお絵かき","","#1788FB","0","visible","1","1","1","1800","","","1","least_expensive","http://tmusfc.jp/wp-content/uploads/2021/09/P6223658-1.jpg","http://tmusfc.jp/wp-content/uploads/2021/09/P6223658-1-150x150.jpg","1","1","1","","disabled","future","0","","disabled","1","0","0","");
INSERT INTO `wp20210827044706_amelia_services` VALUES("4","ケミカルライト","","#1788FB","0","visible","1","1","1","1800","","","1","least_expensive","http://tmusfc.jp/wp-content/uploads/2021/09/P8054173.jpg","http://tmusfc.jp/wp-content/uploads/2021/09/P8054173-150x150.jpg","4","1","1","","disabled","future","0","","disabled","1","0","0","");


DROP TABLE IF EXISTS `wp20210827044706_amelia_services_views`;

CREATE TABLE `wp20210827044706_amelia_services_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serviceId` int(11) NOT NULL,
  `date` date NOT NULL,
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp20210827044706_amelia_users`;

CREATE TABLE `wp20210827044706_amelia_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('hidden','visible','disabled') NOT NULL DEFAULT 'visible',
  `type` enum('customer','provider','manager','admin') NOT NULL,
  `externalId` int(11) DEFAULT NULL,
  `firstName` varchar(255) NOT NULL DEFAULT '',
  `lastName` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `phone` varchar(63) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `note` text,
  `pictureFullPath` varchar(767) DEFAULT NULL,
  `pictureThumbPath` varchar(767) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `usedTokens` text,
  `zoomUserId` varchar(255) DEFAULT NULL,
  `countryPhoneIso` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `wp20210827044706_amelia_users` VALUES("1","visible","provider","","tmu-sfc","tmu-sfc","tmusfc@gmail.com","","","","","","","","","","");


DROP TABLE IF EXISTS `wp20210827044706_commentmeta`;

CREATE TABLE `wp20210827044706_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_comments`;

CREATE TABLE `wp20210827044706_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_comments` VALUES("1","1","WordPress コメントの投稿者","wapuu@wordpress.example","https://wordpress.org/","","2021-08-27 05:14:11","2021-08-26 20:14:11","こんにちは、これはコメントです。
コメントの承認、編集、削除を始めるにはダッシュボードの「コメント画面」にアクセスしてください。
コメントのアバターは「<a href=\"https://gravatar.com\">Gravatar</a>」から取得されます。","0","1","","comment","0","0");


DROP TABLE IF EXISTS `wp20210827044706_links`;

CREATE TABLE `wp20210827044706_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_options`;

CREATE TABLE `wp20210827044706_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=397 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_options` VALUES("1","siteurl","http://tmusfc.jp","yes");
INSERT INTO `wp20210827044706_options` VALUES("2","home","http://tmusfc.jp","yes");
INSERT INTO `wp20210827044706_options` VALUES("3","blogname","東京都立大学 化学実験サークル TMU-SFC","yes");
INSERT INTO `wp20210827044706_options` VALUES("4","blogdescription","より多くの人に化学の面白さを","yes");
INSERT INTO `wp20210827044706_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("6","admin_email","tmusfc@gmail.com","yes");
INSERT INTO `wp20210827044706_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp20210827044706_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp20210827044706_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp20210827044706_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp20210827044706_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp20210827044706_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp20210827044706_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp20210827044706_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp20210827044706_options` VALUES("23","date_format","Y年n月j日","yes");
INSERT INTO `wp20210827044706_options` VALUES("24","time_format","g:i A","yes");
INSERT INTO `wp20210827044706_options` VALUES("25","links_updated_date_format","Y年n月j日 g:i A","yes");
INSERT INTO `wp20210827044706_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp20210827044706_options` VALUES("29","rewrite_rules","a:119:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:16:\"custom-css-js/?$\";s:33:\"index.php?post_type=custom-css-js\";s:46:\"custom-css-js/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_type=custom-css-js&feed=$matches[1]\";s:41:\"custom-css-js/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_type=custom-css-js&feed=$matches[1]\";s:33:\"custom-css-js/page/([0-9]{1,})/?$\";s:51:\"index.php?post_type=custom-css-js&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:41:\"custom-css-js/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:51:\"custom-css-js/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:71:\"custom-css-js/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"custom-css-js/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"custom-css-js/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:47:\"custom-css-js/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:30:\"custom-css-js/([^/]+)/embed/?$\";s:61:\"index.php?post_type=custom-css-js&name=$matches[1]&embed=true\";s:34:\"custom-css-js/([^/]+)/trackback/?$\";s:55:\"index.php?post_type=custom-css-js&name=$matches[1]&tb=1\";s:54:\"custom-css-js/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?post_type=custom-css-js&name=$matches[1]&feed=$matches[2]\";s:49:\"custom-css-js/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?post_type=custom-css-js&name=$matches[1]&feed=$matches[2]\";s:42:\"custom-css-js/([^/]+)/page/?([0-9]{1,})/?$\";s:68:\"index.php?post_type=custom-css-js&name=$matches[1]&paged=$matches[2]\";s:49:\"custom-css-js/([^/]+)/comment-page-([0-9]{1,})/?$\";s:68:\"index.php?post_type=custom-css-js&name=$matches[1]&cpage=$matches[2]\";s:38:\"custom-css-js/([^/]+)(?:/([0-9]+))?/?$\";s:67:\"index.php?post_type=custom-css-js&name=$matches[1]&page=$matches[2]\";s:30:\"custom-css-js/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:40:\"custom-css-js/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:60:\"custom-css-js/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"custom-css-js/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"custom-css-js/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:36:\"custom-css-js/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp20210827044706_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp20210827044706_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp20210827044706_options` VALUES("33","active_plugins","a:4:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:31:\"ameliabooking/ameliabooking.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:31:\"custom-css-js/custom-css-js.php\";}","yes");
INSERT INTO `wp20210827044706_options` VALUES("34","category_base","","yes");
INSERT INTO `wp20210827044706_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp20210827044706_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp20210827044706_options` VALUES("37","gmt_offset","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("39","recently_edited","a:4:{i:0;s:85:\"/home/users/1/mods.jp-tmu-sfc/web/homepage/wp-content/themes/twentytwentyone/page.php\";i:1;s:87:\"/home/users/1/mods.jp-tmu-sfc/web/homepage/wp-content/themes/twentytwentyone/search.php\";i:2;s:86:\"/home/users/1/mods.jp-tmu-sfc/web/homepage/wp-content/themes/twentytwentyone/style.css\";i:3;s:0:\"\";}","no");
INSERT INTO `wp20210827044706_options` VALUES("40","template","twentytwentyone","yes");
INSERT INTO `wp20210827044706_options` VALUES("41","stylesheet","twentytwentyone","yes");
INSERT INTO `wp20210827044706_options` VALUES("42","comment_registration","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("43","html_type","text/html","yes");
INSERT INTO `wp20210827044706_options` VALUES("44","use_trackback","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("45","default_role","subscriber","yes");
INSERT INTO `wp20210827044706_options` VALUES("46","db_version","49752","yes");
INSERT INTO `wp20210827044706_options` VALUES("47","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("48","upload_path","","yes");
INSERT INTO `wp20210827044706_options` VALUES("49","blog_public","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("50","default_link_category","2","yes");
INSERT INTO `wp20210827044706_options` VALUES("51","show_on_front","posts","yes");
INSERT INTO `wp20210827044706_options` VALUES("52","tag_base","","yes");
INSERT INTO `wp20210827044706_options` VALUES("53","show_avatars","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("54","avatar_rating","G","yes");
INSERT INTO `wp20210827044706_options` VALUES("55","upload_url_path","","yes");
INSERT INTO `wp20210827044706_options` VALUES("56","thumbnail_size_w","150","yes");
INSERT INTO `wp20210827044706_options` VALUES("57","thumbnail_size_h","150","yes");
INSERT INTO `wp20210827044706_options` VALUES("58","thumbnail_crop","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("59","medium_size_w","300","yes");
INSERT INTO `wp20210827044706_options` VALUES("60","medium_size_h","300","yes");
INSERT INTO `wp20210827044706_options` VALUES("61","avatar_default","mystery","yes");
INSERT INTO `wp20210827044706_options` VALUES("62","large_size_w","1024","yes");
INSERT INTO `wp20210827044706_options` VALUES("63","large_size_h","1024","yes");
INSERT INTO `wp20210827044706_options` VALUES("64","image_default_link_type","none","yes");
INSERT INTO `wp20210827044706_options` VALUES("65","image_default_size","","yes");
INSERT INTO `wp20210827044706_options` VALUES("66","image_default_align","","yes");
INSERT INTO `wp20210827044706_options` VALUES("67","close_comments_for_old_posts","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("68","close_comments_days_old","14","yes");
INSERT INTO `wp20210827044706_options` VALUES("69","thread_comments","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("70","thread_comments_depth","5","yes");
INSERT INTO `wp20210827044706_options` VALUES("71","page_comments","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("72","comments_per_page","50","yes");
INSERT INTO `wp20210827044706_options` VALUES("73","default_comments_page","newest","yes");
INSERT INTO `wp20210827044706_options` VALUES("74","comment_order","asc","yes");
INSERT INTO `wp20210827044706_options` VALUES("75","sticky_posts","a:0:{}","yes");
INSERT INTO `wp20210827044706_options` VALUES("76","widget_categories","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("77","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("78","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("79","uninstall_plugins","a:2:{s:39:\"simple-custom-css/simple-custom-css.php\";s:15:\"sccss_uninstall\";s:31:\"ameliabooking/ameliabooking.php\";a:2:{i:0;s:20:\"AmeliaBooking\\Plugin\";i:1;s:8:\"deletion\";}}","no");
INSERT INTO `wp20210827044706_options` VALUES("80","timezone_string","Asia/Tokyo","yes");
INSERT INTO `wp20210827044706_options` VALUES("81","page_for_posts","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("82","page_on_front","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("83","default_post_format","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("84","link_manager_enabled","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("85","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("86","site_icon","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("87","medium_large_size_w","768","yes");
INSERT INTO `wp20210827044706_options` VALUES("88","medium_large_size_h","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("89","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp20210827044706_options` VALUES("90","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("91","admin_email_lifespan","1645560851","yes");
INSERT INTO `wp20210827044706_options` VALUES("92","disallowed_keys","","no");
INSERT INTO `wp20210827044706_options` VALUES("93","comment_previously_approved","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("94","auto_plugin_theme_update_emails","a:0:{}","no");
INSERT INTO `wp20210827044706_options` VALUES("95","auto_update_core_dev","enabled","yes");
INSERT INTO `wp20210827044706_options` VALUES("96","auto_update_core_minor","enabled","yes");
INSERT INTO `wp20210827044706_options` VALUES("97","auto_update_core_major","enabled","yes");
INSERT INTO `wp20210827044706_options` VALUES("98","wp_force_deactivated_plugins","a:0:{}","yes");
INSERT INTO `wp20210827044706_options` VALUES("99","initial_db_version","49752","yes");
INSERT INTO `wp20210827044706_options` VALUES("100","wp20210827044706_user_roles","a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:133:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:15:\"edit_custom_css\";b:1;s:15:\"read_custom_css\";b:1;s:17:\"delete_custom_css\";b:1;s:16:\"edit_custom_csss\";b:1;s:23:\"edit_others_custom_csss\";b:1;s:19:\"publish_custom_csss\";b:1;s:18:\"delete_custom_csss\";b:1;s:28:\"delete_published_custom_csss\";b:1;s:25:\"delete_others_custom_csss\";b:1;s:26:\"edit_published_custom_csss\";b:1;s:16:\"amelia_read_menu\";b:1;s:21:\"amelia_read_dashboard\";b:1;s:20:\"amelia_read_calendar\";b:1;s:24:\"amelia_read_appointments\";b:1;s:18:\"amelia_read_events\";b:1;s:21:\"amelia_read_employees\";b:1;s:20:\"amelia_read_services\";b:1;s:20:\"amelia_read_packages\";b:1;s:21:\"amelia_read_locations\";b:1;s:19:\"amelia_read_coupons\";b:1;s:21:\"amelia_read_customers\";b:1;s:19:\"amelia_read_finance\";b:1;s:25:\"amelia_read_notifications\";b:1;s:21:\"amelia_read_customize\";b:1;s:25:\"amelia_read_custom_fields\";b:1;s:20:\"amelia_read_settings\";b:1;s:27:\"amelia_read_others_settings\";b:1;s:27:\"amelia_read_others_calendar\";b:1;s:31:\"amelia_read_others_appointments\";b:1;s:28:\"amelia_read_others_employees\";b:1;s:28:\"amelia_read_others_customers\";b:1;s:22:\"amelia_write_dashboard\";b:1;s:21:\"amelia_write_calendar\";b:1;s:25:\"amelia_write_appointments\";b:1;s:19:\"amelia_write_events\";b:1;s:22:\"amelia_write_employees\";b:1;s:21:\"amelia_write_services\";b:1;s:21:\"amelia_write_packages\";b:1;s:22:\"amelia_write_locations\";b:1;s:20:\"amelia_write_coupons\";b:1;s:22:\"amelia_write_customers\";b:1;s:20:\"amelia_write_finance\";b:1;s:26:\"amelia_write_notifications\";b:1;s:22:\"amelia_write_customize\";b:1;s:26:\"amelia_write_custom_fields\";b:1;s:21:\"amelia_write_settings\";b:1;s:19:\"amelia_write_status\";b:1;s:28:\"amelia_write_others_settings\";b:1;s:28:\"amelia_write_others_calendar\";b:1;s:32:\"amelia_write_others_appointments\";b:1;s:29:\"amelia_write_others_employees\";b:1;s:26:\"amelia_write_others_events\";b:1;s:27:\"amelia_write_others_finance\";b:1;s:29:\"amelia_write_others_dashboard\";b:1;s:23:\"amelia_delete_dashboard\";b:1;s:22:\"amelia_delete_calendar\";b:1;s:26:\"amelia_delete_appointments\";b:1;s:20:\"amelia_delete_events\";b:1;s:23:\"amelia_delete_employees\";b:1;s:22:\"amelia_delete_services\";b:1;s:22:\"amelia_delete_packages\";b:1;s:23:\"amelia_delete_locations\";b:1;s:21:\"amelia_delete_coupons\";b:1;s:23:\"amelia_delete_customers\";b:1;s:21:\"amelia_delete_finance\";b:1;s:27:\"amelia_delete_notifications\";b:1;s:23:\"amelia_delete_customize\";b:1;s:27:\"amelia_delete_custom_fields\";b:1;s:22:\"amelia_delete_settings\";b:1;s:32:\"amelia_write_status_appointments\";b:1;s:26:\"amelia_write_status_events\";b:1;s:30:\"amelia_write_time_appointments\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:15:\"css_js_designer\";a:2:{s:4:\"name\";s:24:\"ウェブデザイナー\";s:12:\"capabilities\";a:10:{s:15:\"edit_custom_css\";b:1;s:15:\"read_custom_css\";b:1;s:17:\"delete_custom_css\";b:1;s:16:\"edit_custom_csss\";b:1;s:23:\"edit_others_custom_csss\";b:1;s:19:\"publish_custom_csss\";b:1;s:18:\"delete_custom_csss\";b:1;s:28:\"delete_published_custom_csss\";b:1;s:25:\"delete_others_custom_csss\";b:1;s:26:\"edit_published_custom_csss\";b:1;}}s:17:\"wpamelia-customer\";a:2:{s:4:\"name\";s:15:\"Amelia Customer\";s:12:\"capabilities\";a:7:{s:4:\"read\";b:1;s:16:\"amelia_read_menu\";b:1;s:20:\"amelia_read_calendar\";b:1;s:24:\"amelia_read_appointments\";b:1;s:18:\"amelia_read_events\";b:1;s:32:\"amelia_write_status_appointments\";b:1;s:30:\"amelia_write_time_appointments\";b:1;}}s:17:\"wpamelia-provider\";a:2:{s:4:\"name\";s:15:\"Amelia Employee\";s:12:\"capabilities\";a:16:{s:4:\"read\";b:1;s:20:\"amelia_delete_events\";b:1;s:16:\"amelia_read_menu\";b:1;s:20:\"amelia_read_calendar\";b:1;s:24:\"amelia_read_appointments\";b:1;s:18:\"amelia_read_events\";b:1;s:21:\"amelia_read_employees\";b:1;s:28:\"amelia_read_others_customers\";b:1;s:22:\"amelia_write_employees\";b:1;s:32:\"amelia_write_status_appointments\";b:1;s:26:\"amelia_write_status_events\";b:1;s:30:\"amelia_write_time_appointments\";b:1;s:32:\"amelia_write_others_appointments\";b:0;s:25:\"amelia_write_appointments\";b:1;s:19:\"amelia_write_events\";b:1;s:26:\"amelia_write_others_events\";b:0;}}s:16:\"wpamelia-manager\";a:2:{s:4:\"name\";s:14:\"Amelia Manager\";s:12:\"capabilities\";a:41:{s:4:\"read\";b:1;s:20:\"amelia_delete_events\";b:1;s:16:\"amelia_read_menu\";b:1;s:21:\"amelia_read_dashboard\";b:1;s:20:\"amelia_read_calendar\";b:1;s:24:\"amelia_read_appointments\";b:1;s:18:\"amelia_read_events\";b:1;s:21:\"amelia_read_employees\";b:1;s:20:\"amelia_read_services\";b:1;s:20:\"amelia_read_packages\";b:1;s:21:\"amelia_read_locations\";b:1;s:19:\"amelia_read_coupons\";b:1;s:21:\"amelia_read_customers\";b:1;s:19:\"amelia_read_finance\";b:1;s:25:\"amelia_read_notifications\";b:1;s:27:\"amelia_read_others_calendar\";b:1;s:31:\"amelia_read_others_appointments\";b:1;s:28:\"amelia_read_others_employees\";b:1;s:28:\"amelia_read_others_customers\";b:1;s:22:\"amelia_write_dashboard\";b:1;s:21:\"amelia_write_calendar\";b:1;s:25:\"amelia_write_appointments\";b:1;s:19:\"amelia_write_events\";b:1;s:22:\"amelia_write_employees\";b:1;s:21:\"amelia_write_services\";b:1;s:21:\"amelia_write_packages\";b:1;s:22:\"amelia_write_locations\";b:1;s:20:\"amelia_write_coupons\";b:1;s:22:\"amelia_write_customers\";b:1;s:20:\"amelia_write_finance\";b:1;s:26:\"amelia_write_notifications\";b:1;s:28:\"amelia_write_others_calendar\";b:1;s:32:\"amelia_write_others_appointments\";b:1;s:29:\"amelia_write_others_employees\";b:1;s:26:\"amelia_write_others_events\";b:1;s:27:\"amelia_write_others_finance\";b:1;s:29:\"amelia_write_others_dashboard\";b:1;s:32:\"amelia_write_status_appointments\";b:1;s:26:\"amelia_write_status_events\";b:1;s:30:\"amelia_write_time_appointments\";b:1;s:12:\"upload_files\";b:1;}}}","yes");
INSERT INTO `wp20210827044706_options` VALUES("101","fresh_site","0","yes");
INSERT INTO `wp20210827044706_options` VALUES("102","WPLANG","ja","yes");
INSERT INTO `wp20210827044706_options` VALUES("103","widget_block","a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:157:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>最近の投稿</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:233:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>最近のコメント</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:153:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>アーカイブ</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:155:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>カテゴリー</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("104","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("105","cron","a:8:{i:1630610052;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1630610231;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1630613652;a:5:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1630613692;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1630613693;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1630693031;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1630700052;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("106","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("107","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("108","widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("109","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("110","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("111","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("112","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("113","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("114","widget_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("115","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("116","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("117","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("119","recovery_keys","a:0:{}","yes");
INSERT INTO `wp20210827044706_options` VALUES("120","https_detection_errors","a:1:{s:19:\"bad_response_source\";a:1:{i:0;s:75:\"レスポンスはこのサイトから来たのではないようです。\";}}","yes");
INSERT INTO `wp20210827044706_options` VALUES("122","theme_mods_twentytwentyone","a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"background_image\";s:64:\"http://tmusfc.jp/wp-content/uploads/2021/08/memphis-colorful.png\";s:15:\"background_size\";s:7:\"contain\";}","yes");
INSERT INTO `wp20210827044706_options` VALUES("132","_site_transient_timeout_browser_605f01b1409979f1b4f5151f8eefb28a","1630613692","no");
INSERT INTO `wp20210827044706_options` VALUES("133","_site_transient_browser_605f01b1409979f1b4f5151f8eefb28a","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"92.0.4515.159\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp20210827044706_options` VALUES("134","_site_transient_timeout_php_check_c60e90b5b23808bb6ae5fe6d44788a5f","1630613693","no");
INSERT INTO `wp20210827044706_options` VALUES("135","_site_transient_php_check_c60e90b5b23808bb6ae5fe6d44788a5f","a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp20210827044706_options` VALUES("137","can_compress_scripts","0","no");
INSERT INTO `wp20210827044706_options` VALUES("153","widget_recent-comments","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("154","widget_recent-posts","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("157","finished_updating_comment_type","1","yes");
INSERT INTO `wp20210827044706_options` VALUES("169","_transient_health-check-site-status-result","{\"good\":12,\"recommended\":6,\"critical\":1}","yes");
INSERT INTO `wp20210827044706_options` VALUES("211","recently_activated","a:1:{s:39:\"simple-custom-css/simple-custom-css.php\";i:1630442737;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("220","wpcf7","a:2:{s:7:\"version\";s:5:\"5.4.2\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1630299391;s:7:\"version\";s:5:\"5.4.2\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO `wp20210827044706_options` VALUES("224","secret_key","6]NaO^Txhe+/GR]r.6g0y>xaK8vz(5[+OUkJ-s3><|E*9!+jkTB{ImMY0E:-R/Fg","no");
INSERT INTO `wp20210827044706_options` VALUES("226","category_children","a:0:{}","yes");
INSERT INTO `wp20210827044706_options` VALUES("262","_site_transient_timeout_popular_importers_f3e31f11fd4be09ce8e82bad800fb297","1630602440","no");
INSERT INTO `wp20210827044706_options` VALUES("263","_site_transient_popular_importers_f3e31f11fd4be09ce8e82bad800fb297","a:2:{s:9:\"importers\";a:7:{s:7:\"blogger\";a:4:{s:4:\"name\";s:7:\"Blogger\";s:11:\"description\";s:54:\"Import posts, comments, and users from a Blogger blog.\";s:11:\"plugin-slug\";s:16:\"blogger-importer\";s:11:\"importer-id\";s:7:\"blogger\";}s:9:\"wpcat2tag\";a:4:{s:4:\"name\";s:29:\"Categories and Tags Converter\";s:11:\"description\";s:71:\"Convert existing categories to tags or tags to categories, selectively.\";s:11:\"plugin-slug\";s:18:\"wpcat2tag-importer\";s:11:\"importer-id\";s:10:\"wp-cat2tag\";}s:11:\"livejournal\";a:4:{s:4:\"name\";s:11:\"LiveJournal\";s:11:\"description\";s:46:\"Import posts from LiveJournal using their API.\";s:11:\"plugin-slug\";s:20:\"livejournal-importer\";s:11:\"importer-id\";s:11:\"livejournal\";}s:11:\"movabletype\";a:4:{s:4:\"name\";s:24:\"Movable Type and TypePad\";s:11:\"description\";s:62:\"Import posts and comments from a Movable Type or TypePad blog.\";s:11:\"plugin-slug\";s:20:\"movabletype-importer\";s:11:\"importer-id\";s:2:\"mt\";}s:3:\"rss\";a:4:{s:4:\"name\";s:3:\"RSS\";s:11:\"description\";s:30:\"Import posts from an RSS feed.\";s:11:\"plugin-slug\";s:12:\"rss-importer\";s:11:\"importer-id\";s:3:\"rss\";}s:6:\"tumblr\";a:4:{s:4:\"name\";s:6:\"Tumblr\";s:11:\"description\";s:53:\"Import posts &amp; media from Tumblr using their API.\";s:11:\"plugin-slug\";s:15:\"tumblr-importer\";s:11:\"importer-id\";s:6:\"tumblr\";}s:9:\"wordpress\";a:4:{s:4:\"name\";s:9:\"WordPress\";s:11:\"description\";s:96:\"Import posts, pages, comments, custom fields, categories, and tags from a WordPress export file.\";s:11:\"plugin-slug\";s:18:\"wordpress-importer\";s:11:\"importer-id\";s:9:\"wordpress\";}}s:10:\"translated\";b:0;}","no");
INSERT INTO `wp20210827044706_options` VALUES("268","auto_update_plugins","a:6:{i:0;s:36:\"contact-form-7/wp-contact-form-7.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:9:\"hello.php\";i:3;s:35:\"google-site-kit/google-site-kit.php\";i:4;s:23:\"siteguard/siteguard.php\";i:5;s:41:\"wp-multibyte-patch/wp-multibyte-patch.php\";}","no");
INSERT INTO `wp20210827044706_options` VALUES("299","_wp_suggested_policy_text_has_changed","not-changed","yes");
INSERT INTO `wp20210827044706_options` VALUES("306","ccj__activation_time","1630442731","yes");
INSERT INTO `wp20210827044706_options` VALUES("307","ccj__version","3.37","yes");
INSERT INTO `wp20210827044706_options` VALUES("308","custom-css-js-tree","a:1:{s:28:\"frontend-css-header-internal\";a:1:{i:0;s:6:\"40.css\";}}","yes");
INSERT INTO `wp20210827044706_options` VALUES("309","ccj_settings","a:5:{s:16:\"ccj_htmlentities\";b:0;s:17:\"ccj_htmlentities2\";b:0;s:16:\"ccj_autocomplete\";b:1;s:8:\"add_role\";b:1;s:15:\"remove_comments\";b:0;}","yes");
INSERT INTO `wp20210827044706_options` VALUES("328","_site_transient_timeout_browser_b17873e636bc67b013b6e84c24812339","1631070839","no");
INSERT INTO `wp20210827044706_options` VALUES("329","_site_transient_browser_b17873e636bc67b013b6e84c24812339","a:10:{s:4:\"name\";s:6:\"Safari\";s:7:\"version\";s:6:\"14.1.1\";s:8:\"platform\";s:6:\"iPhone\";s:10:\"update_url\";s:0:\"\";s:7:\"img_src\";s:0:\"\";s:11:\"img_src_ssl\";s:0:\"\";s:15:\"current_version\";s:0:\"\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:1;}","no");
INSERT INTO `wp20210827044706_options` VALUES("363","_site_transient_timeout_community-events-5807413450273be4478e11e975f320fc","1630644087","no");
INSERT INTO `wp20210827044706_options` VALUES("364","_site_transient_community-events-5807413450273be4478e11e975f320fc","a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";s:11:\"27.92.236.0\";}s:6:\"events\";a:4:{i:0;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:78:\"¿Cómo y cuándo organizar eventos de Meetup presenciales de nuevo? (Spanish)\";s:3:\"url\";s:68:\"https://www.meetup.com/learn-wordpress-discussions/events/280149039/\";s:6:\"meetup\";s:27:\"Learn WordPress Discussions\";s:10:\"meetup_url\";s:51:\"https://www.meetup.com/learn-wordpress-discussions/\";s:4:\"date\";s:19:\"2021-09-02 06:00:00\";s:8:\"end_date\";s:19:\"2021-09-02 07:00:00\";s:20:\"start_unix_timestamp\";i:1630587600;s:18:\"end_unix_timestamp\";i:1630591200;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"US\";s:8:\"latitude\";d:37.779998779297003;s:9:\"longitude\";d:-122.41999816895;}}i:1;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:106:\"WordPress のプラグインやドキュメントを翻訳してみよう！WordPress Translation Day 2021\";s:3:\"url\";s:63:\"https://www.meetup.com/Tokyo-WordPress-Meetup/events/280308599/\";s:6:\"meetup\";s:22:\"Tokyo WordPress Meetup\";s:10:\"meetup_url\";s:46:\"https://www.meetup.com/Tokyo-WordPress-Meetup/\";s:4:\"date\";s:19:\"2021-09-05 15:00:00\";s:8:\"end_date\";s:19:\"2021-09-11 23:59:00\";s:20:\"start_unix_timestamp\";i:1630821600;s:18:\"end_unix_timestamp\";i:1631372340;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"JP\";s:8:\"latitude\";d:35.669998168945;s:9:\"longitude\";d:139.77000427246;}}i:2;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:131:\"八王子WordPressミートアップ9月度「WP×本〜2021読書の秋はWordPress本読んでレベルアップ目指しciao!」\";s:3:\"url\";s:63:\"https://www.meetup.com/Tokyo-WordPress-Meetup/events/280270018/\";s:6:\"meetup\";s:22:\"Tokyo WordPress Meetup\";s:10:\"meetup_url\";s:46:\"https://www.meetup.com/Tokyo-WordPress-Meetup/\";s:4:\"date\";s:19:\"2021-09-11 14:00:00\";s:8:\"end_date\";s:19:\"2021-09-11 16:00:00\";s:20:\"start_unix_timestamp\";i:1631336400;s:18:\"end_unix_timestamp\";i:1631343600;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"JP\";s:8:\"latitude\";d:35.669998168945;s:9:\"longitude\";d:139.77000427246;}}i:3;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:164:\"WordPressの相談事おまへんか？みんなで一緒にまーるく収めまっせ～　Chiba WordPress Meetup オンラインミーティング21年9月の会\";s:3:\"url\";s:63:\"https://www.meetup.com/Chiba-WordPress-Meetup/events/280480753/\";s:6:\"meetup\";s:22:\"Chiba WordPress Meetup\";s:10:\"meetup_url\";s:46:\"https://www.meetup.com/Chiba-WordPress-Meetup/\";s:4:\"date\";s:19:\"2021-09-26 14:00:00\";s:8:\"end_date\";s:19:\"2021-09-26 16:00:00\";s:20:\"start_unix_timestamp\";i:1632632400;s:18:\"end_unix_timestamp\";i:1632639600;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"JP\";s:8:\"latitude\";d:35.610000610352003;s:9:\"longitude\";d:140.11000061035;}}}}","no");
INSERT INTO `wp20210827044706_options` VALUES("365","_transient_timeout_feed_992efac292246ae35bf235a03417a202","1630644088","no");
INSERT INTO `wp20210827044706_options` VALUES("366","_transient_feed_992efac292246ae35bf235a03417a202","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"ブログ | WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://ja.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"WordPress 日本語ローカルサイトブログ\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 26 Aug 2021 01:54:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"ja\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.9-alpha-51716\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"Classic Editor プラグインの公式サポート期限更新\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://ja.wordpress.org/2021/08/26/an-update-on-the-classic-editor-plugin/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 26 Aug 2021 01:38:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:7:\"General\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:7:\"Updates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6343\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"Classic Editor プラグインの公式サポート期限更新を2022年末まで延期しました。\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Naoko Takano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3302:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/matt/\"></a><a href=\"https://profiles.wordpress.org/chanthaboune/\"></a><a href=\"https://profiles.wordpress.org/cbringmann/\"></a><a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2020/04/wordpress-5-4-1/\"></a><a href=\"https://wordpress.org/news/2020/03/adderley/\"></a><a href=\"https://wordpress.org/news/2021/02/welcome-to-your-wp-briefing/\"></a><a href=\"https://wordpress.org/news/2021/02/gutenberg-tutorial-reusable-blocks/\"></a><a href=\"https://wordpress.org/news/2021/08/an-update-on-the-classic-editor-plugin/\">An Update on the Classic Editor Plugin</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>2018年の WordPress 5.0のリリース前に、新しいブロックエディターへの移行を容易にするため <a href=\"https://wordpress.org/plugins/classic-editor/\">Classic Editor</a> プラグインを公開しました。その際、このプラグインを2021年末までサポートし、期限が近づいた頃に必要に応じてそれを調整することを約束しました。マットと話し合った結果、2022年末までこのプラグインのサポートを継続することが、プロジェクトとコミュニティにとって正しい判断であることがはっきりしました。</p>



<p>とはいえ、ブロックエディターの利用を後回しにしていた人にとっては、もう一度試してみる絶好の機会です。ブロックエディターが2018年に初めて登場して以来、何百人もの WordPress コントリビューターたちが、ユーザーのフィードバックに基づいて多くのアップデートを行ってきました。使っていただければ、「こんなに進化したのか !」と嬉しい驚きを感じていただけるはずです。</p>



<p>WordPress、Gutenberg、Classic Editor プラグインに取り組んできた皆さんに心より感謝します。また、ソフトウェアをより良くするために必要なフィードバックを提供してくれたすべての WordPress ユーザーとテスターの皆さんも、ありがとうございます。</p>



<p>~ Josepha (ジョセファ)</p>



<hr class=\"wp-block-separator\" />



<p>久しぶりにブロックエディターを試してみるという方は、<a href=\"https://make.wordpress.org/test/handbook/full-site-editing-outreach-experiment/\">アウトリーチプログラム</a> (<a href=\"https://ja.wordpress.org/team/tag/fse-outreach-program/\">日本語訳</a>) に参加すれば、早い段階でフィードバックをいただけます。初めてブロックエディターを使う方は<a href=\"https://learn.wordpress.org/workshops/?series=1216&amp;topic=&amp;language=ja&amp;captions=\">ワークショップ</a>動画や<a href=\"https://ja.wordpress.org/support/article/wordpress-editor/#%e6%a9%9f%e8%83%bd\">こちらのデモ動画</a>をご覧いただき、基本的な使い方を知ってみてください。</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		

					
										
					
		
		



			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WordPress 5.8、そしてこれからのウィジェット\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://ja.wordpress.org/2021/08/10/widgets-in-wordpress-5-8-and-beyond/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Aug 2021 02:33:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6325\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:274:\"WordPress 5.8 では、ウィジェットエリアで Gutenberg ブロックが使えるようになりました。この投稿では、ウィジェットで実行できるようになった便利なことの一部と、今後の方向性に焦点を当てていきます。\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:3:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:60:\"https://wordpress.org/news/files/2021/08/classic-widgets.mov\";s:6:\"length\";s:7:\"6475399\";s:4:\"type\";s:15:\"video/quicktime\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:60:\"https://wordpress.org/news/files/2021/08/block-widgets-1.mov\";s:6:\"length\";s:8:\"23931847\";s:4:\"type\";s:15:\"video/quicktime\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:58:\"https://wordpress.org/news/files/2021/08/custom-html-1.mov\";s:6:\"length\";s:8:\"13767042\";s:4:\"type\";s:15:\"video/quicktime\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Naoko Takano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:7712:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/matt/\"></a><a href=\"https://profiles.wordpress.org/chanthaboune/\"></a><a href=\"https://profiles.wordpress.org/cbringmann/\">Chloe Bringmann</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2021/08/widgets-in-wordpress-5-8-and-beyond/\">Widgets in WordPress 5.8 and Beyond</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p><strong>文章・デザイン: <a href=\'https://profiles.wordpress.org/critterverse/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>critterverse</a></strong></p>



<p>WordPress 5.8 では、<a href=\"https://ja.wordpress.org/support/article/block-based-widgets-editor/\">ウィジェットエリアで Gutenberg ブロックが使えるようになりました</a>。つまり、高度にカスタマイズ可能なレイアウトとスタイル設定により、WYSIWYG 編集 (見たまま編集できる) の体験に近づくことができます。</p>



<p>3つの別々のウィジェットエリアを備えた古き良き <a href=\"https://wordpress.org/themes/twentysixteen/\">Twenty Sixteen テーマ</a>をベースに、テストサイトを作成してみました。この投稿では、ウィジェットで実行できるようになった便利なことの一部と、今後の方向性に焦点を当てていきます。</p>



<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"https://i0.wp.com/wordpress.org/news/files/2021/08/site-long-1x.png?ssl=1\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2021/08/site-long-1x.png?resize=632%2C1130&amp;ssl=1\" alt=\"1つのサイドバーウィジェットエリアと2つのフッターウィジェットエリアを持つ個別投稿のズームアウトビュー。サイトのコンテンツはマリンパーク・ソルトマーシュについてのものです。各ウィジェットエリアの横に並べているブロックのリスト表示は、デザインがどのように構築されているかを示しています。\" class=\"wp-image-11116\" /></a></figure></div>



<h2>重ねたレイアウトとデュオトーン画像でおもしろい視覚効果を作り出す</h2>



<p>外観に関しては、ユーザーはウィジェットエリアをこれまで以上にコントロールできます。特に、カバーや画像ブロックなどのカスタマイズオプションを備えたブロックを使用することで高度なコントロールが可能になります。これが、旧ウィジェットエディター (上) で作成できるものと、新しいブロックベースのウィジェットエディター (下) で作成できるものです。</p>



<figure class=\"wp-block-video aligncenter\"><video controls src=\"https://wordpress.org/news/files/2021/08/classic-widgets.mov\"></video></figure>



<figure class=\"wp-block-video aligncenter\"><video controls src=\"https://wordpress.org/news/files/2021/08/block-widgets-1.mov\"></video></figure>



<h2>ビジュアルデザイン全体にウィジェットとカスタムコードを混合させる</h2>



<p>カバーやカラムなどのコンテナブロックを使用すると、動的要素やインタラクティブな要素をデザインに簡単に織り込むことができます。これは多くのウィジェットに当てはまりますが、ウィジェットのブロックバージョンは、コンテナブロック内で簡単にまとめたりレイヤー化して、レイアウトに完全に統合できます。</p>



<p>以下の例では、カバーブロックの前に検索ブロックを配置してみました。これにより、良いレイヤー効果を作ることができます。また、カラムブロック内にカスタム HTML ブロックを挿入して、時刻に応じて異なるメッセージを表示しました (<a href=\"https://stackoverflow.com/questions/31242051/show-content-based-on-time-of-day-timing-changes-on-different-days-of-the-week\">jQuery スクリプト</a>)。</p>



<figure class=\"wp-block-video aligncenter\"><video controls src=\"https://wordpress.org/news/files/2021/08/custom-html-1.mov\"></video></figure>



<h2>タイトルと構造に柔軟性。旧ウィジェットレイアウトも使用するオプション</h2>



<p>クラシックウィジェットには、ウィジェットにタイトルが必ず含められているという制限がありました。ウィジェットエリアにブロックを配置することの利点のひとつは、タイトルの表示が完全に柔軟であることです。たとえば、すべてのウィジェットにタイトルを付けたり、各ウィジェットエリアの上部に1つのタイトルだけを配置したりすることもできますし、デザインにタイトルをまったく必要としない場合もあるでしょう。</p>



<p><strong>注:</strong> <a href=\"https://wordpress.org/themes/twentytwentyone/\">Twenty Twenty-One</a> などの一部のテーマでは、ウィジェットエリア内でコンテンツを横方向にレイアウトするように設計されています。テーマがレイアウトをカラムに分割してしまう問題が発生する場合は、グループブロック内に含めることで、複数のブロックをまとめておくことができます。</p>



<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"https://i1.wp.com/wordpress.org/news/files/2021/08/grouped.jpg?ssl=1\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2021/08/grouped.jpg?resize=632%2C381&amp;ssl=1\" alt=\"グループ化または入れ子になったまとまりがある場合とない場合のサイドバーウィジェットエリアのリストビューを並べた比較。\" class=\"wp-image-11122\" /></a></figure></div>



<h2>WordPress パターンディレクトリから既存のレイアウトをコピー &amp; ペースト</h2>



<p>ブロックパターンはまだウィジェットエディターに完全に統合されていませんが、<a href=\"https://wordpress.org/patterns/\">革新的な WordPress パターンディレクトリ</a>からサイトのウィジェットエリアにパターンをコピー &amp; ペーストする、ということは可能です。パターンディレクトリから、<a href=\"https://wordpress.org/patterns/pattern/horizontal-call-to-action/\">この横並びの CTA (注意喚起)</a> パターンをほぼそのまま使用しましたが、色とテキストを少し調整しました。</p>



<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"https://i1.wp.com/wordpress.org/news/files/2021/08/footer.jpg?ssl=1\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2021/08/footer.jpg?resize=632%2C389&amp;ssl=1\" alt=\"段落テキストと &quot;Join now (今すぐ参加)&quot; ボタンが別のカラムにあり、&quot;Become a monthly patron (月毎の支援者になる)&quot; と書かれた黒いボックスのあるフッターウィジェットエリア。岩に当たる波の絵画の画像。間にスペースがなく、真下にあります。
\" class=\"wp-image-11123\" /></a></figure></div>



<p><strong>注:</strong> パターンはまだウィジェットエリア用として選別・連携されていないため、予期しない動作が発生する可能性があります。この機能は、ウィジェット編集の次のプレビューであると考えてください。</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"theme.json を使ったテーマデザインの設定\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://ja.wordpress.org/2021/08/02/configuring-theme-design-with-theme-json/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Aug 2021 07:12:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6301\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:267:\"WordPress 5.8以降、“theme.json” をテーマ開発に利用できるようになりました。この新しいフレームワークを簡単に紹介し、実用的なヒントと例を共有することで、何ができるのかを説明していきます。\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Naoko Takano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:13336:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/matt/\"></a><a href=\"https://profiles.wordpress.org/chanthaboune/\"></a><a href=\"https://profiles.wordpress.org/cbringmann/\"></a><a href=\"https://profiles.wordpress.org/jffng/\">Jeff Ong</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2020/04/wordpress-5-4-1/\"></a><a href=\"https://wordpress.org/news/2020/03/adderley/\"></a><a href=\"https://wordpress.org/news/2021/02/welcome-to-your-wp-briefing/\"></a><a href=\"https://wordpress.org/news/2021/02/gutenberg-tutorial-reusable-blocks/\"></a><a href=\"https://wordpress.org/news/2021/07/configuring-theme-design-with-theme-json/\">Configuring Theme Design with theme.json</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><a href=\"https://ja.wordpress.org/files/2021/08/themejson-1.png\"><img loading=\"lazy\" width=\"1024\" height=\"576\" src=\"https://ja.wordpress.org/files/2021/08/themejson-1-1024x576.png\" alt=\"\" class=\"wp-image-6319\" srcset=\"https://ja.wordpress.org/files/2021/08/themejson-1-1024x576.png 1024w, https://ja.wordpress.org/files/2021/08/themejson-1-300x169.png 300w, https://ja.wordpress.org/files/2021/08/themejson-1-768x432.png 768w, https://ja.wordpress.org/files/2021/08/themejson-1-1536x864.png 1536w, https://ja.wordpress.org/files/2021/08/themejson-1-2048x1152.png 2048w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></a></figure></div>



<p><a href=\"https://ja.wordpress.org/2021/07/21/tatum/\" data-type=\"post\" data-id=\"6295\">WordPress 5.8</a>以降、新しいツールである “theme.json” をテーマ開発に利用できるようになりました。初めて聞いたかもしれませんし、すでにこれを試用し、テーマを開発しているかもしれません。いずれにせよ、今は WordPress テーマにとってエキサイティングな時期ですので、この記事を読んでいただけて嬉しく思います。</p>



<p>当記事では、この新しいフレームワークを簡単に紹介し、実用的なヒントと例をいくつか共有することで、何ができるのかを説明していきます。</p>



<h2>theme.json とは</h2>



<p>技術的に言えば、theme.json はテーマのディレクトリのトップレベルにある単なるファイルです。</p>



<p>しかし、概念的に言えば、テーマの開発方法に大きな変化をもたらすものです。テーマの作成者は、サイトの作成者と訪問者に合わせて WordPress での体験を調整するための一元的なメカニズムを利用できるようになりました。theme.json は、テーマ作者がグローバルスタイル、ブロックスタイル、ブロックエディターの設定をきめ細かく制御できる方法を提供します。</p>



<p>これらの設定と制御を単一のファイルで提供することにより、theme.json は、テーマのデザインと開発の多くの側面をまとめる強力なフレームワークとなります。そして、ブロックエディターが成熟し、より多くの機能が追加されていくにつれ、theme.json は、テーマとエディターが連携するためのバックボーンとして活躍するでしょう <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/1f4aa.png\" alt=\"💪\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /> 。</p>



<h2>これを使う理由</h2>



<p>なぜ theme.json を使うのか – その理由は、テーマの未来がこの方向に進んでいるからです。しかし、私も最初はそうでしたが、皆さんも納得するためにもっと具体的な何かが必要かもしれません。現在 theme.json を使用する理由はいくつかあります。</p>



<ul><li>色、タイポグラフィ、間隔、レイアウトなどのエディター設定を制御し、設定を管理する場所を一元化します。</li><li>スタイルがサイト全体のブロックと要素に正しく適用されることを保証します。</li><li>テーマが提供していた土台となる CSS の量を減らします。theme.json は、スタイルシートを完全に置き換えるわけではありません。テーマに追加の特殊効果や装飾 (トランジション、アニメーションなど) を与えるために CSS が必要になる場合もあるでしょう。ですが、テーマに必要な基本 CSS を大幅に減らすことができます。</li></ul>



<h2>使い方</h2>



<p>この記事の残りの部分では、試すことができる theme.json 設定をいくつかご紹介します。例では、今年のデフォルトテーマをベースとしたブロック版のテーマである&nbsp;<a href=\"https://wordpress.org/themes/tt1-blocks/\">tt1-blocks</a>&nbsp;の&nbsp;<a href=\"https://github.com/WordPress/theme-experiments/blob/master/tt1-blocks/theme.json\">theme.json</a>&nbsp;を使用します。</p>



<p>既存のテーマから始める場合は、<a href=\"https://github.com/WordPress/theme-experiments/\">WordPress/theme-experiments リポジトリ</a>から theme.json をコピーし (例えば、<a href=\"https://profiles.wordpress.org/poena/\">@poena</a>&nbsp;作の&nbsp;<a href=\"https://github.com/WordPress/theme-experiments/blob/master/fse-tutorial/theme.json\">fse-tutorial</a>)、ご自分のテーマのディレクトリのルートに追加します。</p>



<h3>サイトのタイポグラフィ設定をグローバル (全体的) に変更する</h3>


<div class=\"wp-block-syntaxhighlighter-code \"><pre class=\"brush: jscript; title: ; notranslate\">
&quot;settings&quot;: {
	&quot;typography&quot;: {
		&quot;fontSize&quot;: &quot;30px&quot;,
		...

</pre></div>


<p>上記の theme.json に変更を加えると、テーマの body タイポグラフィスタイル (前と後) が次のように更新されます。</p>



<figure class=\"wp-block-gallery columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><a href=\"https://i1.wp.com/wordpress.org/news/files/2021/07/Screen-Shot-2021-07-23-at-11.06.07-AM.png\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2021/07/Screen-Shot-2021-07-23-at-11.06.07-AM.png\" alt=\"\" data-id=\"11062\" class=\"wp-image-11062\" /></a></figure></li><li class=\"blocks-gallery-item\"><figure><a href=\"https://i1.wp.com/wordpress.org/news/files/2021/07/Screen-Shot-2021-07-23-at-11.05.40-AM.png\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2021/07/Screen-Shot-2021-07-23-at-11.05.40-AM.png\" alt=\"\" data-id=\"\" /></a></figure></li></ul></figure>



<h3>サイトの基本色設定をグローバル (全体的) に変更する</h3>


<div class=\"wp-block-syntaxhighlighter-code \"><pre class=\"brush: jscript; title: ; notranslate\">
&quot;styles&quot;: {
	&quot;color&quot;: {
		&quot;background&quot;: &quot;#ffc0cb&quot;,
		&quot;text&quot;: &quot;#6A1515&quot;
	},
	...
}

</pre></div>


<figure class=\"wp-block-gallery columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><a href=\"https://i2.wp.com/wordpress.org/news/files/2021/07/Screen-Shot-2021-07-23-at-11.10.03-AM.png\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2021/07/Screen-Shot-2021-07-23-at-11.10.03-AM.png\" alt=\"\" data-id=\"11063\" class=\"wp-image-11063\" /></a></figure></li><li class=\"blocks-gallery-item\"><figure><a href=\"https://i2.wp.com/wordpress.org/news/files/2021/07/Screen-Shot-2021-07-23-at-11.08.54-AM.png\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2021/07/Screen-Shot-2021-07-23-at-11.08.54-AM.png\" alt=\"\" data-id=\"\" /></a></figure></li></ul></figure>



<h3>特定のブロックのスペースとパディングの設定を変更する</h3>


<div class=\"wp-block-syntaxhighlighter-code \"><pre class=\"brush: jscript; title: ; notranslate\">
&quot;styles&quot;: {
	&quot;blocks&quot;: {
		&quot;core/code&quot;: {
			&quot;spacing&quot;: {
				&quot;padding&quot;: {
					&quot;top&quot;: &quot;3em&quot;,
					&quot;bottom&quot;: &quot;3em&quot;,
					&quot;left&quot;: &quot;3em&quot;,
					&quot;right&quot;: &quot;3em&quot;
				}
			}
		}
	}
}


</pre></div>


<figure class=\"wp-block-gallery columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><a href=\"https://i2.wp.com/wordpress.org/news/files/2021/07/code-padding-original.png\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2021/07/code-padding-original.png\" alt=\"\" data-id=\"11065\" class=\"wp-image-11065\" /></a></figure></li><li class=\"blocks-gallery-item\"><figure><a href=\"https://i1.wp.com/wordpress.org/news/files/2021/07/code-padding-edited.png\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2021/07/code-padding-edited.png\" alt=\"\" data-id=\"\" /></a></figure></li></ul></figure>



<h3>エディター内でボタンなどの特定のブロックにカスタムカラーパレットを設定する</h3>


<div class=\"wp-block-syntaxhighlighter-code \"><pre class=\"brush: jscript; title: ; notranslate\">
&quot;settings&quot;: {
    &quot;blocks&quot;: {
		&quot;core/button&quot;: {
			&quot;color&quot;: {
				&quot;palette&quot;: &#91; 
					{
						&quot;name&quot;: &quot;Maroon&quot;,
						&quot;color&quot;: &quot;#6A1515&quot;,
						&quot;slug&quot;: &quot;maroon&quot;
					},
					{
						&quot;name&quot;: &quot;Strawberry Ice Cream&quot;,
						&quot;color&quot;: &quot;#FFC0CB&quot;,
						&quot;slug&quot;: &quot;strawberry-ice-cream&quot;
					}
				]
			}
		}
	}
}

</pre></div>


<figure class=\"wp-block-gallery columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><a href=\"https://i0.wp.com/wordpress.org/news/files/2021/07/button-all-colors.png\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2021/07/button-all-colors.png\" alt=\"\" data-id=\"11069\" class=\"wp-image-11069\" /></a></figure></li><li class=\"blocks-gallery-item\"><figure><a href=\"https://i1.wp.com/wordpress.org/news/files/2021/07/buttons-custom-palette.png\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2021/07/buttons-custom-palette.png\" alt=\"\" data-id=\"\" /></a></figure></li></ul></figure>



<h3>タイポグラフィ制御の有効化と無効化</h3>



<p>次の例では、すべての見出しブロックにカスタムフォントサイズと行の高さを指定する機能を無効化しています。</p>


<div class=\"wp-block-syntaxhighlighter-code \"><pre class=\"brush: jscript; title: ; notranslate\">
	&quot;settings&quot;: {
		&quot;blocks&quot;: {
			&quot;core/heading&quot;: {
				&quot;typography&quot;: {
					&quot;customFontSize&quot;: false,
					&quot;customLineHeight&quot;: false
				}
			}
		}
	}

</pre></div>


<figure class=\"wp-block-gallery columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><a href=\"https://i1.wp.com/wordpress.org/news/files/2021/07/heading-all-options.png\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2021/07/heading-all-options.png\" alt=\"\" data-id=\"11071\" class=\"wp-image-11071\" /></a></figure></li><li class=\"blocks-gallery-item\"><figure><a href=\"https://i2.wp.com/wordpress.org/news/files/2021/07/heading-no-line-height-custom-size.png\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2021/07/heading-no-line-height-custom-size.png\" alt=\"\" data-id=\"\" /></a></figure></li></ul></figure>



<h2>これからについて</h2>



<p>この記事を通じて、何が可能で、テーマがどこに向かっているのかが伝わっていることを祈ります。ここで紹介したのはテーマのデザイン設定でできることのほんの一例であり、テーマ作者の皆さんがこれからどのような作品を生み出すのか、とても楽しみにしています。</p>



<p>詳細については、&nbsp;<a href=\"https://make.wordpress.org/core/2021/06/25/introducing-theme-json-in-wordpress-5-8/\">theme.json に関する開発者向けのメモ</a> (英語) と、ハンドブックにある&nbsp;<a href=\"https://ja.wordpress.org/team/handbook/block-editor/how-to-guides/themes/theme-json/\">theme.jsonのドキュメント</a>をご覧ください。</p>



<hr class=\"wp-block-separator\" />



<p>この投稿をレビューしてくれた <a href=\"https://profiles.wordpress.org/kjellr\">@kjellr</a>、<a href=\"https://profiles.wordpress.org/kjellr\">@</a><a href=\"https://profiles.wordpress.org/chanthaboune\">chanthaboune</a>、<a href=\"https://profiles.wordpress.org/chanthaboune\">@</a><a href=\"https://profiles.wordpress.org/priethor\">priethor</a>、<a href=\"https://profiles.wordpress.org/priethor\">@</a><a href=\"https://profiles.wordpress.org/annezazu\">annezazu</a> に感謝します。【訳者追記】また、翻訳レビューに協力してくださった <a href=\'https://profiles.wordpress.org/nukaga/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>nukaga</a> さんと <a href=\'https://profiles.wordpress.org/atachibana/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>atachibana</a> さん、ありがとうございました。</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"WordPress 5.8 Tatum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://ja.wordpress.org/2021/07/21/tatum/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Jul 2021 23:09:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6295\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:238:\"以下は、Matt Mullenweg が書いた WordPress.org 公式ブログの記事「WordPress 5.8 Tatum」を訳したものです。 誤字脱字誤訳などありましたらフォーラムまでお知らせください。 最新 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Seisuke Kuraishi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:51640:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/matt/\">Matt Mullenweg</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2021/07/tatum/\">WordPress 5.8 Tatum</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<figure class=\"wp-block-image size-large\"><img src=\"https://wordpress.org/news/files/2021/07/5x8-Album-1-1024x683.jpg\" alt=\"\" class=\"wp-image-11042\" /></figure>



<p>最新かつ最高のリリース、5.8「Tatum」が、<a href=\"https://ja.wordpress.org/download/\">ダウンロード</a>、また、ダッシュボードからアップデートできるようになりました。このリリースは、伝説のジャズピアニスト、アート・テイタムに敬意を表して名付けられました。彼の圧倒的なテクニックと限界を超えようとする姿勢は、ミュージシャン達にインスピレーションを与え、人々の考えを変えました。</p>



<p>お好みの音楽サービスを起動して、テイタムが録音した「Tea for Two」「Tiger Rag」「Begin the Beguine」、そして「Night and Day」などの名曲を楽しみながら、WordPress の最新バージョンについて読んでみてください。</p>



<hr class=\"wp-block-separator is-style-wide\" />



<h2 class=\"has-text-align-center\">パワフルな3つの新機能</h2>



<div style=\"height:16px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<figure class=\"wp-block-gallery columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://wordpress.org/news/files/2021/07/about-widgets-blocks-1024x768.png\" alt=\"\" data-id=\"10985\" data-full-url=\"https://wordpress.org/news/files/2021/07/about-widgets-blocks.png\" data-link=\"https://wordpress.org/news/?attachment_id=10985\" class=\"wp-image-10985\" /></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://wordpress.org/news/files/2021/07/about-query-loop-1024x811.png\" alt=\"\" data-id=\"10986\" data-full-url=\"https://wordpress.org/news/files/2021/07/about-query-loop.png\" data-link=\"https://wordpress.org/news/?attachment_id=10986\" class=\"wp-image-10986\" /></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://wordpress.org/news/files/2021/07/about-template-1024x666.png\" alt=\"\" data-id=\"10987\" data-full-url=\"https://wordpress.org/news/files/2021/07/about-template.png\" data-link=\"https://wordpress.org/news/?attachment_id=10987\" class=\"wp-image-10987\" /></figure></li></ul></figure>



<h3>ブロックを使ったウィジェット管理</h3>



<p>数ヶ月にわたる作業の結果、ブロックウィジェットエディターとカスタマイザーの両方でブロックの力を利用できるようになりました。サイト内のウィジェットエリアにブロックを追加したり、カスタマイザーでライブプレビューできます。コーディング不要のミニレイアウトから、コアやサードパーティブロックの膨大なライブラリまで、コンテンツ制作の新しい可能性が広がります。開発者の方は、<a href=\"https://make.wordpress.org/core/2021/06/29/block-based-widgets-editor-in-wordpress-5-8/\">ウイジェット開発ノート</a>で詳細をご覧ください。</p>



<h3>新しいブロックとパターンで投稿を表示</h3>



<p>クエリーループブロックは、コードを書かずに PHP のループと同じような、指定したパラメータに基づく記事を表示できます。特定のカテゴリーからの投稿を簡単に表示して、ポートフォリオやお気に入りのレシピを集めたページなどを作成できます。より複雑で、より強力な「最新の投稿」ブロックと考えてもよいでしょう。さらに、パターンの提案を使用すると、思い通りのデザインの投稿リストを簡単に作成できます。</p>



<h3>投稿テンプレートの編集</h3>



<p>ブロックテーマ、またはこの機能にオプトインしたテーマを有効にするだけで、使い慣れたブロックエディターでコンテンツを格納するテンプレートを編集することができます。テンプレートの編集と投稿やページの編集という工程をすべて、慣れ親しんだブロックエディターを使いながら切り替えて行うことができます。互換性のあるテーマには、20種類以上の新しいブロックが用意されています。この機能の詳細と実際に試してみる方法については、リリースノートをご覧ください。</p>



<div style=\"height:32px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<h2 class=\"has-text-align-center\">3つのワークフローヘルパー</h2>



<div style=\"height:16px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<figure class=\"wp-block-gallery columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://wordpress.org/news/files/2021/07/about-list-view-1024x803.png\" alt=\"\" data-id=\"10988\" data-full-url=\"https://wordpress.org/news/files/2021/07/about-list-view.png\" data-link=\"https://wordpress.org/news/?attachment_id=10988\" class=\"wp-image-10988\" /></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://wordpress.org/news/files/2021/07/about-pattern-suggestions-1024x555.png\" alt=\"\" data-id=\"10989\" data-full-url=\"https://wordpress.org/news/files/2021/07/about-pattern-suggestions.png\" data-link=\"https://wordpress.org/news/?attachment_id=10989\" class=\"wp-image-10989\" /></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://wordpress.org/news/files/2021/07/about-duotone-1024x837.png\" alt=\"\" data-id=\"10990\" data-full-url=\"https://wordpress.org/news/files/2021/07/about-duotone.png\" data-link=\"https://wordpress.org/news/?attachment_id=10990\" class=\"wp-image-10990\" /></figure></li></ul></figure>



<h3>ページ構造の概要</h3>



<p>シンプルなランディングページが必要な場合もあれば、もう少ししっかりしたページが必要な場合もあります。ブロックが増え、パターンが登場し、コンテンツ作成が容易になるにつれ、複雑なコンテンツを簡単にナビゲートする新しいソリューションが必要になりました。「リストビュー」は、コンテンツのレイヤーやネストしたブロックの間をジャンプするのに最適な方法です。リストビューにはコンテンツ内のすべてのブロックの概要が表示されるため、必要なブロックにすばやく移動できます。コンテンツに完全に集中したい場合は、ワークフローに応じてこの機能の有効、無効を切り替えられます。</p>



<h3>ブロック用おすすめパターン</h3>



<p>今回のリリースから、「パターン変換」ツールは、使用しているブロックに基づいてブロックパターンを提案するようになりました。現時点では、クエリーブロックとソーシャルアイコンブロックで試すことができます。今後、パターンが追加されていけば、エディターにいながら、サイトのスタイリングのインスピレーションを得られるでしょう。</p>



<h3>画像にスタイルや色を追加</h3>



<p>デュオトーンフィルターで画像やカバーブロックを彩りましょう ! デュオトーンは、デザインにポップな色を加えたり、画像、またはカバーブロックの動画をテーマに合わせてスタイリングできます。デュオトーン効果は、白黒のフィルターに似ていますが、影が黒、ハイライトが白の代わりに、影とハイライトに自分の好きな色を選ぶことができます。この機能については、ドキュメントで詳しく説明されています。</p>



<div style=\"height:32px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<h2 class=\"has-text-align-center\">開発者の方へ</h2>



<div style=\"height:16px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<figure class=\"wp-block-image size-large\"><img src=\"https://wordpress.org/news/files/2021/07/about-theme-json-2x-1024x613.png\" alt=\"\" class=\"wp-image-10992\" /></figure>



<div style=\"height:16px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<h3>Theme.json</h3>



<p>グローバルスタイルとグローバル設定 API の導入: 有効化されたテーマ内の theme.json ファイルを使用して、エディターの設定、利用可能なカスタマイズツール、スタイルブロックを制御できます。この設定ファイルはサイトとブロックの両方に対して、機能を有効または無効にし、デフォルトのスタイルを設定します。テーマ作成者は、この便利な新機能の初期イテレーションを試してみることができます。現在利用可能な機能とその仕組みについては、<a href=\"https://make.wordpress.org/core/2021/06/25/introducing-theme-json-in-wordpress-5-8/\">こちらの開発ノートをご覧ください</a>。</p>



<div style=\"height:16px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<div class=\"wp-block-columns\">
<div class=\"wp-block-column\">
<h3>Internet Explorer 11 サポートの終了</h3>



<p>Internet Explorer 11 のサポートは今回のリリースに含まれません。これは、将来的に修正されないサイト管理上の問題が発生する可能性があることを意味します。現在、IE11 を使用している場合は、<a href=\"https://browsehappy.com/\">最新のブラウザーに切り替えることを強くお勧めします</a>。</p>
</div>



<div class=\"wp-block-column\">
<h3>WebP サポートの追加</h3>



<p>WebP は、ウェブ上の画像の可逆圧縮と非可逆圧縮を改善した最新の画像フォーマットです。WebP の画像は、JPEG や PNG に比べて平均で約30％も小さくなるため、サイトの高速化や帯域幅の削減につながります。</p>
</div>
</div>



<h3>さらなるブロックサポートの追加</h3>



<p>WordPress 5.8では、WordPress <a href=\"https://make.wordpress.org/core/2020/11/18/block-supports-in-wordpress-5-6/\">5.6</a> および <a href=\"https://make.wordpress.org/core/2021/02/24/changes-to-block-editor-components-and-blocks/\">5.7</a> で実装されたブロックサポートを拡張し、登録したブロックをカスタマイズするいくつかの新しいブロックサポートフラグと、新しいオプションを導入しました。詳細な情報は、<a href=\"https://make.wordpress.org/core/2021/06/25/block-supports-api-updates-for-wordpress-5-8/\">ブロックサポート開発ノート</a>にあります。</p>



<div style=\"height:16px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<h3>詳細はフィールドガイドを参照してください！</h3>



<p>WordPress フィールドガイドの最新バージョンを参照してください。各変更の開発者向けノートをまとめた必読のガイドです。<a href=\"https://make.wordpress.org/core/2021/07/03/wordpress-5-8-field-guide/\">WordPress 5.8 フィールドガイド</a>。</p>



<hr class=\"wp-block-separator is-style-wide\" />



<h2>リリースチーム</h2>



<p>WordPress 5.8 は、<a href=\"https://profiles.wordpress.org/matt/\">Matt Mullenweg</a> のリードと、熱心なリリースチームのサポートによりリリースされました。</p>



<ul><li><strong>Release Co-Coordinator:</strong>&nbsp;Jeffrey Paul (<a href=\"https://profiles.wordpress.org/jeffpaul/\">@jeffpaul</a>)</li><li><strong>Release Co-Coordinator:</strong>&nbsp;Jonathan Desrosiers (<a href=\"https://profiles.wordpress.org/desrosj/\">@desrosj</a>)</li><li><strong>Editor Tech Lead:</strong>&nbsp;Riad Benguella (<a href=\"https://profiles.wordpress.org/youknowriad/\">@youknowriad</a>)</li><li><strong>Marketing and Communications Lead:</strong> Josepha Haden Chomphosy (<a href=\"https://profiles.wordpress.org/chanthaboune/\">@chanthaboune</a>)</li><li><strong>Documentation Lead:</strong> Milana Cap (<a href=\"https://profiles.wordpress.org/milana_cap/\">@milana_cap</a>)</li><li><strong>Test Lead:</strong>&nbsp;Piotrek Boniu (<a href=\"https://profiles.wordpress.org/boniu91/\">@boniu91</a>)</li><li><strong>Support Lead:&nbsp;</strong>Mary Job (<a href=\"https://profiles.wordpress.org/mariaojob/\">@mariaojob</a>)</li></ul>



<p>このリリースは、530人の寛大なボランティア貢献者の努力の結晶です。<a href=\"https://core.trac.wordpress.org/query?milestone=5.8&amp;group=component&amp;col=id&amp;col=summary&amp;col=milestone&amp;col=owner&amp;col=type&amp;col=status&amp;col=priority&amp;order=priority\">Trac では 320 以上のチケット</a>、<a href=\"https://github.com/wordpress/gutenberg/compare/v10.0.0...v10.7.0\">GitHub では 1,500 以上のプルリクエスト</a>でコラボレーションが行われました。</p>



<p><a href=\"https://profiles.wordpress.org/5ubliminal/\">5ubliminal</a>, <a href=\"https://profiles.wordpress.org/ninetyninew/\">99w</a>, <a href=\"https://profiles.wordpress.org/9primus/\">9primus</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/aaronrobertshaw/\">aaronrobertshaw</a>, <a href=\"https://profiles.wordpress.org/abderrahman/\">abderrahman</a>, <a href=\"https://profiles.wordpress.org/webcommsat/\">Abha Thakor</a>, <a href=\"https://profiles.wordpress.org/abhijitrakas/\">Abhijit Rakas</a>, <a href=\"https://profiles.wordpress.org/achbed/\">achbed</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/zieladam/\">Adam Zielinski</a>, <a href=\"https://profiles.wordpress.org/addiestavlo/\">Addie</a>, <a href=\"https://profiles.wordpress.org/aduth/\">aduth</a>, <a href=\"https://profiles.wordpress.org/chaion07/\">Ahmed Chaion</a>, <a href=\"https://profiles.wordpress.org/engahmeds3ed/\">Ahmed Saeed</a>, <a href=\"https://profiles.wordpress.org/ajitbohra/\">Ajit Bohra</a>, <a href=\"https://profiles.wordpress.org/schlessera/\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/alanjacobmathew/\">alanjacobmathew</a>, <a href=\"https://profiles.wordpress.org/aljullu/\">Albert Juhé Lluveras</a>, <a href=\"https://profiles.wordpress.org/aleperez92/\">Alejandro Perez</a>, <a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/akirk/\">Alex Kirk</a>, <a href=\"https://profiles.wordpress.org/ajlende/\">Alex Lende</a>, <a href=\"https://profiles.wordpress.org/alexstine/\">alexstine</a>, <a href=\"https://profiles.wordpress.org/firewatch/\">allilevine</a>, <a href=\"https://profiles.wordpress.org/amandariu/\">Amanda Riu</a>, <a href=\"https://profiles.wordpress.org/amarinediary/\">amarinediary</a>, <a href=\"https://profiles.wordpress.org/gadgetroid/\">Amogh Harish</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andraganescu/\">Andrei Draganescu</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/andrewserong/\">Andrew Serong</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey &#8220;Rarst&#8221; Savchenko</a>, <a href=\"https://profiles.wordpress.org/nosolosw/\">André Maneiro</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/apeatling/\">Andy Peatling</a>, <a href=\"https://profiles.wordpress.org/andy/\">Andy Skelton</a>, <a href=\"https://profiles.wordpress.org/wpgurudev/\">Ankit Gade</a>, <a href=\"https://profiles.wordpress.org/annalamprou/\">annalamprou</a>, <a href=\"https://profiles.wordpress.org/annezazu/\">Anne McCarthy</a>, <a href=\"https://profiles.wordpress.org/anotherdave/\">anotherdave</a>, <a href=\"https://profiles.wordpress.org/anotia/\">anotia</a>, <a href=\"https://profiles.wordpress.org/antpb/\">Anthony Burchell</a>, <a href=\"https://profiles.wordpress.org/antonlukin/\">Anton Lukin</a>, <a href=\"https://profiles.wordpress.org/vanyukov/\">Anton Vanyukov</a>, <a href=\"https://profiles.wordpress.org/antonisme/\">Antonis Lilis</a>, <a href=\"https://profiles.wordpress.org/apedog/\">apedog</a>, <a href=\"https://profiles.wordpress.org/apokalyptik/\">apokalyptik</a>, <a href=\"https://profiles.wordpress.org/arena/\">arena</a>, <a href=\"https://profiles.wordpress.org/lephleg/\">Argyris Margaritis</a>, <a href=\"https://profiles.wordpress.org/aristath/\">Ari Stathopoulos</a>, <a href=\"https://profiles.wordpress.org/ariskataoka/\">ariskataoka</a>, <a href=\"https://profiles.wordpress.org/arkrs/\">arkrs</a>, <a href=\"https://profiles.wordpress.org/aruphi/\">Armand</a>, <a href=\"https://profiles.wordpress.org/arnaudban/\">ArnaudBan</a>, <a href=\"https://profiles.wordpress.org/arthur791004/\">Arthur Chu</a>, <a href=\"https://profiles.wordpress.org/arunsathiya/\">Arun a11n</a>, <a href=\"https://profiles.wordpress.org/aspexi/\">Aspexi</a>, <a href=\"https://profiles.wordpress.org/atjn/\">atjn</a>, <a href=\"https://profiles.wordpress.org/aurooba/\">Aurooba Ahmed</a>, <a href=\"https://profiles.wordpress.org/filosofo/\">Austin Matzko</a>, <a href=\"https://profiles.wordpress.org/ayeshrajans/\">Ayesh Karunaratne</a>, <a href=\"https://profiles.wordpress.org/barry/\">Barry</a>, <a href=\"https://profiles.wordpress.org/bartkalisz/\">bartkalisz</a>, <a href=\"https://profiles.wordpress.org/beafialho/\">Beatriz Fialho</a>, <a href=\"https://profiles.wordpress.org/pixolin/\">Bego Mario Garde</a>, <a href=\"https://profiles.wordpress.org/utz119/\">Benachi</a>, <a href=\"https://profiles.wordpress.org/benoitchantre/\">Benoit Chantre</a>, <a href=\"https://profiles.wordpress.org/bernhard reiter/\">Bernhard Reiter</a>, <a href=\"https://profiles.wordpress.org/bernhard-reiter/\">Bernhard Reiter</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/bph/\">Birgit Pauli-Haack</a>, <a href=\"https://profiles.wordpress.org/blobfolio/\">Blobfolio</a>, <a href=\"https://profiles.wordpress.org/bmcculley/\">bmcculley</a>, <a href=\"https://profiles.wordpress.org/boblinthorst/\">Bob Linthorst</a>, <a href=\"https://profiles.wordpress.org/bobbingwide/\">bobbingwide</a>, <a href=\"https://profiles.wordpress.org/bogdanpreda/\">Bogdan Preda</a>, <a href=\"https://profiles.wordpress.org/gitlost/\">bonger</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/bradt/\">Brad Touesnard</a>, <a href=\"https://profiles.wordpress.org/kraftbj/\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/brechtvds/\">Brecht</a>, <a href=\"https://profiles.wordpress.org/brentswisher/\">Brent Swisher</a>, <a href=\"https://profiles.wordpress.org/brettshumaker/\">Brett Shumaker</a>, <a href=\"https://profiles.wordpress.org/ribaricplusplus/\">Bruno Ribaric</a>, <a href=\"https://profiles.wordpress.org/burhandodhy/\">Burhan Nasir</a>, <a href=\"https://profiles.wordpress.org/cameronjonesweb/\">Cameron Jones</a>, <a href=\"https://profiles.wordpress.org/cvoell/\">Cameron Voell</a>, <a href=\"https://profiles.wordpress.org/carike/\">Carike</a>, <a href=\"https://profiles.wordpress.org/carlalexander/\">Carl Alexander</a>, <a href=\"https://profiles.wordpress.org/carlomanf/\">carlomanf</a>, <a href=\"https://profiles.wordpress.org/carlosgprim/\">carlosgprim</a>, <a href=\"https://profiles.wordpress.org/poena/\">Carolina Nymark</a>, <a href=\"https://profiles.wordpress.org/caseymilne/\">Casey Milne</a>, <a href=\"https://profiles.wordpress.org/cenay/\">Cenay Nailor</a>, <a href=\"https://profiles.wordpress.org/ceyhun0/\">Ceyhun Ozugur</a>, <a href=\"https://profiles.wordpress.org/nhuja/\">Chandra M</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/chintan1896/\">Chintan hingrajiya</a>, <a href=\"https://profiles.wordpress.org/chipsnyder/\">Chip Snyder</a>, <a href=\"https://profiles.wordpress.org/cbringmann/\">Chloé Bringmann</a>, <a href=\"https://profiles.wordpress.org/chouby/\">Chouby</a>, <a href=\"https://profiles.wordpress.org/chrisvanpatten/\">Chris Van Patten</a>, <a href=\"https://profiles.wordpress.org/chriscct7/\">chriscct7</a>, <a href=\"https://profiles.wordpress.org/vimes1984/\">Christopher Churchill</a>, <a href=\"https://profiles.wordpress.org/ryno267/\">Chuck Reynolds</a>, <a href=\"https://profiles.wordpress.org/claytoncollie/\">Clayton Collie</a>, <a href=\"https://profiles.wordpress.org/codeamp/\">Code Amp</a>, <a href=\"https://profiles.wordpress.org/design_dolphin/\">CodePoet</a>, <a href=\"https://profiles.wordpress.org/costdev/\">Colin Stewart</a>, <a href=\"https://profiles.wordpress.org/collizo4sky/\">Collins Agbonghama</a>, <a href=\"https://profiles.wordpress.org/copons/\">Copons</a>, <a href=\"https://profiles.wordpress.org/coreymckrill/\">Corey McKrill</a>, <a href=\"https://profiles.wordpress.org/cr0ybot/\">Cory Hughart</a>, <a href=\"https://profiles.wordpress.org/courane01/\">Courtney Engle Robertson</a>, <a href=\"https://profiles.wordpress.org/crazycoders/\">crazycoders</a>, <a href=\"https://profiles.wordpress.org/critterverse/\">critterverse</a>, <a href=\"https://profiles.wordpress.org/czapla/\">czapla</a>, <a href=\"https://profiles.wordpress.org/davidszabo/\">Dávid Szabó</a>, <a href=\"https://profiles.wordpress.org/daisyo/\">Daisy Olsen</a>, <a href=\"https://profiles.wordpress.org/damonganto/\">damonganto</a>, <a href=\"https://profiles.wordpress.org/danfarrow/\">Dan Farrow</a>, <a href=\"https://profiles.wordpress.org/diddledan/\">Daniel Llewellyn</a>, <a href=\"https://profiles.wordpress.org/talldanwp/\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/danieldudzic/\">danieldudzic</a>, <a href=\"https://profiles.wordpress.org/mte90/\">Daniele Scasciafratte</a>, <a href=\"https://profiles.wordpress.org/vetyst/\">Danny</a>, <a href=\"https://profiles.wordpress.org/davilera/\">David Aguilera</a>, <a href=\"https://profiles.wordpress.org/davidanderson/\">David Anderson</a>, <a href=\"https://profiles.wordpress.org/dartiss/\">David Artiss</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/davidbinda/\">David Biňovec</a>, <a href=\"https://profiles.wordpress.org/dpcalhoun/\">David Calhoun</a>, <a href=\"https://profiles.wordpress.org/dlh/\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/davidkryzaniak/\">David Kryzaniak</a>, <a href=\"https://profiles.wordpress.org/get_dave/\">David Smith</a>, <a href=\"https://profiles.wordpress.org/dekervit/\">dekervit</a>, <a href=\"https://profiles.wordpress.org/devle/\">devfle</a>, <a href=\"https://profiles.wordpress.org/devrekli/\">devrekli</a>, <a href=\"https://profiles.wordpress.org/dhruvkb/\">dhruvkb</a>, <a href=\"https://profiles.wordpress.org/dianeco/\">Diane Co</a>, <a href=\"https://profiles.wordpress.org/dingdang/\">dingdang</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/djbu/\">djbu</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/donmhico/\">donmhico</a>, <a href=\"https://profiles.wordpress.org/donnapep/\">Donna Peplinskie</a>, <a href=\"https://profiles.wordpress.org/dougwollison/\">Doug Wollison</a>, <a href=\"https://profiles.wordpress.org/dpik/\">dpik</a>, <a href=\"https://profiles.wordpress.org/dragongate/\">dragongate</a>, <a href=\"https://profiles.wordpress.org/drebbitsweb/\">Dreb Bits</a>, <a href=\"https://profiles.wordpress.org/drewapicture/\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/eatsleepcode/\">eatsleepcode</a>, <a href=\"https://profiles.wordpress.org/metalandcoffee/\">Ebonie Butler</a>, <a href=\"https://profiles.wordpress.org/ediamin/\">Edi Amin</a>, <a href=\"https://profiles.wordpress.org/itsjusteileen/\">Eileen Violini</a>, <a href=\"https://profiles.wordpress.org/ellatrix/\">Ella van Durpe</a>, <a href=\"https://profiles.wordpress.org/aliveic/\">Emil E</a>, <a href=\"https://profiles.wordpress.org/emarticor/\">Emilio Martinez</a>, <a href=\"https://profiles.wordpress.org/manooweb/\">Emmanuel Hesry</a>, <a href=\"https://profiles.wordpress.org/empatogen/\">empatogen</a>, <a href=\"https://profiles.wordpress.org/enej/\">Enej Bajgorić</a>, <a href=\"https://profiles.wordpress.org/nrqsnchz/\">Enrique Sánchez</a>, <a href=\"https://profiles.wordpress.org/epiqueras/\">epiqueras</a>, <a href=\"https://profiles.wordpress.org/kebbet/\">Erik</a>, <a href=\"https://profiles.wordpress.org/etoledom/\">etoledom</a>, <a href=\"https://profiles.wordpress.org/fabiankaegy/\">Fabian Kägy</a>, <a href=\"https://profiles.wordpress.org/fabianpimminger/\">Fabian Pimminger</a>, <a href=\"https://profiles.wordpress.org/gaambo/\">Fabian Todt</a>, <a href=\"https://profiles.wordpress.org/felipeelia/\">Felipe Elia</a>, <a href=\"https://profiles.wordpress.org/flixos90/\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/felixbaumgaertner/\">felixbaumgaertner</a>, <a href=\"https://profiles.wordpress.org/femkreations/\">Femy Praseeth</a>, <a href=\"https://profiles.wordpress.org/fijisunshine/\">fijisunshine</a>, <a href=\"https://profiles.wordpress.org/florianbrinkmann/\">Florian Brinkmann</a>, <a href=\"https://profiles.wordpress.org/mista-flo/\">Florian TIAR</a>, <a href=\"https://profiles.wordpress.org/francina/\">Francesca Marano</a>, <a href=\"https://profiles.wordpress.org/bueltge/\">Frank Bueltge</a>, <a href=\"https://profiles.wordpress.org/frosso1/\">frosso1 (a11n)</a>, <a href=\"https://profiles.wordpress.org/fullofcaffeine/\">fullofcaffeine</a>, <a href=\"https://profiles.wordpress.org/gab81/\">gab81</a>, <a href=\"https://profiles.wordpress.org/galbaras/\">Gal Baras</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/garyj/\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/geekpress/\">GeekPress</a>, <a href=\"https://profiles.wordpress.org/soulseekah/\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/geoffrey1963/\">Geoffrey</a>, <a href=\"https://profiles.wordpress.org/revgeorge/\">George Hotelling</a>, <a href=\"https://profiles.wordpress.org/mamaduka/\">George Mamadashvili</a>, <a href=\"https://profiles.wordpress.org/georgestephanis/\">George Stephanis</a>, <a href=\"https://profiles.wordpress.org/geriux/\">geriux</a>, <a href=\"https://profiles.wordpress.org/glendaviesnz/\">glendaviesnz</a>, <a href=\"https://profiles.wordpress.org/grantmkin/\">Grant M. Kinney</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">Greg Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/gregorlove/\">gRegor Morrill</a>, <a href=\"https://profiles.wordpress.org/priethor/\">Héctor Prieto</a>, <a href=\"https://profiles.wordpress.org/hannahmalcolm/\">Hannah Malcolm</a>, <a href=\"https://profiles.wordpress.org/happiryu/\">happiryu</a>, <a href=\"https://profiles.wordpress.org/hareesh-pillai/\">Hareesh</a>, <a href=\"https://profiles.wordpress.org/hazdiego/\">Haz</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">hedgefield</a>, <a href=\"https://profiles.wordpress.org/helen/\">Helen Hou-Sandí</a>, <a href=\"https://profiles.wordpress.org/hermpheus/\">Herm Martini</a>, <a href=\"https://profiles.wordpress.org/herregroen/\">Herre Groen</a>, <a href=\"https://profiles.wordpress.org/herrvigg/\">herrvigg</a>, <a href=\"https://profiles.wordpress.org/htmgarcia/\">htmgarcia</a>, <a href=\"https://profiles.wordpress.org/iandunn/\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ianmjones/\">ianmjones</a>, <a href=\"https://profiles.wordpress.org/icopydoc/\">icopydoc</a>, <a href=\"https://profiles.wordpress.org/ipstenu/\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/isabel_brison/\">Isabel Brison</a>, <a href=\"https://profiles.wordpress.org/dragunoff/\">Ivaylo Draganov</a>, <a href=\"https://profiles.wordpress.org/wphound/\">Ivete Tecedor</a>, <a href=\"https://profiles.wordpress.org/jdgrimes/\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jacklenox/\">Jack Lenox</a>, <a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a>, <a href=\"https://profiles.wordpress.org/jamesbonham/\">James Bonham</a>, <a href=\"https://profiles.wordpress.org/jameskoster/\">James Koster</a>, <a href=\"https://profiles.wordpress.org/jnylen0/\">James Nylen</a>, <a href=\"https://profiles.wordpress.org/pondermatic/\">James Richards</a>, <a href=\"https://profiles.wordpress.org/jamesros161/\">James Rosado</a>, <a href=\"https://profiles.wordpress.org/jamil95/\">jamil95</a>, <a href=\"https://profiles.wordpress.org/janak007/\">janak Kaneriya</a>, <a href=\"https://profiles.wordpress.org/janwoostendorp/\">janw.oostendorp</a>, <a href=\"https://profiles.wordpress.org/jsnjohnston/\">Jason Johnston</a>, <a href=\"https://profiles.wordpress.org/javiarce/\">Javier Arce</a>, <a href=\"https://profiles.wordpress.org/jaymanpandya/\">Jayman Pandya</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jean-Baptiste Audras</a>, <a href=\"https://profiles.wordpress.org/jffng/\">Jeff Ong</a>, <a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeff Paul</a>, <a href=\"https://profiles.wordpress.org/jeffikus/\">Jeffrey Pearce</a>, <a href=\"https://profiles.wordpress.org/jdy68/\">Jenny Dupuy</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jeherve/\">Jeremy Herve</a>, <a href=\"https://profiles.wordpress.org/jeremyyip/\">Jeremy Yip</a>, <a href=\"https://profiles.wordpress.org/jeremy80/\">jeremy80</a>, <a href=\"https://profiles.wordpress.org/jeroenreumkens/\">JeroenReumkens</a>, <a href=\"https://profiles.wordpress.org/jeryj/\">jeryj</a>, <a href=\"https://profiles.wordpress.org/jillebehm/\">jillebehm</a>, <a href=\"https://profiles.wordpress.org/jipmoors/\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/sephsekla/\">Joe Bailey-Roberts</a>, <a href=\"https://profiles.wordpress.org/joedolson/\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/jonkastonka/\">Johan Jonk Stenström</a>, <a href=\"https://profiles.wordpress.org/goaroundagain/\">Johannes Kinast</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnny5/\">John Godley</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/bhwebworks/\">John Sundberg</a>, <a href=\"https://profiles.wordpress.org/jb510/\">Jon Brown</a>, <a href=\"https://profiles.wordpress.org/jonsurrell/\">Jon Surrell</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jonoaldersonwp/\">Jono Alderson</a>, <a href=\"https://profiles.wordpress.org/joostdevalk/\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/koke/\">Jorge Bernal</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/joseeyoast/\">Josee Wouters</a>, <a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha Haden</a>, <a href=\"https://profiles.wordpress.org/dkampdesign/\">JoshuaDoshua</a>, <a href=\"https://profiles.wordpress.org/joyously/\">Joy</a>, <a href=\"https://profiles.wordpress.org/jsnajdr/\">jsnajdr</a>, <a href=\"https://profiles.wordpress.org/juanfra/\">Juan Aldasoro</a>, <a href=\"https://profiles.wordpress.org/jrf/\">Juliette Reinders Folmer</a>, <a href=\"https://profiles.wordpress.org/juliobox/\">Julio Potier</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/k3nsai/\">k3nsai</a>, <a href=\"https://profiles.wordpress.org/kaavyaiyer/\">kaavyaiyer</a>, <a href=\"https://profiles.wordpress.org/kevin940726/\">Kai Hao</a>, <a href=\"https://profiles.wordpress.org/akabarikalpesh/\">Kalpesh Akabari</a>, <a href=\"https://profiles.wordpress.org/vyskoczilova/\">Karolina Vyskocilova</a>, <a href=\"https://profiles.wordpress.org/ryelle/\">Kelly Choyce-Dwan</a>, <a href=\"https://profiles.wordpress.org/kellychoffman/\">Kelly Hoffman</a>, <a href=\"https://profiles.wordpress.org/gwwar/\">Kerry Liu</a>, <a href=\"https://profiles.wordpress.org/kishanjasani/\">Kishan Jasani</a>, <a href=\"https://profiles.wordpress.org/ixkaito/\">Kite</a>, <a href=\"https://profiles.wordpress.org/kittmedia/\">KittMedia</a>, <a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a>, <a href=\"https://profiles.wordpress.org/klevyke/\">klevyke</a>, <a href=\"https://profiles.wordpress.org/knutsp/\">Knut Sparhell</a>, <a href=\"https://profiles.wordpress.org/vdwijngaert/\">Koen Van den Wijngaert</a>, <a href=\"https://profiles.wordpress.org/obenland/\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/xkon/\">Konstantinos Xenos</a>, <a href=\"https://profiles.wordpress.org/devnel/\">Kyle Nel</a>, <a href=\"https://profiles.wordpress.org/lakrisgubben/\">lakrisgubben</a>, <a href=\"https://profiles.wordpress.org/notlaura/\">Lara Schenck</a>, <a href=\"https://profiles.wordpress.org/lmurillom/\">Larissa Murillo</a>, <a href=\"https://profiles.wordpress.org/laxman-prajapati/\">Laxman Prajapati</a>, <a href=\"https://profiles.wordpress.org/lewiscowles/\">LewisCowles</a>, <a href=\"https://profiles.wordpress.org/lifeforceinst/\">lifeforceinst</a>, <a href=\"https://profiles.wordpress.org/linux4me2/\">linux4me2</a>, <a href=\"https://profiles.wordpress.org/lovor/\">Lovro Hrust</a>, <a href=\"https://profiles.wordpress.org/displaynone/\">Luis Sacristán</a>, <a href=\"https://profiles.wordpress.org/infolu/\">Luiz Araújo</a>, <a href=\"https://profiles.wordpress.org/lukecarbis/\">Luke Carbis</a>, <a href=\"https://profiles.wordpress.org/m0ze/\">m0ze</a>, <a href=\"https://profiles.wordpress.org/maedahbatool/\">Maedah Batool</a>, <a href=\"https://profiles.wordpress.org/onemaggie/\">Maggie Cabrera</a>, <a href=\"https://profiles.wordpress.org/travel_girl/\">Maja Benke</a>, <a href=\"https://profiles.wordpress.org/mciampini/\">Marco Ciampini</a>, <a href=\"https://profiles.wordpress.org/mkaz/\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/marekhrabe/\">Marek Hrabe</a>, <a href=\"https://profiles.wordpress.org/tyxla/\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/markjaquith/\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/markparnell/\">Mark Parnell</a>, <a href=\"https://profiles.wordpress.org/markoheijnen/\">Marko Heijnen</a>, <a href=\"https://profiles.wordpress.org/m-e-h/\">Marty Helmick</a>, <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>, <a href=\"https://profiles.wordpress.org/mariaojob/\">Mary Job</a>, <a href=\"https://profiles.wordpress.org/marylauc/\">marylauc</a>, <a href=\"https://profiles.wordpress.org/imath/\">Mathieu Viet</a>, <a href=\"https://profiles.wordpress.org/matveb/\">Matias Ventura</a>, <a href=\"https://profiles.wordpress.org/mattchowning/\">Matt Chowning</a>, <a href=\"https://profiles.wordpress.org/matt/\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/maxpertici/\">Maxime Pertici</a>, <a href=\"https://profiles.wordpress.org/mblach/\">mblach</a>, <a href=\"https://profiles.wordpress.org/immeet94/\">Meet Makadia</a>, <a href=\"https://profiles.wordpress.org/meher/\">Meher Bala</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce-Dwan</a>, <a href=\"https://profiles.wordpress.org/meloniq/\">meloniq</a>, <a href=\"https://profiles.wordpress.org/mensmaximus/\">mensmaximus</a>, <a href=\"https://profiles.wordpress.org/mbabker/\">Michael Babker</a>, <a href=\"https://profiles.wordpress.org/tw2113/\">Michael Beckwith</a>, <a href=\"https://profiles.wordpress.org/mcsf/\">Miguel Fonseca</a>, <a href=\"https://profiles.wordpress.org/simison/\">Mikael Korpela</a>, <a href=\"https://profiles.wordpress.org/mikehansenme/\">Mike Hansen</a>, <a href=\"https://profiles.wordpress.org/mikejolley/\">Mike Jolley</a>, <a href=\"https://profiles.wordpress.org/mike_cowobo/\">Mike Martel</a>, <a href=\"https://profiles.wordpress.org/mikeschroder/\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mihdan/\">Mikhail Kobzarev</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/milana_cap/\">Milana Cap</a>, <a href=\"https://profiles.wordpress.org/mkdgs/\">mkdgs</a>, <a href=\"https://profiles.wordpress.org/mmuyskens/\">mmuyskens</a>, <a href=\"https://profiles.wordpress.org/mmxxi/\">mmxxi</a>, <a href=\"https://profiles.wordpress.org/daddou/\">Mohamed El Amine DADDOU</a>, <a href=\"https://profiles.wordpress.org/mohamedfaragallah/\">Mohammed Faragallah</a>, <a href=\"https://profiles.wordpress.org/monikarao/\">Monika Rao</a>, <a href=\"https://profiles.wordpress.org/mor10/\">Morten Rand-Hendriksen</a>, <a href=\"https://profiles.wordpress.org/mrjoeldean/\">mrjoeldean</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/munyagu/\">munyagu</a>, <a href=\"https://profiles.wordpress.org/m_uysl/\">Mustafa Uysal</a>, <a href=\"https://profiles.wordpress.org/mweichert/\">mweichert</a>, <a href=\"https://profiles.wordpress.org/assassinateur/\">Nadir Seghir</a>, <a href=\"https://profiles.wordpress.org/nalininonstopnewsuk/\">Nalini Thakor</a>, <a href=\"https://profiles.wordpress.org/naoki0h/\">Naoki Ohashi</a>, <a href=\"https://profiles.wordpress.org/nao/\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/nayanchamp7/\">Nazrul Islam Nayan</a>, <a href=\"https://profiles.wordpress.org/dway/\">nderambure</a>, <a href=\"https://profiles.wordpress.org/krstarica/\">net</a>, <a href=\"https://profiles.wordpress.org/nicegamer7/\">nicegamer7</a>, <a href=\"https://profiles.wordpress.org/eidolonnight/\">Nicholas Garofalo</a>, <a href=\"https://profiles.wordpress.org/celloexpressions/\">Nick Halsey</a>, <a href=\"https://profiles.wordpress.org/ntsekouras/\">Nik Tsekouras</a>, <a href=\"https://profiles.wordpress.org/ninanmnm/\">ninanmnm</a>, <a href=\"https://profiles.wordpress.org/pianist787/\">Noah Allen</a>, <a href=\"https://profiles.wordpress.org/nvartolomei/\">nvartolomei</a>, <a href=\"https://profiles.wordpress.org/oguzkocer/\">oguzkocer</a>, <a href=\"https://profiles.wordpress.org/olafklejnstrupjensen/\">olafklejnstrupjensen</a>, <a href=\"https://profiles.wordpress.org/olgabulat/\">Olga Bulat</a>, <a href=\"https://profiles.wordpress.org/oglekler/\">Olga Gleckler</a>, <a href=\"https://profiles.wordpress.org/otshelnik-fm/\">Otshelnik-Fm</a>, <a href=\"https://profiles.wordpress.org/oxyrealm/\">oxyrealm</a>, <a href=\"https://profiles.wordpress.org/ozh/\">Ozh</a>, <a href=\"https://profiles.wordpress.org/paaljoachim/\">Paal Joachim Romdahl</a>, <a href=\"https://profiles.wordpress.org/palmiak/\">palmiak</a>, <a href=\"https://profiles.wordpress.org/paaggeli/\">Panagiotis Angelidis</a>, <a href=\"https://profiles.wordpress.org/paragoninitiativeenterprises/\">Paragon Initiative Enterprises</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/fantasy1125/\">Pascal Knecht</a>, <a href=\"https://profiles.wordpress.org/patkemper/\">Pat</a>, <a href=\"https://profiles.wordpress.org/patricklindsay/\">patricklindsay</a>, <a href=\"https://profiles.wordpress.org/kapilpaul/\">Paul</a>, <a href=\"https://profiles.wordpress.org/pbiron/\">Paul Biron</a>, <a href=\"https://profiles.wordpress.org/pabline/\">Paul Bunkham</a>, <a href=\"https://profiles.wordpress.org/paulschreiber/\">Paul Schreiber</a>, <a href=\"https://profiles.wordpress.org/paulstonier/\">Paul Stonier</a>, <a href=\"https://profiles.wordpress.org/pschrottky/\">Paul Von Schrottky</a>, <a href=\"https://profiles.wordpress.org/psrpinto/\">Paulo Pinto</a>, <a href=\"https://profiles.wordpress.org/pavelvisualcomposer/\">Pavel I</a>, <a href=\"https://profiles.wordpress.org/mrpauloen/\">Paweł</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/walbo/\">Petter Walbø Johnsgård</a>, <a href=\"https://profiles.wordpress.org/phena109/\">phena109</a>, <a href=\"https://profiles.wordpress.org/philipmjackson/\">Philip Jackson</a>, <a href=\"https://profiles.wordpress.org/wppinar/\">Pinar</a>, <a href=\"https://profiles.wordpress.org/boniu91/\">Piotrek Boniu</a>, <a href=\"https://profiles.wordpress.org/mordauk/\">Pippin Williamson</a>, <a href=\"https://profiles.wordpress.org/ptahdunbar/\">Pirate Dunbar</a>, <a href=\"https://profiles.wordpress.org/promz/\">Pramod Jodhani</a>, <a href=\"https://profiles.wordpress.org/presskopp/\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/presstoke/\">presstoke</a>, <a href=\"https://profiles.wordpress.org/pwallner/\">pwallner</a>, <a href=\"https://profiles.wordpress.org/pyronaur/\">pyronaur</a>, <a href=\"https://profiles.wordpress.org/itsjonq/\">Q</a>, <a href=\"https://profiles.wordpress.org/rachelbaker/\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rafhun/\">rafhun</a>, <a href=\"https://profiles.wordpress.org/rkradadiya/\">Rajesh Radadiya</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/rahmohn/\">Ramon Ahnert</a>, <a href=\"https://profiles.wordpress.org/ramonopoly/\">ramonopoly</a>, <a href=\"https://profiles.wordpress.org/jontyravi/\">Ravi Vaghela</a>, <a href=\"https://profiles.wordpress.org/ravipatel/\">ravipatel</a>, <a href=\"https://profiles.wordpress.org/rellect/\">Refael Iliaguyev</a>, <a href=\"https://profiles.wordpress.org/renehermi/\">Rene Hermenau</a>, <a href=\"https://profiles.wordpress.org/retrofox/\">retrofox</a>, <a href=\"https://profiles.wordpress.org/reynhartono/\">reynhartono</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/rianrietveld/\">Rian Rietveld</a>, <a href=\"https://profiles.wordpress.org/rima1889/\">Rima Prajapati</a>, <a href=\"https://profiles.wordpress.org/rinatkhaziev/\">Rinat</a>, <a href=\"https://profiles.wordpress.org/rnaby/\">Rnaby</a>, <a href=\"https://profiles.wordpress.org/robdxw/\">robdxw</a>, <a href=\"https://profiles.wordpress.org/noisysocks/\">Robert Anderson</a>, <a href=\"https://profiles.wordpress.org/miqrogroove/\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/rogertheriault/\">Roger Theriault</a>, <a href=\"https://profiles.wordpress.org/rogerlos/\">rogerlos</a>, <a href=\"https://profiles.wordpress.org/roo2/\">roo2</a>, <a href=\"https://profiles.wordpress.org/lev0/\">Roy</a>, <a href=\"https://profiles.wordpress.org/geekstreetwp/\">Russell Aaron</a>, <a href=\"https://profiles.wordpress.org/rmccue/\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/welcher/\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/soean/\">Sören Wrede</a>, <a href=\"https://profiles.wordpress.org/stodorovic/\">Saša</a>, <a href=\"https://profiles.wordpress.org/sabrinazeidan/\">Sabrina Zeidan</a>, <a href=\"https://profiles.wordpress.org/sahilmepani/\">Sahil Mepani</a>, <a href=\"https://profiles.wordpress.org/solarissmoke/\">Samir Shah</a>, <a href=\"https://profiles.wordpress.org/otto42/\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/sandipmondal/\">Sandip Mondal</a>, <a href=\"https://profiles.wordpress.org/sannevndrmeulen/\">Sanne van der Meulen</a>, <a href=\"https://profiles.wordpress.org/sarahricker/\">sarahricker</a>, <a href=\"https://profiles.wordpress.org/sarayourfriend/\">sarayourfriend</a>, <a href=\"https://profiles.wordpress.org/sasagar/\">SASAPIYO</a>, <a href=\"https://profiles.wordpress.org/satrancali/\">satrancali</a>, <a href=\"https://profiles.wordpress.org/savicmarko1985/\">savicmarko1985</a>, <a href=\"https://profiles.wordpress.org/gmagicscott/\">Scott Lesovic</a>, <a href=\"https://profiles.wordpress.org/coffee2code/\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/scottconnerly/\">scottconnerly</a>, <a href=\"https://profiles.wordpress.org/scruffian/\">scruffian</a>, <a href=\"https://profiles.wordpress.org/sean212/\">Sean Fisher</a>, <a href=\"https://profiles.wordpress.org/seanchayes/\">Sean Hayes</a>, <a href=\"https://profiles.wordpress.org/sebbb/\">sebbb</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/yakimun/\">Sergey Yakimov</a>, <a href=\"https://profiles.wordpress.org/sergioestevao/\">SergioEstevao</a>, <a href=\"https://profiles.wordpress.org/sergiomdgomes/\">sergiomdgomes</a>, <a href=\"https://profiles.wordpress.org/shaunandrews/\">shaunandrews</a>, <a href=\"https://profiles.wordpress.org/shital-patel/\">Shital Marakana</a>, <a href=\"https://profiles.wordpress.org/silb3r/\">silb3r</a>, <a href=\"https://profiles.wordpress.org/siobhyb/\">Siobhan</a>, <a href=\"https://profiles.wordpress.org/sirstuey/\">SirStuey</a>, <a href=\"https://profiles.wordpress.org/snapfractalpop/\">snapfractalpop</a>, <a href=\"https://profiles.wordpress.org/spikeuk1/\">spikeuk1</a>, <a href=\"https://profiles.wordpress.org/spytzo/\">spytzo</a>, <a href=\"https://profiles.wordpress.org/stacimc/\">stacimc</a>, <a href=\"https://profiles.wordpress.org/khromov/\">Stanislav Khromov</a>, <a href=\"https://profiles.wordpress.org/deustron/\">Stefan Hüsges</a>, <a href=\"https://profiles.wordpress.org/stefanjoebstl/\">stefanjoebstl</a>, <a href=\"https://profiles.wordpress.org/ryokuhi/\">Stefano Minoia</a>, <a href=\"https://profiles.wordpress.org/hypest/\">Stefanos Togoulidis</a>, <a href=\"https://profiles.wordpress.org/sabernhardt/\">Stephen Bernhardt</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/dufresnesteven/\">Steve Dufresne</a>, <a href=\"https://profiles.wordpress.org/stevegrunwell/\">Steve Grunwell</a>, <a href=\"https://profiles.wordpress.org/stevehenty/\">Steve Henty</a>, <a href=\"https://profiles.wordpress.org/stevenkword/\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/strategio/\">strategio</a>, <a href=\"https://profiles.wordpress.org/subrataemfluence/\">Subrata Sarkar</a>, <a href=\"https://profiles.wordpress.org/sumaiyasiddika/\">Sumaiya Siddika</a>, <a href=\"https://profiles.wordpress.org/sumanm/\">Suman</a>, <a href=\"https://profiles.wordpress.org/sumitsingh/\">Sumit Singh</a>, <a href=\"https://profiles.wordpress.org/5um17/\">Sumit Singh</a>, <a href=\"https://profiles.wordpress.org/sushmak/\">sushmak</a>, <a href=\"https://profiles.wordpress.org/cybr/\">Sybre Waaijer</a>, <a href=\"https://profiles.wordpress.org/synchro/\">Synchro</a>, <a href=\"https://profiles.wordpress.org/szaqal21/\">szaqal21</a>, <a href=\"https://profiles.wordpress.org/tamlyn/\">tamlyn</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/tellyworth/\">Tellyworth</a>, <a href=\"https://profiles.wordpress.org/terriann/\">Terri Ann</a>, <a href=\"https://profiles.wordpress.org/wildworks/\">Tetsuaki Hamano</a>, <a href=\"https://profiles.wordpress.org/themes-1/\">them.es</a>, <a href=\"https://profiles.wordpress.org/kraftner/\">Thomas Kräftner</a>, <a href=\"https://profiles.wordpress.org/thomasplevy/\">Thomas Patrick Levy</a>, <a href=\"https://profiles.wordpress.org/thomas-vitale/\">Thomas Vitale</a>, <a href=\"https://profiles.wordpress.org/tigertech/\">tigertech</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/timotijhof/\">TimoTijhof</a>, <a href=\"https://profiles.wordpress.org/tkama/\">Tkama</a>, <a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/tmdk/\">tmdk</a>, <a href=\"https://profiles.wordpress.org/tz-media/\">Tobias Zimpel</a>, <a href=\"https://profiles.wordpress.org/tobiasbg/\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tobifjellner/\">tobifjellner (Tor-Bjorn Fjellner)</a>, <a href=\"https://profiles.wordpress.org/tjnowell/\">Tom J Nowell</a>, <a href=\"https://profiles.wordpress.org/skithund/\">Toni Viemerö</a>, <a href=\"https://profiles.wordpress.org/hellofromtonya/\">Tonya Mork</a>, <a href=\"https://profiles.wordpress.org/toro_unit/\">Toro_Unit (Hiroshi Urabe)</a>, <a href=\"https://profiles.wordpress.org/torres126/\">torres126</a>, <a href=\"https://profiles.wordpress.org/zodiac1978/\">Torsten Landsiedel</a>, <a href=\"https://profiles.wordpress.org/toru/\">Toru Miki</a>, <a href=\"https://profiles.wordpress.org/travisnorthcutt/\">Travis Northcutt</a>, <a href=\"https://profiles.wordpress.org/trejder/\">trejder</a>, <a href=\"https://profiles.wordpress.org/desaiuditd/\">Udit Desai</a>, <a href=\"https://profiles.wordpress.org/grapplerulrich/\">Ulrich</a>, <a href=\"https://profiles.wordpress.org/utsav72640/\">Utsav tilava</a>, <a href=\"https://profiles.wordpress.org/vcanales/\">Vicente Canales</a>, <a href=\"https://profiles.wordpress.org/vipulc2/\">Vipul Chandel</a>, <a href=\"https://profiles.wordpress.org/vladytimy/\">Vlad T</a>, <a href=\"https://profiles.wordpress.org/wangql/\">wangql</a>, <a href=\"https://profiles.wordpress.org/webdragon/\">WebDragon</a>, <a href=\"https://profiles.wordpress.org/wendyjchen/\">Wendy Chen</a>, <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/williampatton/\">williampatton</a>, <a href=\"https://profiles.wordpress.org/xavivars/\">Xavi Ivars</a>, <a href=\"https://profiles.wordpress.org/tikifez/\">Xristopher Anderton</a>, <a href=\"https://profiles.wordpress.org/y_kolev/\">Y_Kolev</a>, <a href=\"https://profiles.wordpress.org/yansern/\">Yan Sern</a>, <a href=\"https://profiles.wordpress.org/fierevere/\">Yui</a>, <a href=\"https://profiles.wordpress.org/yuliyan/\">yuliyan</a>, <a href=\"https://profiles.wordpress.org/yvettesonneveld/\">Yvette Sonneveld</a>, <a href=\"https://profiles.wordpress.org/zackkrida/\">Zack Krida</a>, <a href=\"https://profiles.wordpress.org/zebulan/\">Zebulan Stanphill</a>, <a href=\"https://profiles.wordpress.org/zkancs/\">zkancs</a>, and <a href=\"https://profiles.wordpress.org/sunxiyuan/\">孙锡源</a>.</p>



<p>これらの貢献者に加えて、<a href=\"https://wordpress.org/support/\">サポートフォーラム</a>で貢献されているコミュニティボランティアの皆さんにも感謝いたします。彼らは、WordPress 初心者から、2003年最初のリリースの頃からの利用者まで、世界中の人々の質問に答えてくれています。リリースが成功しているのは、彼らの努力のおかげです！</p>



<p>最後に、リリースごとに 200 以上の言語で WordPress を利用可能にしてくださっているコミュニティ翻訳者の皆さんに感謝いたします。80 の言語で WordPress 5.8 の 80% 以上が翻訳されており、コミュニティの翻訳者達は、さらに多くの言語に対応できるようハードワークで作業を行なっています。WordPress への貢献に魅力を感じた方は、簡単に詳細を知ることができますので <a href=\"https://make.wordpress.org/\">Make WordPress</a> や<a href=\"https://make.wordpress.org/core/\">コア開発ブログ</a>をチェックしてみてください。</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress 5.8 リリース候補 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://ja.wordpress.org/2021/07/14/wordpress-5-8-release-candidate-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Jul 2021 07:57:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6291\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:216:\"以下は、Jeffrey Paul が書いた WordPress.org 公式ブログの記事「WordPress 5.8 Release Candidate 3」を訳したものです。 誤字脱字誤訳などありましたらフォーラムまで [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Seisuke Kuraishi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3862:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeffrey Paul</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2021/07/wordpress-5-8-release-candidate-3/\">WordPress 5.8 Release Candidate 3</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p><a href=\"https://make.wordpress.org/core/5-8/\">WordPress 5.8</a> の3番目のリリース候補が公開されました！ <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/1f389.png\" alt=\"🎉\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>WordPress 5.8 は、<strong>2021年7月20日</strong>にリリースされる予定ですが、そのためには皆様の協力が必要です。まだ 5.8 を試していないなら今がその時です！</p>



<p>WordPress 5.8 リリース候補 3 のテストは、次の3つの方法で行うことができます。</p>



<ul><li><a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester プラグイン</a> をインストールして有効化する（「最前線」チャンネルと「ベータ / RC のみ」ストリームを選択）。</li><li>リリース候補<a href=\"https://wordpress.org/wordpress-5.8-RC3.zip\">（zip 形式）</a>を直接ダウンロードする。</li><li>WP-CLI を使用: <code>wp core update --version=5.8-RC3</code></li></ul>



<p>ベータ・RC版をテストし、フィードバックをくださったすべての貢献者の皆様に感謝いたします。バグのテストは、リリースに磨きをかけるための重要な作業であり WordPress に貢献するための素晴らしい方法です。</p>



<h2 id=\"プラグイン・テーマ開発者の方へ\">プラグイン・テーマ開発者の方へ</h2>



<p>WordPress 5.8 でプラグインやテーマのテストを行い、<code>readme</code> ファイルの <em>Tested up to</em> バージョンを 5.8 に更新してください。互換性の問題を見つけた場合は、最終リリース前に解決できるよう、必ず<a href=\"https://wordpress.org/support/forum/alphabeta/\">サポートフォーラム</a>に投稿してください。</p>



<p>WordPress 5.8 に含まれる変更点の詳細については、<a href=\"https://ja.wordpress.org/2021/06/13/wordpress-5-8-beta-1/\">WordPress 5.8 ベータ 1</a> の記事をご覧ください。<a href=\"https://make.wordpress.org/core/2021/07/03/wordpress-5-8-field-guide/\">WordPress 5.8 フィールドガイド</a>は、特に開発者の方に役立つもので、大きな変更点に対応するための情報やリンクが掲載されています。</p>



<h2 id=\"ご協力いただけること\">ご協力いただけること</h2>



<p>英語以外の言語で話したり書いたりすることができますか？ WordPress の<a href=\"https://translate.wordpress.org/projects/wp/dev\">100言語を超す翻訳にご協力ください</a>！</p>



<p><strong>バグを見つけた場合は</strong>、サポートフォーラムの<a href=\"https://wordpress.org/support/forum/alphabeta/\">アルファ・ベータエリア</a>に投稿してください。情報をお待ちしています！再現可能なバグのレポートが書ける方は <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac に報告</a>してください。こちらでは<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ一覧</a>を確認できます。</p>



<p>（訳注: 貢献者、Haiku セクションは、<a href=\"https://wordpress.org/news/2021/07/wordpress-5-8-release-candidate-3/\">原文</a>を参照してください。）</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress 5.8 リリース候補 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://ja.wordpress.org/2021/07/07/wordpress-5-8-release-candidate-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Jul 2021 11:01:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6289\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:216:\"以下は、Jeffrey Paul が書いた WordPress.org 公式ブログの記事「WordPress 5.8 Release Candidate 2」を訳したものです。 誤字脱字誤訳などありましたらフォーラムまで [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Seisuke Kuraishi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3862:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeffrey Paul</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2021/07/wordpress-5-8-release-candidate-2/\">WordPress 5.8 Release Candidate 2</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p><a href=\"https://make.wordpress.org/core/5-8/\">WordPress 5.8</a> の2つ目のリリース候補が公開されました！ <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/1f389.png\" alt=\"🎉\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>WordPress 5.8 は、<strong>2021年7月20日</strong>にリリースされる予定ですが、そのためには皆様の協力が必要です。まだ 5.8 を試していないなら今がその時です！</p>



<p>WordPress 5.8 リリース候補 2 のテストは、次の3つの方法で行うことができます。</p>



<ul><li><a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester プラグイン</a> をインストールして有効化する（「最前線」チャンネルと「ベータ / RC のみ」ストリームを選択）。</li><li>リリース候補<a href=\"https://wordpress.org/wordpress-5.8-RC2.zip\">（zip 形式）</a>を直接ダウンロードする。</li><li>WP-CLI を使用: <code>wp core update --version=5.8-RC2</code></li></ul>



<p>ベータ・RC版をテストし、フィードバックをくださったすべての貢献者の皆様に感謝いたします。バグのテストは、リリースに磨きをかけるための重要な作業であり WordPress に貢献するための素晴らしい方法です。</p>



<h2 id=\"プラグイン・テーマ開発者の方へ\">プラグイン・テーマ開発者の方へ</h2>



<p>WordPress 5.8 でプラグインやテーマのテストを行い、<code>readme</code> ファイルの <em>Tested up to</em> バージョンを 5.8 に更新してください。互換性の問題を見つけた場合は、最終リリース前に解決できるよう、必ず<a href=\"https://wordpress.org/support/forum/alphabeta/\">サポートフォーラム</a>に投稿してください。</p>



<p>WordPress 5.8 に含まれる変更点の詳細については、<a href=\"https://ja.wordpress.org/2021/06/13/wordpress-5-8-beta-1/\">WordPress 5.8 ベータ 1</a> の記事をご覧ください。<a href=\"https://make.wordpress.org/core/2021/07/03/wordpress-5-8-field-guide/\">WordPress 5.8 フィールドガイド</a>は、特に開発者の方に役立つもので、大きな変更点に対応するための情報やリンクが掲載されています。</p>



<h2 id=\"ご協力いただけること\">ご協力いただけること</h2>



<p>英語以外の言語で話したり書いたりすることができますか？ WordPress の<a href=\"https://translate.wordpress.org/projects/wp/dev\">100言語を超す翻訳にご協力ください</a>！</p>



<p><strong>バグを見つけた場合は</strong>、サポートフォーラムの<a href=\"https://wordpress.org/support/forum/alphabeta/\">アルファ・ベータエリア</a>に投稿してください。情報をお待ちしています！再現可能なバグのレポートが書ける方は <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac に報告</a>してください。こちらでは<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ一覧</a>を確認できます。</p>



<p>（訳注: 貢献者、Haiku セクションは、<a href=\"https://wordpress.org/news/2021/07/wordpress-5-8-release-candidate-2/\">原文</a>を参照してください。）</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 5.8 リリース候補\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://ja.wordpress.org/2021/07/01/wordpress-5-8-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 30 Jun 2021 18:53:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6284\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:220:\"以下は、Jeffrey Paul が書いた WordPress.org 公式ブログの記事「WordPress 5.8 Release Candidate」を訳したものです。 誤字脱字誤訳などありましたらフォーラムまでお知 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Seisuke Kuraishi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5419:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeffrey Paul</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-release-candidate/\">WordPress 5.8 Release Candidate</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p><a href=\"https://make.wordpress.org/core/5-8/\">WordPress 5.8</a> 最初のリリース候補が公開されました！ <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/1f389.png\" alt=\"🎉\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>WordPress 5.8 最終リリースへと向かうコミュニティの重要な節目を共に祝いましょう！</p>



<p>「リリース候補」は、新しいバージョンがリリースできる状態であることを意味します。しかし、何千ものプラグインやテーマ、何百万人もの人々の WordPress の使い方の違いにより、何かを見落としている可能性があります。WordPress 5.8 は、<strong>2021年7月20日</strong>にリリースされる予定ですが、そのためには皆様の協力が必要です。まだ 5.8 を試していないなら<strong>今がその時です</strong>！</p>



<p>WordPress 5.8 リリース候補のテストは、次の3つの方法で行うことができます。</p>



<ul><li><a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester プラグイン</a> をインストールして有効化する（「最前線」チャンネルと「ベータ / RC のみ」ストリームを選択）。</li><li>リリース候補<a href=\"https://wordpress.org/wordpress-5.8-RC1.zip\">（zip 形式）</a>を直接ダウンロードする。</li><li>WP-CLI を使用: <code>wp core update --version=5.8-RC1</code></li></ul>



<p>ベータ版をテストし、フィードバックをくださったすべての貢献者の皆様に感謝いたします。バグのテストは、リリースに磨きをかけるための重要な作業であり WordPress に貢献するための素晴らしい方法です。</p>



<h2 id=\"wordpress-58-の概要\">WordPress 5.8 の概要</h2>



<p>2021年2番目のリリースでは、フルサイト編集の約束された未来に向けて、ブロックエディターを次のように進化させています。</p>



<ul><li>ブロックによるウィジェット管理</li><li>新しいブロックとパターンを使った投稿表示</li><li>投稿テンプレートの編集</li><li>ページ構成の概観</li><li>ブロックのパターン提案</li><li>画像のスタイルと色付け</li><li><code>theme.json</code></li><li>IE11 サポートの終了</li><li>WebP 対応</li><li>追加ブロックサポート</li><li>Gutenberg <a href=\"https://make.wordpress.org/core/2021/05/27/whats-new-in-gutenberg-10-7-26-may/\">バージョン 10.7</a></li></ul>



<p>WordPress 5.8 には、開発者の体験を向上させるための多くの改良が加えられています。詳しくは、<a href=\"https://make.wordpress.org/core/\">Make WordPress Core ブログ</a>を購読し、<a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">開発者ノートのタグ</a>を注視して、最新情報やご自身のプロダクトに影響を与える可能性のある変更を確認してください。</p>



<h2 id=\"プラグイン・テーマ開発者の方へ\">プラグイン・テーマ開発者の方へ</h2>



<p>WordPress 5.8 でプラグインやテーマのテストを行い、<code>readme</code> ファイルの <em>Tested up to</em> バージョンを 5.8 に更新してください。互換性の問題を見つけた場合は、最終リリース前に解決できるよう、必ず<a href=\"https://wordpress.org/support/forum/alphabeta/\">サポートフォーラム</a>に投稿してください。</p>



<p>WordPress 5.8 フィールドガイドが近日中に公開されますので、主要な変更点の詳細についてはそちらを参照してください。</p>



<h2 id=\"ご協力いただけること\">ご協力いただけること</h2>



<p>英語以外の言語が話せますか？ WordPress の<a href=\"https://translate.wordpress.org/projects/wp/dev\">100言語を超す翻訳にご協力ください</a>！このリリースは 5.8 リリーススケジュールにおける<a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">翻訳語句のハードフリーズ</a>（凍結）ポイントでもあります。</p>



<p>バグを見つけた場合は、サポートフォーラムの<a href=\"https://wordpress.org/support/forum/alphabeta/\">アルファ・ベータエリア</a>に投稿してください。情報をお待ちしています！再現可能なバグのレポートが書ける方は <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac に報告</a>してください。こちらでは<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ一覧</a>を確認できます。</p>



<p>（訳注: 貢献者、Haiku セクションは、<a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-release-candidate/\">原文</a>を参照してください。）</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"WordPress 5.8 ベータ 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ja.wordpress.org/2021/06/26/wordpress-5-8-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 26 Jun 2021 10:45:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6282\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:234:\"以下は、Jeffrey Paul が書いた WordPress.org 公式ブログの記事「WordPress 5.8 Beta 4」を訳したものです。 誤字脱字誤訳などありましたらフォーラムまでお知らせください。 Wor [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Seisuke Kuraishi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4750:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeffrey Paul</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-4/\">WordPress 5.8 Beta 4</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.8 ベータ 4 がテストいただけるようになりました。</p>



<p><strong>このソフトウェアはまだ開発中です</strong>ので、本番運用中のサイトでの利用はおすすめできません。テストサイトでの試用を検討してください。</p>



<p>WordPress 5.8 ベータ 4 のテストは、次の3つの方法で行うことができます。</p>



<ul><li><a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> プラグインをインストールして有効化する（「最前線」チャンネルと「ベータ / RC のみ」ストリームを選択）。</li><li><a href=\"https://wordpress.org/wordpress-5.8-beta4.zip\">ベータ版（zip 形式）</a>を直接ダウンロードする。</li><li>WP-CLI を使用: <code>wp core update --version=5.8-beta4</code></li></ul>



<p>正式リリースは、2021年7月20日を予定しています。<strong>4週間</strong>もありませんので、最終リリースを可能な限り良いものにするためには、皆様からの協力が必要です。</p>



<h2 id=\"ハイライト\">ハイライト</h2>



<p><a href=\"https://ja.wordpress.org/2021/06/23/wordpress-5-8-beta-3/\">ベータ 3</a> 以降、<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=06%2F24%2F2021..06%2F26%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">18 件</a>のバグが修正されました。チケットの多くは、既存デフォルトテーマの改善や、新しいブロックウィジェットの画面、ベータ版で集積されたエディターのバグ修正に関するものです。</p>



<h2 id=\"ご協力いただけること\">ご協力いただけること</h2>



<p><a href=\"https://make.wordpress.org/core/\">Make WordPress Core ブログ</a>では、今後数週間のうちに <a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8 関連の開発者向けノート</a>を公開し、詳細・その他変更点について詳しく説明していきますので、ぜひご覧ください。</p>



<p>現時点で、WordPress 5.8 では <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=..06%2F25%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">254 件のチケット</a>が修正されており、その中には <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;status=reopened&amp;changetime=..06%2F25%2F2021&amp;type=enhancement&amp;type=feature+request&amp;milestone=5.8&amp;group=component&amp;col=id&amp;col=summary&amp;col=type&amp;col=status&amp;col=milestone&amp;col=changetime&amp;col=owner&amp;col=priority&amp;col=keywords&amp;order=changetime\">91 件の新機能と強化</a>が含まれています。この後、さらにバグの修正が行われていきます。</p>



<p><strong>テストをしてください！</strong></p>



<p><a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">バグのテスト</a>は、ベータ段階でリリースに磨きをかけるための重要な作業であり WordPress に貢献するための素晴らしい方法です。<img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>バグを見つけた場合は、サポートフォーラムの <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta エリア</a>に投稿してください。情報をお待ちしています！再現可能な<a href=\"https://make.wordpress.org/core/reports/\">バグのレポート</a>が書ける方は <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac</a> に報告してください。こちらでは<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ</a>も確認できます。</p>



<p>（訳注: 貢献者、Haiku セクションは、<a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-4/\">原文</a>を参照してください。）</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Gutenberg ハイライト\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ja.wordpress.org/2021/06/24/gutenberg-highlights/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Jun 2021 01:31:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6270\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:171:\"先日開催された WordCamp Europe で共有した、Gutenberg プラグインの現在、そして今後のハイライトを紹介する動画をご紹介します。\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Naoko Takano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3392:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/matt/\"></a><a href=\"https://profiles.wordpress.org/chanthaboune/\"></a><a href=\"https://profiles.wordpress.org/cbringmann/\"><a href=\"https://profiles.wordpress.org/matveb/\">Matias Ventura</a></a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2020/04/wordpress-5-4-1/\"></a><a href=\"https://wordpress.org/news/2020/03/adderley/\"></a><a href=\"https://wordpress.org/news/2021/02/welcome-to-your-wp-briefing/\"></a><a href=\"https://wordpress.org/news/2021/02/gutenberg-tutorial-reusable-blocks/\"><a href=\"https://wordpress.org/news/2021/06/gutenberg-highlights/\">Gutenberg Highlights</a></a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>先日開催された <a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a> で、WordPress プロジェクトリードであるマットと一緒に <a href=\"https://ja.wordpress.org/plugins/gutenberg/\">Gutenberg プラグイン</a>の最新の開発状況について議論し、その現在、そして今後のハイライトを紹介する動画を共有しました。</p>



<p>このデモ動画のナレーションは <a href=\'https://profiles.wordpress.org/beafialho/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>beafialho</a> が担当し、WordPress の編集やカスタマイズ体験を向上させるために世界中で行われている貢献者たちの素晴らしい活動を認識する良い機会となりました。ライブに参加できなかった方のために、この動画がオンラインで視聴できるようになりました。</p>



<figure class=\"wp-block-embed is-type-video is-provider-videopress wp-block-embed-videopress wp-embed-aspect-4-3 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">
<iframe title=\"Matías Ventura, Beatriz Fialho: 2021 WordCamp Europe Gutenberg Demo\" width=\'612\' height=\'436\' src=\'https://video.wordpress.com/embed/yeQBBW2L?hd=1\' frameborder=\'0\' allowfullscreen></iframe><script src=\'https://v0.wordpress.com/js/next/videopress-iframe.js?m=1435166243\'></script>
</div></figure>



<p>動画で日本語または英語の字幕を表示するには、動画下部のキャプション機能をご利用ください。</p>



<figure class=\"wp-block-image size-large\"><a href=\"https://ja.wordpress.org/files/2021/06/videopress-caption.png\"><img loading=\"lazy\" width=\"1024\" height=\"162\" src=\"https://ja.wordpress.org/files/2021/06/videopress-caption-1024x162.png\" alt=\"\" class=\"wp-image-6276\" srcset=\"https://ja.wordpress.org/files/2021/06/videopress-caption-1024x162.png 1024w, https://ja.wordpress.org/files/2021/06/videopress-caption-300x47.png 300w, https://ja.wordpress.org/files/2021/06/videopress-caption-768x122.png 768w, https://ja.wordpress.org/files/2021/06/videopress-caption-1536x243.png 1536w, https://ja.wordpress.org/files/2021/06/videopress-caption.png 1914w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></a></figure>



<p>また、マットは<a href=\"https://ma.tt/2021/06/wceu-open-thread/\">自身のブログ</a>に質問用のスレッドを開いているので、質問があればぜひそこに書き込んでみてください。</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"WordPress 5.8 ベータ 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ja.wordpress.org/2021/06/23/wordpress-5-8-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Jun 2021 14:33:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=6274\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:234:\"以下は、Josepha が書いた WordPress.org 公式ブログの記事「WordPress 5.8 Beta 3」を訳したものです。 誤字脱字誤訳などありましたらフォーラムまでお知らせください。 WordPres [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Seisuke Kuraishi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6491:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha</a> が書いた WordPress.org 公式ブログの記事「<a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-3/\">WordPress 5.8 Beta 3</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.8 ベータ 3 がテストいただけるようになりました。</p>



<p><strong>このソフトウェアはまだ開発中です</strong>ので、本番運用中のサイトでの利用はおすすめできません。テストサイトでの試用を検討してください。</p>



<p>WordPress 5.8 ベータ 3 のテストは、次の3つの方法で行うことができます。</p>



<ul><li><a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> プラグインをインストールして有効化する（「最前線」チャンネルと「ベータ / RC のみ」ストリームを選択）。</li><li><a href=\"https://wordpress.org/wordpress-5.8-beta3.zip\">ベータ版（zip 形式）</a>を直接ダウンロードする。</li><li>WP-CLI を使用: <code>wp core update --version=5.8-beta3</code></li></ul>



<p>正式リリースは、2021年7月20日を予定しています。<strong>4週間後</strong>に迫っていますので、最終リリースを可能な限り良いものにするためには、皆様からの協力が必要です。</p>



<h2 id=\"ハイライト\">ハイライト</h2>



<p><a href=\"https://ja.wordpress.org/2021/06/17/wordpress-5-8-beta-2/\">ベータ 2</a> 以降、<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=06%2F16%2F2021..06%2F23%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">38 件</a>のバグが修正されました。その中のいくつかの変更点をまとめます。</p>



<ul><li>ブロックエディター: ユニークなレスポンスのために、キャッシングをエンドポイントに移動。 (<a href=\"https://core.trac.wordpress.org/ticket/53435\">#53435</a>)</li><li>同梱テーマ: ウィジェットエリアでのブロック表示の改善。 (<a href=\"https://core.trac.wordpress.org/ticket/53422\">#53422</a>)</li><li>コーディング規約: <code>wp-admin/comment.php</code> の HTML フォーマットに一貫性を持たせる。 (<a href=\"https://core.trac.wordpress.org/ticket/52627\">#52627</a>)</li><li>エディター: メタデータファイルから登録するブロックタイプのリストにカバーブロックを含める。 (<a href=\"https://core.trac.wordpress.org/ticket/53440\">#53440</a>)</li><li>メディア: 「前」「次」の添付ファイルのリンクを返す新機能を追加。 (<a href=\"https://core.trac.wordpress.org/ticket/45708\">#45708</a>)</li><li>メディア: 小さい画面でのアップロードページのメディアアイテムのレイアウトを改善。 (<a href=\"https://core.trac.wordpress.org/ticket/51754\">#51754</a>)</li><li>メディア: メディアが追加・削除された時に添付ファイルの総数を更新。 (<a href=\"https://core.trac.wordpress.org/ticket/53171\">#53171</a>)</li><li>REST API: ウィジェットの名前と説明に含まれるシングル・ダブルクオートのエンティティをデコード。 (<a href=\"https://core.trac.wordpress.org/ticket/53407\">#53407</a>)</li><li>Twenty Nineteen: エディターで全幅・幅広のブロックのマージンを更新。 (<a href=\"https://core.trac.wordpress.org/ticket/53428\">#53428</a>)</li><li>ウィジェット: ウィジェットブロックエディターにエディタースタイルを追加。 (<a href=\"https://core.trac.wordpress.org/ticket/53344\">#53344</a>)</li></ul>



<h2 id=\"ご協力いただけること\">ご協力いただけること</h2>



<p><a href=\"https://make.wordpress.org/core/\">Make WordPress Core ブログ</a>では、今後数週間のうちに <a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8 関連の開発者向けノート</a>を公開し、詳細・その他変更点について詳しく説明していきますので、ぜひご覧ください。</p>



<p>現時点で、WordPress 5.8 では <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=..06%2F23%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">254 件のチケット</a>が修正されており、その中には <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;status=reopened&amp;changetime=..06%2F23%2F2021&amp;type=enhancement&amp;type=feature+request&amp;milestone=5.8&amp;group=component&amp;col=id&amp;col=summary&amp;col=type&amp;col=status&amp;col=milestone&amp;col=changetime&amp;col=owner&amp;col=priority&amp;col=keywords&amp;order=changetime\">91 件の新機能と強化</a>が含まれています。この後、さらにバグの修正が行われていきます。</p>



<p><strong>テストをしてください！</strong></p>



<p><a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">バグのテスト</a>は、ベータ段階でリリースに磨きをかけるための重要な作業であり WordPress に貢献するための素晴らしい方法です。<img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>バグを見つけた場合は、サポートフォーラムの <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta エリア</a>に投稿してください。情報をお待ちしています！再現可能な<a href=\"https://make.wordpress.org/core/reports/\">バグのレポート</a>が書ける方は <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac</a> に報告してください。こちらでは<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ</a>も確認できます。</p>



<p>（訳注: 貢献者、Haiku セクションは、<a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-3/\">原文</a>を参照してください。）</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://ja.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 02 Sep 2021 16:41:27 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Mon, 15 Jun 2020 00:12:19 GMT\";s:4:\"link\";s:61:\"<https://ja.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20210725171650\";}","no");
INSERT INTO `wp20210827044706_options` VALUES("367","_transient_timeout_feed_mod_992efac292246ae35bf235a03417a202","1630644088","no");
INSERT INTO `wp20210827044706_options` VALUES("368","_transient_feed_mod_992efac292246ae35bf235a03417a202","1630600888","no");
INSERT INTO `wp20210827044706_options` VALUES("369","_transient_timeout_feed_6f409681938158427d2ded6eb1b9ea27","1630644088","no");
INSERT INTO `wp20210827044706_options` VALUES("370","_transient_feed_6f409681938158427d2ded6eb1b9ea27","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:5:\"

	
	\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:141:\"

		
		
		
				
		
		

		
		
					
				

			
				

			
				

			
				

			
				

			
				

			
				

			
				

			
				

			
				

					
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WordPress | サポートフォーラム » 返信一覧\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"https://ja.wordpress.org/support/forums/feed\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 16:40:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://bbpress.org/?v=2.7.0-alpha-1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"ja\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://ja.wordpress.org/support/topic/translation-install-php%e3%81%ae%e3%82%a8%e3%83%a9%e3%83%bc%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/#post-11674362\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"返信先: translation-install.phpのエラーについて\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://ja.wordpress.org/support/topic/translation-install-php%e3%81%ae%e3%82%a8%e3%83%a9%e3%83%bc%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/#post-11674362\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 15:07:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:483:\"
						
						<p>こんにちは</p>
<p><a href=\"https://developer.wordpress.org/reference/hooks/translations_api/\" rel=\"nofollow ugc\">translations_api</a> フィルターフックでできそうです。</p>
<p>例:<br />
<code>add_filter( &#039;translations_api&#039;, &#039;__return_empty_array&#039; );</code></p>
<p>参考ページ:<br />
<a href=\"https://core.trac.wordpress.org/ticket/50584\" rel=\"nofollow ugc\">https://core.trac.wordpress.org/ticket/50584</a></p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"ishitaka\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://ja.wordpress.org/support/topic/translation-install-php%e3%81%ae%e3%82%a8%e3%83%a9%e3%83%bc%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/#post-11674361\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"返信先: translation-install.phpのエラーについて\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://ja.wordpress.org/support/topic/translation-install-php%e3%81%ae%e3%82%a8%e3%83%a9%e3%83%bc%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/#post-11674361\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 14:52:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:358:\"
						
						<p>度重ねてご回答ありがとうございます。<br />
なるほど。。。では、インターネットに接続できない環境では必然的に出てしまうのですね。<br />
このメッセージを抑止する方法ってありますでしょうか？<br />
可能であれば抑止したいな思い。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"mightyuuki\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://ja.wordpress.org/support/topic/translation-install-php%e3%81%ae%e3%82%a8%e3%83%a9%e3%83%bc%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/#post-11674360\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"返信先: translation-install.phpのエラーについて\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://ja.wordpress.org/support/topic/translation-install-php%e3%81%ae%e3%82%a8%e3%83%a9%e3%83%bc%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/#post-11674360\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 14:38:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"
						
						<p>翻訳ファイルをインターネット上から取得する処理です。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"munyagu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:118:\"https://ja.wordpress.org/support/topic/page-speed-insights%e3%81%ae%e6%94%b9%e5%96%84%e6%96%b9%e6%b3%95/#post-11674359\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"返信先: Page Speed Insightsの改善方法\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:118:\"https://ja.wordpress.org/support/topic/page-speed-insights%e3%81%ae%e6%94%b9%e5%96%84%e6%96%b9%e6%b3%95/#post-11674359\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 13:31:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1039:\"
						
						<p>多分このプラグインがそれに近いかと思われますが、何をしているのか完全に理解していないと、フロント側はレイアウトが崩れる等正常に動かなくなります。<br />
<a href=\"https://ja.wordpress.org/plugins/wp-asset-clean-up/\" rel=\"nofollow\">https://ja.wordpress.org/plugins/wp-asset-clean-up/</a><br />
また、此の類のプラグインを乱用するとサーバー側の負担が大きくスコアは下がります。<br />
PageSpeed Insightsのディスクトップとモバイルの使用していないCSSは、モバイル時にディスクトップとしてのCSSが読み込まれている為そうなります。レスボンブルの場合これの制御はかなり大変です。<br />
PageSpeed Insightsでは詳細が変わりにくいので、何故サイトが遅いのか以下のサイトにて研究して下さい。<br />
<a href=\"https://gtmetrix.com/\" rel=\"nofollow ugc\">https://gtmetrix.com/</a><br />
(WordPress対応)</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"ifnoob\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:234:\"https://ja.wordpress.org/support/topic/%e3%82%a2%e3%82%a4%e3%82%ad%e3%83%a3%e3%83%83%e3%83%81%e7%94%bb%e5%83%8f%e3%81%ae%e8%a8%ad%e5%ae%9a%e9%a0%85%e7%9b%ae%e3%81%8c%e8%a1%a8%e7%a4%ba%e3%81%95%e3%82%8c%e3%81%aa%e3%81%84/#post-11674358\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"返信先: アイキャッチ画像の設定項目が表示されない\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:234:\"https://ja.wordpress.org/support/topic/%e3%82%a2%e3%82%a4%e3%82%ad%e3%83%a3%e3%83%83%e3%83%81%e7%94%bb%e5%83%8f%e3%81%ae%e8%a8%ad%e5%ae%9a%e9%a0%85%e7%9b%ae%e3%81%8c%e8%a1%a8%e7%a4%ba%e3%81%95%e3%82%8c%e3%81%aa%e3%81%84/#post-11674358\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 13:15:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:628:\"
						
						<p>横から失礼します。</p>
<p>先程同じ現象にて、色々と確認していましたが、子テーマのstyle.cssの問題でした。<br />
仮に子テーマをカスタマイズしているようでしたら、子テーマのstyle.cssの冒頭部分のコメントをデフォルトの状態に修正してみてください。<br />
もしカスタマイズしていないようでしたら、子テーマの再インストールで解決するかと思います。</p>
<p>私の場合はそれで解決しましたので、時間が経ってはいますが参考になれば。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"studioargus\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e8%aa%ad%e8%80%85%e3%81%8c%e8%83%8c%e6%99%af%e8%89%b2%e3%80%81%e3%83%95%e3%82%a9%e3%83%b3%e3%83%88%e8%89%b2%e3%82%92%e5%a4%89%e6%9b%b4%e3%81%a7%e3%81%8d%e3%82%8b%e3%83%9c%e3%82%bf%e3%83%b3%e3%81%8c/#post-11674357\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"返信先: 読者が背景色、フォント色を変更できるボタンが欲しい\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e8%aa%ad%e8%80%85%e3%81%8c%e8%83%8c%e6%99%af%e8%89%b2%e3%80%81%e3%83%95%e3%82%a9%e3%83%b3%e3%83%88%e8%89%b2%e3%82%92%e5%a4%89%e6%9b%b4%e3%81%a7%e3%81%8d%e3%82%8b%e3%83%9c%e3%82%bf%e3%83%b3%e3%81%8c/#post-11674357\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 10:53:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:229:\"
						
						<p>ishitakaさん、<br />
有益な情報ありがとうございました。<br />
WP Dark Mode プラグインは、まさに私が求めていた機能です。<br />
大変助かりました。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"shinzanmono\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://ja.wordpress.org/support/topic/translation-install-php%e3%81%ae%e3%82%a8%e3%83%a9%e3%83%bc%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/#post-11674356\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"返信先: translation-install.phpのエラーについて\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://ja.wordpress.org/support/topic/translation-install-php%e3%81%ae%e3%82%a8%e3%83%a9%e3%83%bc%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/#post-11674356\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 09:20:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1035:\"
						
						<p>ご返答頂きまして、ありがとうございます。<br />
PHPの設定ではopensslは有効にしております。<br />
一応、先ほどPHPInfoで設定反映も確認してみましたが、enableになっているようです。</p>
<p>現設定値<br />
ーーーーーーーーーーーーーーーーーー<br />
OpenSSL support	enabled<br />
OpenSSL Library Version	OpenSSL 1.1.1b 26 Feb 2019<br />
OpenSSL Header Version	OpenSSL 1.1.1i 8 Dec 2020<br />
Openssl default config	C:\\Program Files\\Common Files\\SSL/openssl.cnf<br />
ーーーーーーーーーーーーーーーーーー</p>
<p>すみません。。。他に原因となる要因はありますでしょうか？<br />
ローカル環境なので、インターネットには接続できない環境です。<br />
翻訳ファイルがインターネット上にある場合は、取得できないのですが、<br />
本翻訳ファイルの取得場所ってどこになるかご存じだったりしますか？</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"mightyuuki\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:136:\"https://ja.wordpress.org/support/topic/redirection%e8%a8%ad%e5%ae%9a%e6%99%82%e3%81%aerest-api%e3%82%a8%e3%83%a9%e3%83%bc/#post-11674354\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"返信先: Redirection設定時のREST APIエラー\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:136:\"https://ja.wordpress.org/support/topic/redirection%e8%a8%ad%e5%ae%9a%e6%99%82%e3%81%aerest-api%e3%82%a8%e3%83%a9%e3%83%bc/#post-11674354\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 06:27:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2074:\"
						
						<p>shokun0803さん、コメントありがとうございます！</p>
<blockquote><p>セットアップ画面には、</p>
<p>続行するには、少なくとも1つの動作している REST API が必要です。</p>
<p>と書かれていますので、どれかひとつでもREST APIが動作していることが確認できれば設定は続行できるかと思いますが、セットアップ完了がクリックできませんか。</p></blockquote>
<p>確認したところ、「セットアップ完了」クリックできました。<br />
「転送ルール」という設定ページが表示されました。<br />
Version 5.1 installed! というメッセージも表示されていますので、ひとまずこれで利用してみます！</p>
<blockquote><p>ローカルの環境で試してみましたが、</p>
<p>REST API: 良好</p>
<p>とひとつしか表示されませんでしたので、サーバーの環境でも違いが出てしまうと思います。</p></blockquote>
<p>そうでしたか！サーバー環境によって異なるのですね。<br />
実際に操作を試していただいたり、丁寧に教えていただいたり、何から何まで本当にどうもありがとうございました。相談できる場所が見つからず、とても心細かったのですが、勇気を出して投稿させていただいて良かったです。</p>
<p>今後もまた相談させていただく機会があるかと存じますが、今後ともよろしくお願いいたします。<br />
どうもありがとうございました！</p>


<ul id=\"bbp-reply-revision-log-11674354\" class=\"bbp-reply-revision-log\">

	<li id=\"bbp-reply-revision-log-11674354-item-11674355\" class=\"bbp-reply-revision-log-item\">
		この返信は10時間、 12分前に<a href=\"https://ja.wordpress.org/support/users/snowdropcandy/\" title=\"snowdropcandy のプロフィールを表示\" class=\"bbp-author-link\"><span  class=\"bbp-author-name\">snowdropcandy</span></a>が編集しました。
	</li>

</ul>

						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"snowdropcandy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:136:\"https://ja.wordpress.org/support/topic/redirection%e8%a8%ad%e5%ae%9a%e6%99%82%e3%81%aerest-api%e3%82%a8%e3%83%a9%e3%83%bc/#post-11674353\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"返信先: Redirection設定時のREST APIエラー\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:136:\"https://ja.wordpress.org/support/topic/redirection%e8%a8%ad%e5%ae%9a%e6%99%82%e3%81%aerest-api%e3%82%a8%e3%83%a9%e3%83%bc/#post-11674353\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 03:19:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:740:\"
						
						<p>snowdropcandyさん、こんにちは。</p>
<p>セットアップ画面には、</p>
<blockquote><p>続行するには、少なくとも1つの動作している REST API が必要です。</p></blockquote>
<p>と書かれていますので、どれかひとつでもREST APIが動作していることが確認できれば設定は続行できるかと思いますが、セットアップ完了がクリックできませんか。</p>
<p>ローカルの環境で試してみましたが、</p>
<blockquote><p>REST API: 良好</p></blockquote>
<p>とひとつしか表示されませんでしたので、サーバーの環境でも違いが出てしまうと思います。</p>
<p>ご参考になれば。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"shokun0803\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e8%aa%ad%e8%80%85%e3%81%8c%e8%83%8c%e6%99%af%e8%89%b2%e3%80%81%e3%83%95%e3%82%a9%e3%83%b3%e3%83%88%e8%89%b2%e3%82%92%e5%a4%89%e6%9b%b4%e3%81%a7%e3%81%8d%e3%82%8b%e3%83%9c%e3%82%bf%e3%83%b3%e3%81%8c/#post-11674352\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"返信先: 読者が背景色、フォント色を変更できるボタンが欲しい\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e8%aa%ad%e8%80%85%e3%81%8c%e8%83%8c%e6%99%af%e8%89%b2%e3%80%81%e3%83%95%e3%82%a9%e3%83%b3%e3%83%88%e8%89%b2%e3%82%92%e5%a4%89%e6%9b%b4%e3%81%a7%e3%81%8d%e3%82%8b%e3%83%9c%e3%82%bf%e3%83%b3%e3%81%8c/#post-11674352\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Sep 2021 02:54:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:473:\"
						
						<p>こんにちは</p>
<p><a href=\"https://ja.wordpress.org/plugins/wp-dark-mode/\" rel=\"nofollow\">WP Dark Mode</a> プラグインはどうでしょうか。プラグインページの説明を見た感じではできそうです。</p>
<p>他にもいろいろあるので試してみてはと思います。<br />
<a href=\"https://ja.wordpress.org/plugins/tags/dark-mode/\" rel=\"nofollow\">https://ja.wordpress.org/plugins/tags/dark-mode/</a></p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"ishitaka\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:44:\"https://ja.wordpress.org/support/forums/feed\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:7:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 02 Sep 2021 16:41:28 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:12:\"x-robots-tag\";s:15:\"noindex, follow\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20210725171650\";}","no");
INSERT INTO `wp20210827044706_options` VALUES("371","_transient_timeout_feed_mod_6f409681938158427d2ded6eb1b9ea27","1630644088","no");
INSERT INTO `wp20210827044706_options` VALUES("372","_transient_feed_mod_6f409681938158427d2ded6eb1b9ea27","1630600888","no");
INSERT INTO `wp20210827044706_options` VALUES("373","_transient_timeout_dash_v2_45827e8e892dd0b85803a110fad8690f","1630644088","no");
INSERT INTO `wp20210827044706_options` VALUES("374","_transient_dash_v2_45827e8e892dd0b85803a110fad8690f","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/2021/08/26/an-update-on-the-classic-editor-plugin/\'>Classic Editor プラグインの公式サポート期限更新</a></li><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/2021/08/10/widgets-in-wordpress-5-8-and-beyond/\'>WordPress 5.8、そしてこれからのウィジェット</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/support/topic/translation-install-php%E3%81%AE%E3%82%A8%E3%83%A9%E3%83%BC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6/#post-11674362\'>返信先: translation-install.phpのエラーについて</a></li><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/support/topic/translation-install-php%E3%81%AE%E3%82%A8%E3%83%A9%E3%83%BC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6/#post-11674361\'>返信先: translation-install.phpのエラーについて</a></li><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/support/topic/translation-install-php%E3%81%AE%E3%82%A8%E3%83%A9%E3%83%BC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6/#post-11674360\'>返信先: translation-install.phpのエラーについて</a></li></ul></div>","no");
INSERT INTO `wp20210827044706_options` VALUES("375","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1630611837","no");
INSERT INTO `wp20210827044706_options` VALUES("376","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:5114;}s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4768;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2725;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2604;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:2012;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1866;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1851;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1526;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1514;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1506;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1501;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1499;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1475;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1311;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1279;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1275;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1238;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1160;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1129;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:1063;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:973;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:938;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:916;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:900;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:888;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:840;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:823;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:817;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:813;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:797;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:762;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:752;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:733;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:729;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:729;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:717;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:711;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:684;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:669;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:668;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:667;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:665;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:664;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:662;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:652;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:636;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:602;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:600;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:593;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:592;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:577;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:575;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:568;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:567;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:565;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:557;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:556;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:553;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:550;}s:9:\"elementor\";a:3:{s:4:\"name\";s:9:\"elementor\";s:4:\"slug\";s:9:\"elementor\";s:5:\"count\";i:543;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:538;}s:5:\"block\";a:3:{s:4:\"name\";s:5:\"block\";s:4:\"slug\";s:5:\"block\";s:5:\"count\";i:535;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:533;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:523;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:514;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:510;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:500;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:499;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:499;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:487;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:485;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:474;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:468;}s:8:\"shipping\";a:3:{s:4:\"name\";s:8:\"shipping\";s:4:\"slug\";s:8:\"shipping\";s:5:\"count\";i:466;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:464;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:463;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:454;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:448;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:446;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:444;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:434;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:427;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:424;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:418;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:411;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:411;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:406;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:401;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:401;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:391;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:390;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:384;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:383;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:380;}s:6:\"import\";a:3:{s:4:\"name\";s:6:\"import\";s:4:\"slug\";s:6:\"import\";s:5:\"count\";i:377;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:373;}s:6:\"blocks\";a:3:{s:4:\"name\";s:6:\"blocks\";s:4:\"slug\";s:6:\"blocks\";s:5:\"count\";i:369;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:369;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:360;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:357;}}","no");
INSERT INTO `wp20210827044706_options` VALUES("381","amelia_settings","{\"db\":{\"mysqliEnabled\":false,\"pdoEmulatePrepares\":false,\"pdoBigSelect\":false,\"ssl\":{\"enable\":false,\"key\":null,\"cert\":null,\"ca\":null}},\"general\":{\"timeSlotLength\":1800,\"serviceDurationAsSlot\":false,\"bufferTimeInSlot\":true,\"defaultAppointmentStatus\":\"approved\",\"minimumTimeRequirementPriorToBooking\":0,\"minimumTimeRequirementPriorToCanceling\":0,\"minimumTimeRequirementPriorToRescheduling\":0,\"numberOfDaysAvailableForBooking\":361,\"backendSlotsDaysInFuture\":365,\"backendSlotsDaysInPast\":365,\"phoneDefaultCountryCode\":\"jp\",\"requiredPhoneNumberField\":false,\"requiredEmailField\":true,\"itemsPerPage\":12,\"appointmentsPerPage\":100,\"servicesPerPage\":100,\"customersFilterLimit\":100,\"gMapApiKey\":\"\",\"addToCalendar\":true,\"sendIcsAttachment\":false,\"defaultPageOnBackend\":\"Dashboard\",\"showClientTimeZone\":false,\"redirectUrlAfterAppointment\":\"\",\"customFieldsUploadsPath\":\"\",\"backLink\":{\"enabled\":true,\"label\":\"Booking Enabled by Amelia - Appointment and Event Booking Plugin\",\"url\":\"https:\\/\\/wpamelia.com\\/pricing\\/?utm_source=lite&utm_medium=website&utm_campaign=powerdby\"},\"runInstantPostBookingActions\":false,\"useWindowVueInAmelia\":true,\"useWindowVueInAmeliaBack\":true,\"sortingPackages\":\"nameAsc\",\"sortingServices\":\"custom\",\"calendarLocaleSubstitutes\":[],\"googleRecaptcha\":{\"enabled\":false,\"invisible\":true,\"siteKey\":\"\",\"secret\":\"\"},\"usedLanguages\":[]},\"company\":{\"pictureFullPath\":\"http:\\/\\/tmusfc.jp\\/wp-content\\/uploads\\/2021\\/09\\/IMG_7420-scaled.jpg\",\"pictureThumbPath\":\"http:\\/\\/tmusfc.jp\\/wp-content\\/uploads\\/2021\\/09\\/IMG_7420-150x150.jpg\",\"name\":\"\\u6771\\u4eac\\u90fd\\u7acb\\u5927\\u5b66\\u3000TMU-SFC\",\"address\":\"\\u6771\\u4eac\\u90fd\\u516b\\u738b\\u5b50\\u5e02\\u5357\\u5927\\u6ca2\\uff11\\u4e01\\u76ee\\uff11\\u5b66\\u751f\\u30db\\u30fc\\u30eb365\",\"phone\":\"\",\"countryPhoneIso\":\"jp\",\"website\":\"\"},\"notifications\":{\"mailService\":\"php\",\"smtpHost\":\"\",\"smtpPort\":\"\",\"smtpSecure\":\"ssl\",\"smtpUsername\":\"\",\"smtpPassword\":\"\",\"mailgunApiKey\":\"\",\"mailgunDomain\":\"\",\"mailgunEndpoint\":\"\",\"senderName\":\"\\u5316\\u5b66\\u5b9f\\u9a13\\u30b5\\u30fc\\u30af\\u30eb\\u3000TMU-SFC\",\"senderEmail\":\"tmusfc@gmail.com\",\"notifyCustomers\":true,\"sendAllCF\":true,\"smsAlphaSenderId\":\"Amelia\",\"smsSignedIn\":false,\"smsApiToken\":\"\",\"bccEmail\":\"\",\"bccSms\":\"\",\"cancelSuccessUrl\":\"\",\"cancelErrorUrl\":\"\",\"breakReplacement\":\"<br>\"},\"daysOff\":[],\"weekSchedule\":[{\"day\":\"Monday\",\"time\":[\"09:00\",\"17:00\"],\"breaks\":[],\"periods\":[]},{\"day\":\"Tuesday\",\"time\":[\"09:00\",\"17:00\"],\"breaks\":[],\"periods\":[]},{\"day\":\"Wednesday\",\"time\":[\"09:00\",\"17:00\"],\"breaks\":[],\"periods\":[]},{\"day\":\"Thursday\",\"time\":[\"09:00\",\"17:00\"],\"breaks\":[],\"periods\":[]},{\"day\":\"Friday\",\"time\":[\"09:00\",\"17:00\"],\"breaks\":[],\"periods\":[]},{\"day\":\"Saturday\",\"time\":[],\"breaks\":[],\"periods\":[]},{\"day\":\"Sunday\",\"time\":[],\"breaks\":[],\"periods\":[]}],\"googleCalendar\":{\"clientID\":\"\",\"clientSecret\":\"\",\"redirectURI\":\"http:\\/\\/tmusfc.jp\\/wp-admin\\/admin.php?page=wpamelia-employees\",\"showAttendees\":false,\"insertPendingAppointments\":false,\"addAttendees\":false,\"sendEventInvitationEmail\":false,\"removeGoogleCalendarBusySlots\":false,\"maximumNumberOfEventsReturned\":50,\"eventTitle\":\"%service_name%\",\"eventDescription\":\"\",\"includeBufferTimeGoogleCalendar\":false,\"status\":\"tentative\",\"enableGoogleMeet\":false},\"outlookCalendar\":{\"clientID\":\"\",\"clientSecret\":\"\",\"redirectURI\":\"http:\\/\\/tmusfc.jp\\/wp-admin\\/\",\"insertPendingAppointments\":false,\"addAttendees\":false,\"sendEventInvitationEmail\":false,\"removeOutlookCalendarBusySlots\":false,\"maximumNumberOfEventsReturned\":50,\"eventTitle\":\"%service_name%\",\"eventDescription\":\"\",\"includeBufferTimeOutlookCalendar\":false},\"payments\":{\"currency\":\"USD\",\"symbol\":\"$\",\"priceSymbolPosition\":\"before\",\"priceNumberOfDecimals\":2,\"priceSeparator\":1,\"hideCurrencySymbolFrontend\":false,\"defaultPaymentMethod\":\"onSite\",\"onSite\":true,\"coupons\":false,\"payPal\":{\"enabled\":false,\"sandboxMode\":false,\"liveApiClientId\":\"\",\"liveApiSecret\":\"\",\"testApiClientId\":\"\",\"testApiSecret\":\"\",\"description\":{\"enabled\":false,\"appointment\":\"\",\"package\":\"\",\"event\":\"\"}},\"stripe\":{\"enabled\":false,\"testMode\":false,\"livePublishableKey\":\"\",\"liveSecretKey\":\"\",\"testPublishableKey\":\"\",\"testSecretKey\":\"\",\"description\":{\"enabled\":false,\"appointment\":\"\",\"package\":\"\",\"event\":\"\"},\"metaData\":{\"enabled\":false,\"appointment\":null,\"package\":null,\"event\":null},\"manualCapture\":false},\"wc\":{\"enabled\":false,\"productId\":\"\",\"onSiteIfFree\":false,\"page\":\"cart\",\"dashboard\":true,\"checkoutData\":{\"appointment\":\"\",\"package\":\"\",\"event\":\"\",\"translations\":{\"appointment\":[],\"event\":[],\"package\":[]}},\"skipCheckoutGetValueProcessing\":false},\"mollie\":{\"enabled\":false,\"testMode\":false,\"liveApiKey\":\"\",\"testApiKey\":\"\",\"description\":{\"enabled\":false,\"appointment\":\"\",\"package\":\"\",\"event\":\"\"},\"metaData\":{\"enabled\":false,\"appointment\":null,\"package\":null,\"event\":null},\"method\":[]}},\"activation\":{\"showActivationSettings\":true,\"active\":false,\"purchaseCodeStore\":\"\",\"envatoTokenEmail\":\"\",\"version\":\"1.0.35\",\"deleteTables\":false,\"stash\":false},\"customization\":{\"primaryColor\":\"#1A84EE\",\"primaryGradient1\":\"#1A84EE\",\"primaryGradient2\":\"#0454A2\",\"textColor\":\"#354052\",\"textColorOnBackground\":\"#FFFFFF\",\"font\":\"Amelia Roboto\",\"useGenerated\":false,\"hash\":\"WgI6hmbMTx\"},\"labels\":{\"enabled\":true,\"employee\":\"employee\",\"employees\":\"employees\",\"service\":\"service\",\"services\":\"services\"},\"roles\":{\"allowConfigureSchedule\":false,\"allowConfigureDaysOff\":false,\"allowConfigureSpecialDays\":false,\"allowConfigureServices\":false,\"allowWriteAppointments\":false,\"automaticallyCreateCustomer\":false,\"inspectCustomerInfo\":false,\"allowCustomerReschedule\":false,\"allowCustomerDeleteProfile\":false,\"allowWriteEvents\":false,\"enabledHttpAuthorization\":true,\"customerCabinet\":{\"enabled\":false,\"headerJwtSecret\":\"b47ca9aac5a07ec18ca9\",\"urlJwtSecret\":\"eb85490cfe407e4d6c72\",\"tokenValidTime\":2592000,\"pageUrl\":\"\",\"loginEnabled\":true,\"filterDate\":false,\"translations\":[]},\"providerCabinet\":{\"enabled\":false,\"headerJwtSecret\":\"bb8b5a243b7c4d833b40\",\"urlJwtSecret\":\"3834278847a4fea9acbc\",\"tokenValidTime\":2592000,\"pageUrl\":\"\",\"loginEnabled\":true,\"filterDate\":false},\"urlAttachment\":{\"enabled\":true,\"headerJwtSecret\":\"72b70e0a3a0545d3670b\",\"urlJwtSecret\":\"15c5273d38c80b41175b\",\"tokenValidTime\":2592000,\"pageUrl\":\"\",\"loginEnabled\":true,\"filterDate\":false}},\"appointments\":{\"isGloballyBusySlot\":false,\"allowBookingIfPending\":true,\"allowBookingIfNotMin\":true,\"openedBookingAfterMin\":false,\"recurringPlaceholders\":\"DateTime: %appointment_date_time%\",\"recurringPlaceholdersSms\":\"DateTime: %appointment_date_time%\",\"recurringPlaceholdersCustomer\":\"DateTime: %appointment_date_time%\",\"recurringPlaceholdersCustomerSms\":\"DateTime: %appointment_date_time%\",\"packagePlaceholders\":\"DateTime: %appointment_date_time%\",\"packagePlaceholdersSms\":\"DateTime: %appointment_date_time%\",\"packagePlaceholdersCustomer\":\"DateTime: %appointment_date_time%\",\"packagePlaceholdersCustomerSms\":\"DateTime: %appointment_date_time%\",\"translations\":{\"recurringPlaceholdersCustomer\":null,\"recurringPlaceholdersCustomerSms\":null,\"packagePlaceholdersCustomer\":null,\"packagePlaceholdersCustomerSms\":null}},\"webHooks\":[],\"zoom\":{\"enabled\":true,\"apiKey\":\"\",\"apiSecret\":\"\",\"meetingTitle\":\"%reservation_name%\",\"meetingAgenda\":\"%reservation_description%\",\"pendingAppointmentsMeetings\":false,\"maxUsersCount\":300},\"ics\":{\"description\":{\"appointment\":\"\",\"event\":\"\",\"translations\":{\"appointment\":null,\"event\":null}}}}","yes");
INSERT INTO `wp20210827044706_options` VALUES("384","_site_transient_timeout_available_translations","1630617375","no");
INSERT INTO `wp20210827044706_options` VALUES("385","_site_transient_available_translations","a:126:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-05-13 15:59:22\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-08 22:04:46\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-06-14 14:01:58\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-10-29 07:54:22\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.18/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-12 18:39:12\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-10-31 08:48:37\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2020-10-30 03:24:38\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-04-25 07:27:37\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 05:24:50\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-29 19:09:14\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-09 13:26:29\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-19 22:07:46\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-22 10:24:47\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.8/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 22:19:30\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 22:20:04\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.8/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-22 10:24:20\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-10 12:19:50\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dsb\";a:8:{s:8:\"language\";s:3:\"dsb\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 11:17:46\";s:12:\"english_name\";s:13:\"Lower Sorbian\";s:11:\"native_name\";s:16:\"Dolnoserbšćina\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/translation/core/5.8/dsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"dsb\";i:3;s:3:\"dsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Dalej\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 04:36:23\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-03 20:56:24\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-20 07:45:43\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 21:02:00\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-04-15 04:12:28\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-01 17:19:17\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-04-18 09:35:35\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-20 17:20:36\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-22 17:31:33\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 02:18:40\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 02:19:00\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_EC\";a:8:{s:8:\"language\";s:5:\"es_EC\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 02:19:31\";s:12:\"english_name\";s:17:\"Spanish (Ecuador)\";s:11:\"native_name\";s:19:\"Español de Ecuador\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/es_EC.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-30 00:35:05\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 13:13:00\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_UY\";a:8:{s:8:\"language\";s:5:\"es_UY\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-03-31 18:33:26\";s:12:\"english_name\";s:17:\"Spanish (Uruguay)\";s:11:\"native_name\";s:19:\"Español de Uruguay\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/es_UY.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-06-14 16:02:22\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PR\";a:8:{s:8:\"language\";s:5:\"es_PR\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-04-29 15:36:59\";s:12:\"english_name\";s:21:\"Spanish (Puerto Rico)\";s:11:\"native_name\";s:23:\"Español de Puerto Rico\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/es_PR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.11/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-27 10:08:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2020-08-12 08:38:59\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-31 16:15:10\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-31 06:18:44\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"fa_AF\";a:8:{s:8:\"language\";s:5:\"fa_AF\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-06-14 12:40:09\";s:12:\"english_name\";s:21:\"Persian (Afghanistan)\";s:11:\"native_name\";s:31:\"(فارسی (افغانستان\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/fa_AF.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-02 07:17:54\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-19 13:07:55\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 07:27:38\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-02-22 13:54:46\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-09 08:24:48\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:6:\"4.4.25\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.4.25/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:6:\"5.8-rc\";s:7:\"updated\";s:19:\"2021-05-28 16:42:59\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.8-rc/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-11-06 12:34:38\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-03 09:22:19\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:3:\"hsb\";a:8:{s:8:\"language\";s:3:\"hsb\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 11:18:08\";s:12:\"english_name\";s:13:\"Upper Sorbian\";s:11:\"native_name\";s:17:\"Hornjoserbšćina\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/translation/core/5.8/hsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"hsb\";i:3;s:3:\"hsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:4:\"Dale\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-12 12:56:29\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-30 16:28:34\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-12-11 10:40:02\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-14 11:54:07\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 03:37:13\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-02-16 23:58:56\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nutugne\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-21 07:24:54\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 18:00:15\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/translation/core/5.8/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-07-10 11:35:44\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2019-06-10 16:18:28\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.11/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2020-09-30 14:08:59\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 05:27:21\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-11 19:53:28\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/translation/core/5.8/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"ຕໍ່\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-03-23 12:35:40\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-31 07:25:25\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-07-01 09:16:57\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-11-22 15:32:08\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-08-31 11:57:07\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.2.30\";s:7:\"updated\";s:19:\"2017-12-26 11:57:10\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.30/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 13:52:23\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2020-05-31 16:07:59\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.11/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"जारीराख्नु \";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-25 18:16:47\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 21:47:59\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-03 06:37:09\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.8/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-03-18 10:59:16\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 08:35:49\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.3.26\";s:7:\"updated\";s:19:\"2015-12-02 21:41:29\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.3.26/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-02 07:25:03\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 22:25:05\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-05-30 09:51:29\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-02 07:24:45\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 21:04:07\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 21:02:01\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:3:\"snd\";a:8:{s:8:\"language\";s:3:\"snd\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-07-07 01:53:37\";s:12:\"english_name\";s:6:\"Sindhi\";s:11:\"native_name\";s:8:\"سنڌي\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.4.6/snd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"sd\";i:2;s:3:\"snd\";i:3;s:3:\"snd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"اڳتي هلو\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-07-21 06:06:38\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-04-23 11:54:14\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.8-beta/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-31 06:12:58\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-10 11:19:20\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-01 21:21:06\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-01 21:06:48\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"sw\";a:8:{s:8:\"language\";s:2:\"sw\";s:7:\"version\";s:5:\"5.3.8\";s:7:\"updated\";s:19:\"2019-10-13 15:35:35\";s:12:\"english_name\";s:7:\"Swahili\";s:11:\"native_name\";s:9:\"Kiswahili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.8/sw.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sw\";i:2;s:3:\"swa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Endelea\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:5:\"ta_LK\";a:8:{s:8:\"language\";s:5:\"ta_LK\";s:7:\"version\";s:6:\"4.2.30\";s:7:\"updated\";s:19:\"2015-12-03 01:07:44\";s:12:\"english_name\";s:17:\"Tamil (Sri Lanka)\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.30/ta_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"தொடர்க\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.5.5\";s:7:\"updated\";s:19:\"2021-07-13 19:33:34\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.5.5/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-09-30 09:04:29\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.17/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-09 09:04:54\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2021-07-03 18:41:33\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-27 18:02:55\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-04-09 11:17:33\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.4.6/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-02-28 12:02:22\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-02 03:13:39\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/5.8/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-08-25 14:22:17\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:3:\"5.8\";s:7:\"updated\";s:19:\"2021-09-02 05:46:40\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-06-27 10:46:14\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no");
INSERT INTO `wp20210827044706_options` VALUES("387","_site_transient_timeout_theme_roots","1630608419","no");
INSERT INTO `wp20210827044706_options` VALUES("388","_site_transient_theme_roots","a:3:{s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}","no");
INSERT INTO `wp20210827044706_options` VALUES("389","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:60:\"https://downloads.wordpress.org/release/ja/wordpress-5.8.zip\";s:6:\"locale\";s:2:\"ja\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:60:\"https://downloads.wordpress.org/release/ja/wordpress-5.8.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"5.8\";s:7:\"version\";s:3:\"5.8\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1630606629;s:15:\"version_checked\";s:3:\"5.8\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp20210827044706_options` VALUES("390","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1630606630;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:10:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:6:\"4.1.11\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/akismet.4.1.11.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.9\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";}s:31:\"ameliabooking/ameliabooking.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:27:\"w.org/plugins/ameliabooking\";s:4:\"slug\";s:13:\"ameliabooking\";s:6:\"plugin\";s:31:\"ameliabooking/ameliabooking.php\";s:11:\"new_version\";s:6:\"1.0.35\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/ameliabooking/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/ameliabooking.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/ameliabooking/assets/icon-256x256.png?rev=1991800\";s:2:\"1x\";s:66:\"https://ps.w.org/ameliabooking/assets/icon-128x128.png?rev=1991800\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/ameliabooking/assets/banner-1544x500.png?rev=1991943\";s:2:\"1x\";s:68:\"https://ps.w.org/ameliabooking/assets/banner-772x250.png?rev=1991943\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.5\";}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.4.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.4.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.5\";}s:9:\"hello.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}s:39:\"simple-custom-css/simple-custom-css.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:31:\"w.org/plugins/simple-custom-css\";s:4:\"slug\";s:17:\"simple-custom-css\";s:6:\"plugin\";s:39:\"simple-custom-css/simple-custom-css.php\";s:11:\"new_version\";s:5:\"4.0.4\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/simple-custom-css/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/simple-custom-css.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/simple-custom-css/assets/icon-256x256.jpg?rev=1819543\";s:2:\"1x\";s:70:\"https://ps.w.org/simple-custom-css/assets/icon-128x128.jpg?rev=1819543\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/simple-custom-css/assets/banner-1544x500.jpg?rev=1819543\";s:2:\"1x\";s:72:\"https://ps.w.org/simple-custom-css/assets/banner-772x250.jpg?rev=1819543\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:5:\"3.0.1\";}s:31:\"custom-css-js/custom-css-js.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:27:\"w.org/plugins/custom-css-js\";s:4:\"slug\";s:13:\"custom-css-js\";s:6:\"plugin\";s:31:\"custom-css-js/custom-css-js.php\";s:11:\"new_version\";s:4:\"3.37\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/custom-css-js/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/custom-css-js.3.37.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/custom-css-js/assets/icon-128x128.png?rev=1303730\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/custom-css-js/assets/banner-1544x500.png?rev=1770945\";s:2:\"1x\";s:68:\"https://ps.w.org/custom-css-js/assets/banner-772x250.png?rev=1303730\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:5:\"3.0.1\";}s:23:\"siteguard/siteguard.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:23:\"w.org/plugins/siteguard\";s:4:\"slug\";s:9:\"siteguard\";s:6:\"plugin\";s:23:\"siteguard/siteguard.php\";s:11:\"new_version\";s:5:\"1.6.0\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/siteguard/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/siteguard.1.6.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/siteguard/assets/icon-256x256.png?rev=1011863\";s:2:\"1x\";s:62:\"https://ps.w.org/siteguard/assets/icon-128x128.png?rev=1011863\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:64:\"https://ps.w.org/siteguard/assets/banner-772x250.png?rev=1011863\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"3.9\";}s:35:\"google-site-kit/google-site-kit.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:29:\"w.org/plugins/google-site-kit\";s:4:\"slug\";s:15:\"google-site-kit\";s:6:\"plugin\";s:35:\"google-site-kit/google-site-kit.php\";s:11:\"new_version\";s:6:\"1.40.0\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/google-site-kit/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/google-site-kit.1.40.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/google-site-kit/assets/icon-256x256.png?rev=2181376\";s:2:\"1x\";s:68:\"https://ps.w.org/google-site-kit/assets/icon-128x128.png?rev=2181376\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/google-site-kit/assets/banner-1544x500.png?rev=2513620\";s:2:\"1x\";s:70:\"https://ps.w.org/google-site-kit/assets/banner-772x250.png?rev=2513620\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";}s:41:\"wp-multibyte-patch/wp-multibyte-patch.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:32:\"w.org/plugins/wp-multibyte-patch\";s:4:\"slug\";s:18:\"wp-multibyte-patch\";s:6:\"plugin\";s:41:\"wp-multibyte-patch/wp-multibyte-patch.php\";s:11:\"new_version\";s:3:\"2.9\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/wp-multibyte-patch/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/wp-multibyte-patch.2.9.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:62:\"https://s.w.org/plugins/geopattern-icon/wp-multibyte-patch.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.2\";}}s:7:\"checked\";a:10:{s:19:\"akismet/akismet.php\";s:6:\"4.1.11\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.9\";s:31:\"ameliabooking/ameliabooking.php\";s:6:\"1.0.35\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.4.2\";s:9:\"hello.php\";s:5:\"1.7.2\";s:39:\"simple-custom-css/simple-custom-css.php\";s:5:\"4.0.4\";s:31:\"custom-css-js/custom-css-js.php\";s:4:\"3.37\";s:23:\"siteguard/siteguard.php\";s:5:\"1.6.0\";s:35:\"google-site-kit/google-site-kit.php\";s:6:\"1.40.0\";s:41:\"wp-multibyte-patch/wp-multibyte-patch.php\";s:3:\"2.9\";}}","no");
INSERT INTO `wp20210827044706_options` VALUES("391","_site_transient_update_themes","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1630606630;s:7:\"checked\";a:3:{s:14:\"twentynineteen\";s:3:\"2.1\";s:12:\"twentytwenty\";s:3:\"1.8\";s:15:\"twentytwentyone\";s:3:\"1.4\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:3:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"2.1\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.2.1.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.8\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.8.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.4.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp20210827044706_options` VALUES("392","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp20210827044706_options` VALUES("393","aio_wp_security_configs","a:92:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:16:\"tmusfc@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"l9ookjbmzzf5qahhb68r\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"zkf0vf3dmfk9j2qk9gys\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:16:\"tmusfc@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:27:\"aiowps_max_file_upload_size\";s:2:\"10\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:16:\"tmusfc@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}","yes");
INSERT INTO `wp20210827044706_options` VALUES("394","_transient_timeout_users_online","1630608431","no");
INSERT INTO `wp20210827044706_options` VALUES("395","_transient_users_online","a:1:{i:0;a:4:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1630639031;s:10:\"ip_address\";s:13:\"27.92.236.205\";s:7:\"blog_id\";b:0;}}","no");


DROP TABLE IF EXISTS `wp20210827044706_postmeta`;

CREATE TABLE `wp20210827044706_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp20210827044706_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp20210827044706_postmeta` VALUES("3","5","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%83%83%e3%82%af%e3%81%a7%e3%82%b5%e3%82%a4%e3%83%88%e3%82%92%e4%bd%9c%e6%88%90");
INSERT INTO `wp20210827044706_postmeta` VALUES("4","5","_customize_changeset_uuid","6ec6cd79-db21-4dfb-8f78-9428c309a05b");
INSERT INTO `wp20210827044706_postmeta` VALUES("5","6","_customize_draft_post_name","%e4%bc%9a%e7%a4%be%e6%a6%82%e8%a6%81");
INSERT INTO `wp20210827044706_postmeta` VALUES("6","6","_customize_changeset_uuid","6ec6cd79-db21-4dfb-8f78-9428c309a05b");
INSERT INTO `wp20210827044706_postmeta` VALUES("7","7","_customize_draft_post_name","%e3%81%8a%e5%95%8f%e3%81%84%e5%90%88%e3%82%8f%e3%81%9b");
INSERT INTO `wp20210827044706_postmeta` VALUES("8","7","_customize_changeset_uuid","6ec6cd79-db21-4dfb-8f78-9428c309a05b");
INSERT INTO `wp20210827044706_postmeta` VALUES("9","8","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%82%b0");
INSERT INTO `wp20210827044706_postmeta` VALUES("10","8","_customize_changeset_uuid","6ec6cd79-db21-4dfb-8f78-9428c309a05b");
INSERT INTO `wp20210827044706_postmeta` VALUES("11","10","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%83%83%e3%82%af%e3%81%a7%e3%82%b5%e3%82%a4%e3%83%88%e3%82%92%e4%bd%9c%e6%88%90");
INSERT INTO `wp20210827044706_postmeta` VALUES("12","10","_customize_changeset_uuid","2ad8bba3-3ac6-4881-ba08-9eb0bb7b3889");
INSERT INTO `wp20210827044706_postmeta` VALUES("13","11","_customize_draft_post_name","%e4%bc%9a%e7%a4%be%e6%a6%82%e8%a6%81");
INSERT INTO `wp20210827044706_postmeta` VALUES("14","11","_customize_changeset_uuid","2ad8bba3-3ac6-4881-ba08-9eb0bb7b3889");
INSERT INTO `wp20210827044706_postmeta` VALUES("15","12","_customize_draft_post_name","%e3%81%8a%e5%95%8f%e3%81%84%e5%90%88%e3%82%8f%e3%81%9b");
INSERT INTO `wp20210827044706_postmeta` VALUES("16","12","_customize_changeset_uuid","2ad8bba3-3ac6-4881-ba08-9eb0bb7b3889");
INSERT INTO `wp20210827044706_postmeta` VALUES("17","13","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%82%b0");
INSERT INTO `wp20210827044706_postmeta` VALUES("18","13","_customize_changeset_uuid","2ad8bba3-3ac6-4881-ba08-9eb0bb7b3889");
INSERT INTO `wp20210827044706_postmeta` VALUES("19","9","_customize_restore_dismissed","1");
INSERT INTO `wp20210827044706_postmeta` VALUES("20","15","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%83%83%e3%82%af%e3%81%a7%e3%82%b5%e3%82%a4%e3%83%88%e3%82%92%e4%bd%9c%e6%88%90");
INSERT INTO `wp20210827044706_postmeta` VALUES("21","15","_customize_changeset_uuid","8c2d8777-fe77-4397-b29d-acaeaa84dde5");
INSERT INTO `wp20210827044706_postmeta` VALUES("22","16","_customize_draft_post_name","%e4%bc%9a%e7%a4%be%e6%a6%82%e8%a6%81");
INSERT INTO `wp20210827044706_postmeta` VALUES("23","16","_customize_changeset_uuid","8c2d8777-fe77-4397-b29d-acaeaa84dde5");
INSERT INTO `wp20210827044706_postmeta` VALUES("24","17","_customize_draft_post_name","%e3%81%8a%e5%95%8f%e3%81%84%e5%90%88%e3%82%8f%e3%81%9b");
INSERT INTO `wp20210827044706_postmeta` VALUES("25","17","_customize_changeset_uuid","8c2d8777-fe77-4397-b29d-acaeaa84dde5");
INSERT INTO `wp20210827044706_postmeta` VALUES("26","18","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%82%b0");
INSERT INTO `wp20210827044706_postmeta` VALUES("27","18","_customize_changeset_uuid","8c2d8777-fe77-4397-b29d-acaeaa84dde5");
INSERT INTO `wp20210827044706_postmeta` VALUES("28","14","_customize_restore_dismissed","1");
INSERT INTO `wp20210827044706_postmeta` VALUES("29","20","_form","<label> 氏名
    [text* your-name] </label>

<label> メールアドレス
    [email* your-email] </label>

<label> 題名
    [text* your-subject] </label>

<label> メッセージ本文 (任意)
    [textarea your-message] </label>

[submit \"送信\"]");
INSERT INTO `wp20210827044706_postmeta` VALUES("30","20","_mail","a:8:{s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:35:\"[_site_title] <wordpress@tmusfc.jp>\";s:4:\"body\";s:212:\"差出人: [your-name] <[your-email]>
題名: [your-subject]

メッセージ本文:
[your-message]

-- 
このメールは [_site_title] ([_site_url]) のお問い合わせフォームから送信されました\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}");
INSERT INTO `wp20210827044706_postmeta` VALUES("31","20","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:35:\"[_site_title] <wordpress@tmusfc.jp>\";s:4:\"body\";s:150:\"メッセージ本文:
[your-message]

-- 
このメールは [_site_title] ([_site_url]) のお問い合わせフォームから送信されました\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}");
INSERT INTO `wp20210827044706_postmeta` VALUES("32","20","_messages","a:12:{s:12:\"mail_sent_ok\";s:75:\"ありがとうございます。メッセージは送信されました。\";s:12:\"mail_sent_ng\";s:84:\"メッセージの送信に失敗しました。後でまたお試しください。\";s:16:\"validation_error\";s:81:\"入力内容に問題があります。確認して再度お試しください。\";s:4:\"spam\";s:84:\"メッセージの送信に失敗しました。後でまたお試しください。\";s:12:\"accept_terms\";s:66:\"メッセージを送信する前に承諾確認が必要です。\";s:16:\"invalid_required\";s:42:\"必須項目に入力してください。\";s:16:\"invalid_too_long\";s:48:\"入力されたテキストが長すぎます。\";s:17:\"invalid_too_short\";s:48:\"入力されたテキストが短すぎます。\";s:13:\"upload_failed\";s:81:\"ファイルのアップロード時に不明なエラーが発生しました。\";s:24:\"upload_file_type_invalid\";s:66:\"この形式のファイルはアップロードできません。\";s:21:\"upload_file_too_large\";s:36:\"ファイルが大きすぎます。\";s:23:\"upload_failed_php_error\";s:72:\"ファイルのアップロード中にエラーが発生しました。\";}");
INSERT INTO `wp20210827044706_postmeta` VALUES("33","20","_additional_settings","");
INSERT INTO `wp20210827044706_postmeta` VALUES("34","20","_locale","ja");
INSERT INTO `wp20210827044706_postmeta` VALUES("35","21","_form","<label> <b>代表者氏名(必須)</b>
    [text* your-name class:name placeholder \"お名前を入力してください\" ] </label>


<label> メールアドレス(必須)
[email* your-email class:email \"メールアドレスを入力してください\"] </label>


体験実験参加日（必須）
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]

参加実験を選ぶ(必須)
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加実験を選ぶ(必須)
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加時間帯を選ぶ(必須)
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]

<label> 質問内容 (任意)
    [textarea your-message class:message] </label>

[submit \"送信\"]");
INSERT INTO `wp20210827044706_postmeta` VALUES("36","21","_mail","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:41:\"体験！！化学実験 \"[your-subject]\"\";s:6:\"sender\";s:73:\"首都大学東京 化学実験サークル TMU-SFC <wordpress@tmusfc.jp>\";s:9:\"recipient\";s:22:\"jmpringonoki@gmail.com\";s:4:\"body\";s:291:\"差出人: [your-name]

差出人メールアドレス:[your-email]

参加日:[your-date]

参加時間:[your-time]

参加実験:[your-experiment]


質問など:[your-message]

-- 
このメールは [_site_title] ([_site_url]) のお問い合わせフォームから送信されました\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `wp20210827044706_postmeta` VALUES("37","21","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:35:\"[_site_title] <wordpress@tmusfc.jp>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:150:\"メッセージ本文:
[your-message]

-- 
このメールは [_site_title] ([_site_url]) のお問い合わせフォームから送信されました\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `wp20210827044706_postmeta` VALUES("38","21","_messages","a:22:{s:12:\"mail_sent_ok\";s:66:\"ありがとうございます、参加予約を承りました。\";s:12:\"mail_sent_ng\";s:87:\"メッセージの送信に失敗しました。入力項目をご確認ください。\";s:16:\"validation_error\";s:81:\"入力内容に問題があります。確認して再度お試しください。\";s:4:\"spam\";s:84:\"メッセージの送信に失敗しました。後でまたお試しください。\";s:12:\"accept_terms\";s:66:\"メッセージを送信する前に承諾確認が必要です。\";s:16:\"invalid_required\";s:42:\"必須項目に入力してください。\";s:16:\"invalid_too_long\";s:48:\"入力されたテキストが長すぎます。\";s:17:\"invalid_too_short\";s:48:\"入力されたテキストが短すぎます。\";s:13:\"upload_failed\";s:81:\"ファイルのアップロード時に不明なエラーが発生しました。\";s:24:\"upload_file_type_invalid\";s:66:\"この形式のファイルはアップロードできません。\";s:21:\"upload_file_too_large\";s:36:\"ファイルが大きすぎます。\";s:23:\"upload_failed_php_error\";s:72:\"ファイルのアップロード中にエラーが発生しました。\";s:12:\"invalid_date\";s:45:\"日付の形式が正しくありません。\";s:14:\"date_too_early\";s:42:\"選択された日付は早すぎます。\";s:13:\"date_too_late\";s:42:\"選択された日付は遅すぎます。\";s:14:\"invalid_number\";s:45:\"数値の形式に間違いがあります。\";s:16:\"number_too_small\";s:45:\"入力された数値が小さすぎます。\";s:16:\"number_too_large\";s:48:\"数値が最大許容値を超えています。\";s:23:\"quiz_answer_not_correct\";s:48:\"クイズの答えが正しくありません。\";s:13:\"invalid_email\";s:66:\"入力されたメールアドレスに間違いがあります。\";s:11:\"invalid_url\";s:34:\"URL に間違いがあります。\";s:11:\"invalid_tel\";s:42:\"電話番号に間違いがあります。\";}");
INSERT INTO `wp20210827044706_postmeta` VALUES("39","21","_additional_settings","");
INSERT INTO `wp20210827044706_postmeta` VALUES("40","21","_locale","ja");
INSERT INTO `wp20210827044706_postmeta` VALUES("41","22","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%83%83%e3%82%af%e3%81%a7%e3%82%b5%e3%82%a4%e3%83%88%e3%82%92%e4%bd%9c%e6%88%90");
INSERT INTO `wp20210827044706_postmeta` VALUES("42","22","_customize_changeset_uuid","11d02196-8baf-4d6a-9d67-f295c7fc573a");
INSERT INTO `wp20210827044706_postmeta` VALUES("43","23","_customize_draft_post_name","%e4%bc%9a%e7%a4%be%e6%a6%82%e8%a6%81");
INSERT INTO `wp20210827044706_postmeta` VALUES("44","23","_customize_changeset_uuid","11d02196-8baf-4d6a-9d67-f295c7fc573a");
INSERT INTO `wp20210827044706_postmeta` VALUES("45","24","_customize_draft_post_name","%e3%81%8a%e5%95%8f%e3%81%84%e5%90%88%e3%82%8f%e3%81%9b");
INSERT INTO `wp20210827044706_postmeta` VALUES("46","24","_customize_changeset_uuid","11d02196-8baf-4d6a-9d67-f295c7fc573a");
INSERT INTO `wp20210827044706_postmeta` VALUES("47","25","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%82%b0");
INSERT INTO `wp20210827044706_postmeta` VALUES("48","25","_customize_changeset_uuid","11d02196-8baf-4d6a-9d67-f295c7fc573a");
INSERT INTO `wp20210827044706_postmeta` VALUES("49","27","_customize_draft_post_name","asa");
INSERT INTO `wp20210827044706_postmeta` VALUES("50","27","_customize_changeset_uuid","11d02196-8baf-4d6a-9d67-f295c7fc573a");
INSERT INTO `wp20210827044706_postmeta` VALUES("51","19","_customize_restore_dismissed","1");
INSERT INTO `wp20210827044706_postmeta` VALUES("52","28","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%83%83%e3%82%af%e3%81%a7%e3%82%b5%e3%82%a4%e3%83%88%e3%82%92%e4%bd%9c%e6%88%90");
INSERT INTO `wp20210827044706_postmeta` VALUES("53","28","_customize_changeset_uuid","4d0d35aa-1cba-4f47-9a9c-1f3e41d1e5d4");
INSERT INTO `wp20210827044706_postmeta` VALUES("54","29","_customize_draft_post_name","%e4%bc%9a%e7%a4%be%e6%a6%82%e8%a6%81");
INSERT INTO `wp20210827044706_postmeta` VALUES("55","29","_customize_changeset_uuid","4d0d35aa-1cba-4f47-9a9c-1f3e41d1e5d4");
INSERT INTO `wp20210827044706_postmeta` VALUES("56","30","_customize_draft_post_name","%e3%81%8a%e5%95%8f%e3%81%84%e5%90%88%e3%82%8f%e3%81%9b");
INSERT INTO `wp20210827044706_postmeta` VALUES("57","30","_customize_changeset_uuid","4d0d35aa-1cba-4f47-9a9c-1f3e41d1e5d4");
INSERT INTO `wp20210827044706_postmeta` VALUES("58","31","_customize_draft_post_name","%e3%83%96%e3%83%ad%e3%82%b0");
INSERT INTO `wp20210827044706_postmeta` VALUES("59","31","_customize_changeset_uuid","4d0d35aa-1cba-4f47-9a9c-1f3e41d1e5d4");
INSERT INTO `wp20210827044706_postmeta` VALUES("60","26","_customize_restore_dismissed","1");
INSERT INTO `wp20210827044706_postmeta` VALUES("61","33","_edit_lock","1630445758:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("62","32","_customize_restore_dismissed","1");
INSERT INTO `wp20210827044706_postmeta` VALUES("63","2","_edit_lock","1630300648:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("64","35","_edit_lock","1630301077:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("65","35","_wp_trash_meta_status","publish");
INSERT INTO `wp20210827044706_postmeta` VALUES("66","35","_wp_trash_meta_time","1630301084");
INSERT INTO `wp20210827044706_postmeta` VALUES("67","36","_wp_attached_file","2021/08/memphis-colorful.png");
INSERT INTO `wp20210827044706_postmeta` VALUES("68","36","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:400;s:4:\"file\";s:28:\"2021/08/memphis-colorful.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"memphis-colorful-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"memphis-colorful-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp20210827044706_postmeta` VALUES("69","36","_wp_attachment_is_custom_background","twentytwentyone");
INSERT INTO `wp20210827044706_postmeta` VALUES("70","37","_wp_trash_meta_status","publish");
INSERT INTO `wp20210827044706_postmeta` VALUES("71","37","_wp_trash_meta_time","1630301416");
INSERT INTO `wp20210827044706_postmeta` VALUES("72","38","_edit_lock","1630302933:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("73","3","_edit_lock","1630429426:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("74","39","_edit_lock","1630429468:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("75","3","_wp_suggested_privacy_policy_content","a:3:{s:11:\"plugin_name\";s:9:\"WordPress\";s:11:\"policy_text\";s:5533:\"<h2>私たちについて</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>私たちのサイトアドレスは http://tmusfc.jp です。</p><h2>コメント</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>訪問者がこのサイトにコメントを残す際、コメントフォームに表示されているデータ、そしてスパム検出に役立てるための IP アドレスとブラウザーユーザーエージェント文字列を収集します。</p><p>メールアドレスから作成される匿名化された (「ハッシュ」とも呼ばれる) 文字列は、あなたが Gravatar サービスを使用中かどうか確認するため同サービスに提供されることがあります。同サービスのプライバシーポリシーは https://automattic.com/privacy/ にあります。コメントが承認されると、プロフィール画像がコメントとともに一般公開されます。</p><h2>メディア</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>サイトに画像をアップロードする際、位置情報 (EXIF GPS) を含む画像をアップロードするべきではありません。サイトの訪問者は、サイトから画像をダウンロードして位置データを抽出することができます。</p><h2>Cookie</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>サイトにコメントを残す際、お名前、メールアドレス、サイトを Cookie に保存することにオプトインできます。これはあなたの便宜のためであり、他のコメントを残す際に詳細情報を再入力する手間を省きます。この Cookie は1年間保持されます。</p><p>ログインページを訪問すると、お使いのブラウザーが Cookie を受け入れられるかを判断するために一時 Cookie を設定します。この Cookie は個人データを含んでおらず、ブラウザーを閉じると廃棄されます。</p><p>ログインの際さらに、ログイン情報と画面表示情報を保持するため、私たちはいくつかの Cookie を設定します。ログイン Cookie は2日間、画面表示オプション Cookie は1年間保持されます。「ログイン状態を保存する」を選択した場合、ログイン情報は2週間維持されます。ログアウトするとログイン Cookie は消去されます。</p><p>もし投稿を編集または公開すると、さらなる Cookie がブラウザーに保存されます。この Cookie は個人データを含まず、単に変更した投稿の ID を示すものです。1日で有効期限が切れます。</p><h2>他サイトからの埋め込みコンテンツ</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>このサイトの投稿には埋め込みコンテンツ (動画、画像、投稿など) が含まれます。他サイトからの埋め込みコンテンツは、訪問者がそのサイトを訪れた場合とまったく同じように振る舞います。</p><p>これらのサイトは、あなたのデータの収集、Cookie の使用、サードパーティによる追加トラッキングの埋め込み、埋め込みコンテンツとのやりとりの監視を行うことがあります。アカウントを使ってそのサイトにログイン中の場合、埋め込みコンテンツとのやりとりのトラッキングも含まれます。</p><h2>あなたのデータの共有先</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>パスワードリセットをリクエストすると、IP アドレスがリセット用のメールに含まれます。</p><h2>データを保存する期間</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>あなたがコメントを残すと、コメントとそのメタデータが無期限に保持されます。これは、モデレーションキューにコメントを保持しておく代わりに、フォローアップのコメントを自動的に認識し承認できるようにするためです。</p><p>このサイトに登録したユーザーがいる場合、その方がユーザープロフィールページで提供した個人情報を保存します。すべてのユーザーは自分の個人情報を表示、編集、削除することができます (ただしユーザー名は変更することができません)。サイト管理者もそれらの情報を表示、編集できます。</p><h2>データに対するあなたの権利</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>このサイトのアカウントを持っているか、サイトにコメントを残したことがある場合、私たちが保持するあなたについての個人データ (提供したすべてのデータを含む) をエクスポートファイルとして受け取るリクエストを行うことができます。また、個人データの消去リクエストを行うこともできます。これには、管理、法律、セキュリティ目的のために保持する義務があるデータは含まれません。</p><h2>あなたのデータの送信先</h2><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>訪問者によるコメントは、自動スパム検出サービスを通じて確認を行う場合があります。</p>\";s:5:\"added\";i:1630442485;}");
INSERT INTO `wp20210827044706_postmeta` VALUES("76","3","_wp_suggested_privacy_policy_content","a:3:{s:11:\"plugin_name\";s:17:\"Twenty Twenty-One\";s:11:\"policy_text\";s:653:\"<p class=\"privacy-policy-tutorial\">Twenty Twenty-One は、ダークモードのサポートが有効な場合に LocalStorage を使用します。</p>
<p><strong class=\"privacy-policy-tutorial\">提案テキスト:</strong> このサイトでは、ダークモード対応のオン/オフ時の設定を保存するために LocalStorage を使用しています。<br>LocalStorage は設定を動作させるために必要なもので、ユーザーがダークモードボタンをクリックしたときにのみ使用されます。<br>データベースにデータが保存されたり、転送されたりすることはありません。</p>
\";s:5:\"added\";i:1630442485;}");
INSERT INTO `wp20210827044706_postmeta` VALUES("77","40","_edit_last","1");
INSERT INTO `wp20210827044706_postmeta` VALUES("78","40","options","a:5:{s:4:\"type\";s:6:\"header\";s:7:\"linking\";s:8:\"internal\";s:8:\"priority\";s:1:\"5\";s:4:\"side\";s:8:\"frontend\";s:8:\"language\";s:3:\"css\";}");
INSERT INTO `wp20210827044706_postmeta` VALUES("79","40","_edit_lock","1630601027:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("80","40","_oembed_798e08a4071c0cd6a0e499af80a94e02","{{unknown}}");
INSERT INTO `wp20210827044706_postmeta` VALUES("81","42","_edit_lock","1630444088:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("82","42","_wp_trash_meta_status","draft");
INSERT INTO `wp20210827044706_postmeta` VALUES("83","42","_wp_trash_meta_time","1630444130");
INSERT INTO `wp20210827044706_postmeta` VALUES("84","42","_wp_desired_post_slug","");
INSERT INTO `wp20210827044706_postmeta` VALUES("85","1","_edit_lock","1630444001:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("86","45","_edit_lock","1630444765:1");
INSERT INTO `wp20210827044706_postmeta` VALUES("87","46","_wp_attached_file","2021/09/IMG_7420-scaled.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("88","46","_wp_attachment_metadata","a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:27:\"2021/09/IMG_7420-scaled.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"IMG_7420-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"IMG_7420-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"IMG_7420-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"IMG_7420-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"IMG_7420-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"IMG_7420-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"IMG_7420-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"E-M5MarkII\";s:7:\"caption\";s:22:\"OLYMPUS DIGITAL CAMERA\";s:17:\"created_timestamp\";s:10:\"1572892420\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"20\";s:3:\"iso\";s:4:\"3200\";s:13:\"shutter_speed\";s:5:\"0.001\";s:5:\"title\";s:22:\"OLYMPUS DIGITAL CAMERA\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:12:\"IMG_7420.jpg\";}");
INSERT INTO `wp20210827044706_postmeta` VALUES("89","46","_wp_attachment_image_alt","TMU-SFC メンバー");
INSERT INTO `wp20210827044706_postmeta` VALUES("90","47","_wp_attached_file","2021/09/P6223651-scaled.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("91","47","_wp_attachment_metadata","a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:27:\"2021/09/P6223651-scaled.jpg\";s:5:\"sizes\";a:1:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"P6223651-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"E-M5MarkII\";s:7:\"caption\";s:22:\"OLYMPUS DIGITAL CAMERA\";s:17:\"created_timestamp\";s:10:\"1561213366\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"40\";s:3:\"iso\";s:4:\"2500\";s:13:\"shutter_speed\";s:4:\"0.01\";s:5:\"title\";s:22:\"OLYMPUS DIGITAL CAMERA\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:12:\"P6223651.jpg\";}");
INSERT INTO `wp20210827044706_postmeta` VALUES("92","48","_wp_attached_file","2021/09/P6223651-1-scaled.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("93","48","_wp_attachment_metadata","a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:29:\"2021/09/P6223651-1-scaled.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"P6223651-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"P6223651-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"P6223651-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"P6223651-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:24:\"P6223651-1-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:24:\"P6223651-1-2048x1536.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:24:\"P6223651-1-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"E-M5MarkII\";s:7:\"caption\";s:22:\"OLYMPUS DIGITAL CAMERA\";s:17:\"created_timestamp\";s:10:\"1561213366\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"40\";s:3:\"iso\";s:4:\"2500\";s:13:\"shutter_speed\";s:4:\"0.01\";s:5:\"title\";s:22:\"OLYMPUS DIGITAL CAMERA\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:14:\"P6223651-1.jpg\";}");
INSERT INTO `wp20210827044706_postmeta` VALUES("94","48","_wp_attachment_image_alt","ビスマス結晶");
INSERT INTO `wp20210827044706_postmeta` VALUES("95","49","_wp_attached_file","2021/09/P6223702.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("96","50","_wp_attached_file","2021/09/P6223702-1.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("97","51","_wp_attached_file","2021/09/P6223702-2.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("98","52","_wp_attached_file","2021/09/P6223702-2-1.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("99","52","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1440;s:4:\"file\";s:24:\"2021/09/P6223702-2-1.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"P6223702-2-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"P6223702-2-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"P6223702-2-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"P6223702-2-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:26:\"P6223702-2-1-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:26:\"P6223702-2-1-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp20210827044706_postmeta` VALUES("100","52","_wp_attachment_image_alt","葉脈標本");
INSERT INTO `wp20210827044706_postmeta` VALUES("101","53","_wp_attached_file","2021/09/P6223658.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("104","56","_wp_attached_file","2021/09/P6223658-1.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("105","56","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1440;s:4:\"file\";s:22:\"2021/09/P6223658-1.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"P6223658-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"P6223658-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"P6223658-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"P6223658-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:24:\"P6223658-1-1536x1152.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:24:\"P6223658-1-1568x1176.jpg\";s:5:\"width\";i:1568;s:6:\"height\";i:1176;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp20210827044706_postmeta` VALUES("106","56","_wp_attachment_image_alt","電気でお絵かき");
INSERT INTO `wp20210827044706_postmeta` VALUES("107","57","_wp_attached_file","2021/09/P8054173.jpg");
INSERT INTO `wp20210827044706_postmeta` VALUES("108","57","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:960;s:4:\"file\";s:20:\"2021/09/P8054173.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"P8054173-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"P8054173-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"P8054173-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"P8054173-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"E-M5MarkII\";s:7:\"caption\";s:22:\"OLYMPUS DIGITAL CAMERA\";s:17:\"created_timestamp\";s:10:\"1565020948\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"23\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:3:\"0.5\";s:5:\"title\";s:22:\"OLYMPUS DIGITAL CAMERA\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp20210827044706_postmeta` VALUES("109","57","_wp_attachment_image_alt","ケミカルライト");


DROP TABLE IF EXISTS `wp20210827044706_posts`;

CREATE TABLE `wp20210827044706_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_posts` VALUES("1","1","2021-08-27 05:14:11","2021-08-26 20:14:11","<!-- wp:paragraph -->
<p>WordPress へようこそ。こちらは最初の投稿です。編集または削除し、コンテンツ作成を始めてください。</p>
<!-- /wp:paragraph -->","Hello world!","","publish","open","open","","hello-world","","","2021-08-27 05:14:11","2021-08-26 20:14:11","","0","http://tmusfc.jp/?p=1","0","post","","1");
INSERT INTO `wp20210827044706_posts` VALUES("2","1","2021-08-27 05:14:11","2021-08-26 20:14:11","<!-- wp:paragraph -->
<p>これはサンプルページです。同じ位置に固定され、(多くのテーマでは) サイトナビゲーションメニューに含まれる点がブログ投稿とは異なります。まずは、サイト訪問者に対して自分のことを説明する自己紹介ページを作成するのが一般的です。たとえば以下のようなものです。</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>はじめまして。昼間はバイク便のメッセンジャーとして働いていますが、俳優志望でもあります。これは僕のサイトです。ロサンゼルスに住み、ジャックという名前のかわいい犬を飼っています。好きなものはピニャコラーダ、そして通り雨に濡れること。</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>または、このようなものです。</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>XYZ 小道具株式会社は1971年の創立以来、高品質の小道具を皆様にご提供させていただいています。ゴッサム・シティに所在する当社では2,000名以上の社員が働いており、様々な形で地域のコミュニティへ貢献しています。</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>新しく WordPress ユーザーになった方は、<a href=\"http://tmusfc.jp/wp-admin/\">ダッシュボード</a>へ行ってこのページを削除し、独自のコンテンツを含む新しいページを作成してください。それでは、お楽しみください !</p>
<!-- /wp:paragraph -->","サンプルページ","","publish","closed","open","","sample-page","","","2021-08-27 05:14:11","2021-08-26 20:14:11","","0","http://tmusfc.jp/?page_id=2","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("3","1","2021-08-27 05:14:11","2021-08-26 20:14:11","<!-- wp:heading --><h2>私たちについて</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>私たちのサイトアドレスは http://tmusfc.jp です。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>コメント</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>訪問者がこのサイトにコメントを残す際、コメントフォームに表示されているデータ、そしてスパム検出に役立てるための IP アドレスとブラウザーユーザーエージェント文字列を収集します。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>メールアドレスから作成される匿名化された (「ハッシュ」とも呼ばれる) 文字列は、あなたが Gravatar サービスを使用中かどうか確認するため同サービスに提供されることがあります。同サービスのプライバシーポリシーは https://automattic.com/privacy/ にあります。コメントが承認されると、プロフィール画像がコメントとともに一般公開されます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>メディア</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>サイトに画像をアップロードする際、位置情報 (EXIF GPS) を含む画像をアップロードするべきではありません。サイトの訪問者は、サイトから画像をダウンロードして位置データを抽出することができます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookie</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>サイトにコメントを残す際、お名前、メールアドレス、サイトを Cookie に保存することにオプトインできます。これはあなたの便宜のためであり、他のコメントを残す際に詳細情報を再入力する手間を省きます。この Cookie は1年間保持されます。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>ログインページを訪問すると、お使いのブラウザーが Cookie を受け入れられるかを判断するために一時 Cookie を設定します。この Cookie は個人データを含んでおらず、ブラウザーを閉じると廃棄されます。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>ログインの際さらに、ログイン情報と画面表示情報を保持するため、私たちはいくつかの Cookie を設定します。ログイン Cookie は2日間、画面表示オプション Cookie は1年間保持されます。「ログイン状態を保存する」を選択した場合、ログイン情報は2週間維持されます。ログアウトするとログイン Cookie は消去されます。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>もし投稿を編集または公開すると、さらなる Cookie がブラウザーに保存されます。この Cookie は個人データを含まず、単に変更した投稿の ID を示すものです。1日で有効期限が切れます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>他サイトからの埋め込みコンテンツ</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>このサイトの投稿には埋め込みコンテンツ (動画、画像、投稿など) が含まれます。他サイトからの埋め込みコンテンツは、訪問者がそのサイトを訪れた場合とまったく同じように振る舞います。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>これらのサイトは、あなたのデータの収集、Cookie の使用、サードパーティによる追加トラッキングの埋め込み、埋め込みコンテンツとのやりとりの監視を行うことがあります。アカウントを使ってそのサイトにログイン中の場合、埋め込みコンテンツとのやりとりのトラッキングも含まれます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>あなたのデータの共有先</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>パスワードリセットをリクエストすると、IP アドレスがリセット用のメールに含まれます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>データを保存する期間</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>あなたがコメントを残すと、コメントとそのメタデータが無期限に保持されます。これは、モデレーションキューにコメントを保持しておく代わりに、フォローアップのコメントを自動的に認識し承認できるようにするためです。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>このサイトに登録したユーザーがいる場合、その方がユーザープロフィールページで提供した個人情報を保存します。すべてのユーザーは自分の個人情報を表示、編集、削除することができます (ただしユーザー名は変更することができません)。サイト管理者もそれらの情報を表示、編集できます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>データに対するあなたの権利</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>このサイトのアカウントを持っているか、サイトにコメントを残したことがある場合、私たちが保持するあなたについての個人データ (提供したすべてのデータを含む) をエクスポートファイルとして受け取るリクエストを行うことができます。また、個人データの消去リクエストを行うこともできます。これには、管理、法律、セキュリティ目的のために保持する義務があるデータは含まれません。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>あなたのデータの送信先</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">提案テキスト: </strong>訪問者によるコメントは、自動スパム検出サービスを通じて確認を行う場合があります。</p><!-- /wp:paragraph -->","プライバシーポリシー","","draft","closed","open","","privacy-policy","","","2021-08-27 05:14:11","2021-08-26 20:14:11","","0","http://tmusfc.jp/?page_id=3","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("4","1","2021-08-27 05:14:53","0000-00-00 00:00:00","","自動下書き","","auto-draft","open","open","","","","","2021-08-27 05:14:53","0000-00-00 00:00:00","","0","http://tmusfc.jp/?p=4","0","post","","0");
INSERT INTO `wp20210827044706_posts` VALUES("5","1","2021-08-27 05:15:04","0000-00-00 00:00:00","
					<!-- wp:heading {\"align\":\"wide\",\"fontSize\":\"gigantic\",\"style\":{\"typography\":{\"lineHeight\":\"1.1\"}}} -->
					<h2 class=\"alignwide has-text-align-wide has-gigantic-font-size\" style=\"line-height:1.1\">ブロックでサイトを作成</h2>
					<!-- /wp:heading -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-columns-overlap\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-center is-style-twentytwentyone-columns-overlap\"><!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\"} -->
					<figure class=\"wp-block-image alignfull size-large\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg\" alt=\"「立葵」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\",\"className\":\"is-style-twentytwentyone-image-frame\"} -->
					<figure class=\"wp-block-image alignfull size-large is-style-twentytwentyone-image-frame\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg\" alt=\"「ブローニュの森で」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"sizeSlug\":\"large\",\"className\":\"alignfull size-full is-style-twentytwentyone-border\"} -->
					<figure class=\"wp-block-image size-large alignfull size-full is-style-twentytwentyone-border\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg\" alt=\"「モーブで若い女性」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":50} -->
					<div style=\"height:50px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"top\",\"align\":\"wide\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>ブロックパターンを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>ブロックパターンは、あらかじめデザインされたブロックのグループです。追加するには、エディターの上部にあるツールバーでブロック追加ボタン [+] を選択してください。そして、検索バーの下のパターンタブに切り替え、パターンを選択してください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>画像にフレームを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマには、コンテンツのためのスタイリッシュなフレームが含まれています。画像ブロックを選択した状態で、エディターのサイドバーにある「スタイル」パネルを開いてください。その後、「フレーム」ブロックスタイルを選択して有効化します。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>重ね合わせカラム</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマにはさらに、カラムブロックの重ね合わせスタイルも含まれます。カラムブロックを選択した状態でエディターのサイドバーの「スタイル」パネルを開きます。「重ね合わせ」ブロックスタイルを選択して試してみてください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:cover {\"overlayColor\":\"green\",\"contentPosition\":\"center center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-border\"} -->
					<div class=\"wp-block-cover alignwide has-green-background-color has-background-dim is-style-twentytwentyone-border\"><div class=\"wp-block-cover__inner-container\"><!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:paragraph {\"fontSize\":\"huge\"} -->
					<p class=\"has-huge-font-size\">サポートが必要ですか ?</p>
					<!-- /wp:paragraph -->

					<!-- wp:spacer {\"height\":75} -->
					<div style=\"height:75px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns -->
					<div class=\"wp-block-columns\"><!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/article/twenty-twenty-one/\">テーマのドキュメンテーションを読む</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/theme/twentytwentyone/\">サポートフォーラムを確認する</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer --></div></div>
					<!-- /wp:cover -->","ブロックでサイトを作成","","auto-draft","closed","closed","","","","","2021-08-27 05:15:04","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=5","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("6","1","2021-08-27 05:15:04","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>あなたは自身や自身の作品を紹介したいアーティストかもしれないし、あるいは、説明するべきミッションを持つ企業かもしれません。</p>
<!-- /wp:paragraph -->","会社概要","","auto-draft","closed","closed","","","","","2021-08-27 05:15:04","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=6","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("7","1","2021-08-27 05:15:04","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>これは、住所や電話番号などの基本的な連絡先情報が記載されたページです。 問い合わせフォームを追加するプラグインを試すこともできます。</p>
<!-- /wp:paragraph -->","お問い合わせ","","auto-draft","closed","closed","","","","","2021-08-27 05:15:04","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=7","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("8","1","2021-08-27 05:15:04","0000-00-00 00:00:00","","ブログ","","auto-draft","closed","closed","","","","","2021-08-27 05:15:04","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=8","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("9","1","2021-08-27 05:15:04","0000-00-00 00:00:00","{
    \"nav_menus_created_posts\": {
        \"starter_content\": true,
        \"value\": [
            5,
            6,
            7,
            8
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30e1\\u30a4\\u30f3\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu_item[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"custom\",
            \"title\": \"\\u30db\\u30fc\\u30e0\\u30da\\u30fc\\u30b8\",
            \"url\": \"http://tmusfc.jp/\",
            \"position\": 0,
            \"nav_menu_term_id\": -1,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu_item[-2]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 6,
            \"position\": 1,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u4f1a\\u793e\\u6982\\u8981\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu_item[-3]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 8,
            \"position\": 2,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u30d6\\u30ed\\u30b0\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu_item[-4]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 7,
            \"position\": 3,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"twentytwentyone::nav_menu_locations[primary]\": {
        \"starter_content\": true,
        \"value\": -1,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30b5\\u30d6\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu_item[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Facebook\",
            \"url\": \"https://www.facebook.com/wordpress\",
            \"position\": 0,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu_item[-6]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Twitter\",
            \"url\": \"https://twitter.com/wordpress\",
            \"position\": 1,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu_item[-7]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Instagram\",
            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",
            \"position\": 2,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"nav_menu_item[-8]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"\\u30e1\\u30fc\\u30eb\",
            \"url\": \"mailto:wordpress@example.com\",
            \"position\": 3,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"twentytwentyone::nav_menu_locations[footer]\": {
        \"starter_content\": true,
        \"value\": -5,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"show_on_front\": {
        \"starter_content\": true,
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"page_on_front\": {
        \"starter_content\": true,
        \"value\": 5,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    },
    \"page_for_posts\": {
        \"starter_content\": true,
        \"value\": 8,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:04\"
    }
}","","","auto-draft","closed","closed","","6ec6cd79-db21-4dfb-8f78-9428c309a05b","","","2021-08-27 05:15:04","0000-00-00 00:00:00","","0","http://tmusfc.jp/?p=9","0","customize_changeset","","0");
INSERT INTO `wp20210827044706_posts` VALUES("10","1","2021-08-27 05:15:35","0000-00-00 00:00:00","
					<!-- wp:heading {\"align\":\"wide\",\"fontSize\":\"gigantic\",\"style\":{\"typography\":{\"lineHeight\":\"1.1\"}}} -->
					<h2 class=\"alignwide has-text-align-wide has-gigantic-font-size\" style=\"line-height:1.1\">ブロックでサイトを作成</h2>
					<!-- /wp:heading -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-columns-overlap\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-center is-style-twentytwentyone-columns-overlap\"><!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\"} -->
					<figure class=\"wp-block-image alignfull size-large\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg\" alt=\"「立葵」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\",\"className\":\"is-style-twentytwentyone-image-frame\"} -->
					<figure class=\"wp-block-image alignfull size-large is-style-twentytwentyone-image-frame\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg\" alt=\"「ブローニュの森で」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"sizeSlug\":\"large\",\"className\":\"alignfull size-full is-style-twentytwentyone-border\"} -->
					<figure class=\"wp-block-image size-large alignfull size-full is-style-twentytwentyone-border\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg\" alt=\"「モーブで若い女性」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":50} -->
					<div style=\"height:50px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"top\",\"align\":\"wide\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>ブロックパターンを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>ブロックパターンは、あらかじめデザインされたブロックのグループです。追加するには、エディターの上部にあるツールバーでブロック追加ボタン [+] を選択してください。そして、検索バーの下のパターンタブに切り替え、パターンを選択してください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>画像にフレームを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマには、コンテンツのためのスタイリッシュなフレームが含まれています。画像ブロックを選択した状態で、エディターのサイドバーにある「スタイル」パネルを開いてください。その後、「フレーム」ブロックスタイルを選択して有効化します。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>重ね合わせカラム</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマにはさらに、カラムブロックの重ね合わせスタイルも含まれます。カラムブロックを選択した状態でエディターのサイドバーの「スタイル」パネルを開きます。「重ね合わせ」ブロックスタイルを選択して試してみてください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:cover {\"overlayColor\":\"green\",\"contentPosition\":\"center center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-border\"} -->
					<div class=\"wp-block-cover alignwide has-green-background-color has-background-dim is-style-twentytwentyone-border\"><div class=\"wp-block-cover__inner-container\"><!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:paragraph {\"fontSize\":\"huge\"} -->
					<p class=\"has-huge-font-size\">サポートが必要ですか ?</p>
					<!-- /wp:paragraph -->

					<!-- wp:spacer {\"height\":75} -->
					<div style=\"height:75px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns -->
					<div class=\"wp-block-columns\"><!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/article/twenty-twenty-one/\">テーマのドキュメンテーションを読む</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/theme/twentytwentyone/\">サポートフォーラムを確認する</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer --></div></div>
					<!-- /wp:cover -->","ブロックでサイトを作成","","auto-draft","closed","closed","","","","","2021-08-27 05:15:35","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=10","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("11","1","2021-08-27 05:15:35","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>あなたは自身や自身の作品を紹介したいアーティストかもしれないし、あるいは、説明するべきミッションを持つ企業かもしれません。</p>
<!-- /wp:paragraph -->","会社概要","","auto-draft","closed","closed","","","","","2021-08-27 05:15:35","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=11","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("12","1","2021-08-27 05:15:35","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>これは、住所や電話番号などの基本的な連絡先情報が記載されたページです。 問い合わせフォームを追加するプラグインを試すこともできます。</p>
<!-- /wp:paragraph -->","お問い合わせ","","auto-draft","closed","closed","","","","","2021-08-27 05:15:35","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=12","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("13","1","2021-08-27 05:15:35","0000-00-00 00:00:00","","ブログ","","auto-draft","closed","closed","","","","","2021-08-27 05:15:35","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=13","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("14","1","2021-08-27 05:15:35","0000-00-00 00:00:00","{
    \"nav_menus_created_posts\": {
        \"starter_content\": true,
        \"value\": [
            10,
            11,
            12,
            13
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30e1\\u30a4\\u30f3\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu_item[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"custom\",
            \"title\": \"\\u30db\\u30fc\\u30e0\\u30da\\u30fc\\u30b8\",
            \"url\": \"http://tmusfc.jp/\",
            \"position\": 0,
            \"nav_menu_term_id\": -1,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu_item[-2]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 11,
            \"position\": 1,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u4f1a\\u793e\\u6982\\u8981\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu_item[-3]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 13,
            \"position\": 2,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u30d6\\u30ed\\u30b0\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu_item[-4]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 12,
            \"position\": 3,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"twentytwentyone::nav_menu_locations[primary]\": {
        \"starter_content\": true,
        \"value\": -1,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30b5\\u30d6\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu_item[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Facebook\",
            \"url\": \"https://www.facebook.com/wordpress\",
            \"position\": 0,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu_item[-6]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Twitter\",
            \"url\": \"https://twitter.com/wordpress\",
            \"position\": 1,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu_item[-7]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Instagram\",
            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",
            \"position\": 2,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"nav_menu_item[-8]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"\\u30e1\\u30fc\\u30eb\",
            \"url\": \"mailto:wordpress@example.com\",
            \"position\": 3,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"twentytwentyone::nav_menu_locations[footer]\": {
        \"starter_content\": true,
        \"value\": -5,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"show_on_front\": {
        \"starter_content\": true,
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"page_on_front\": {
        \"starter_content\": true,
        \"value\": 10,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    },
    \"page_for_posts\": {
        \"starter_content\": true,
        \"value\": 13,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:15:35\"
    }
}","","","auto-draft","closed","closed","","2ad8bba3-3ac6-4881-ba08-9eb0bb7b3889","","","2021-08-27 05:15:35","0000-00-00 00:00:00","","0","http://tmusfc.jp/?p=14","0","customize_changeset","","0");
INSERT INTO `wp20210827044706_posts` VALUES("15","1","2021-08-27 05:16:43","0000-00-00 00:00:00","
					<!-- wp:heading {\"align\":\"wide\",\"fontSize\":\"gigantic\",\"style\":{\"typography\":{\"lineHeight\":\"1.1\"}}} -->
					<h2 class=\"alignwide has-text-align-wide has-gigantic-font-size\" style=\"line-height:1.1\">ブロックでサイトを作成</h2>
					<!-- /wp:heading -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-columns-overlap\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-center is-style-twentytwentyone-columns-overlap\"><!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\"} -->
					<figure class=\"wp-block-image alignfull size-large\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg\" alt=\"「立葵」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\",\"className\":\"is-style-twentytwentyone-image-frame\"} -->
					<figure class=\"wp-block-image alignfull size-large is-style-twentytwentyone-image-frame\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg\" alt=\"「ブローニュの森で」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"sizeSlug\":\"large\",\"className\":\"alignfull size-full is-style-twentytwentyone-border\"} -->
					<figure class=\"wp-block-image size-large alignfull size-full is-style-twentytwentyone-border\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg\" alt=\"「モーブで若い女性」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":50} -->
					<div style=\"height:50px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"top\",\"align\":\"wide\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>ブロックパターンを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>ブロックパターンは、あらかじめデザインされたブロックのグループです。追加するには、エディターの上部にあるツールバーでブロック追加ボタン [+] を選択してください。そして、検索バーの下のパターンタブに切り替え、パターンを選択してください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>画像にフレームを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマには、コンテンツのためのスタイリッシュなフレームが含まれています。画像ブロックを選択した状態で、エディターのサイドバーにある「スタイル」パネルを開いてください。その後、「フレーム」ブロックスタイルを選択して有効化します。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>重ね合わせカラム</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマにはさらに、カラムブロックの重ね合わせスタイルも含まれます。カラムブロックを選択した状態でエディターのサイドバーの「スタイル」パネルを開きます。「重ね合わせ」ブロックスタイルを選択して試してみてください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:cover {\"overlayColor\":\"green\",\"contentPosition\":\"center center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-border\"} -->
					<div class=\"wp-block-cover alignwide has-green-background-color has-background-dim is-style-twentytwentyone-border\"><div class=\"wp-block-cover__inner-container\"><!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:paragraph {\"fontSize\":\"huge\"} -->
					<p class=\"has-huge-font-size\">サポートが必要ですか ?</p>
					<!-- /wp:paragraph -->

					<!-- wp:spacer {\"height\":75} -->
					<div style=\"height:75px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns -->
					<div class=\"wp-block-columns\"><!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/article/twenty-twenty-one/\">テーマのドキュメンテーションを読む</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/theme/twentytwentyone/\">サポートフォーラムを確認する</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer --></div></div>
					<!-- /wp:cover -->","ブロックでサイトを作成","","auto-draft","closed","closed","","","","","2021-08-27 05:16:43","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=15","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("16","1","2021-08-27 05:16:43","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>あなたは自身や自身の作品を紹介したいアーティストかもしれないし、あるいは、説明するべきミッションを持つ企業かもしれません。</p>
<!-- /wp:paragraph -->","会社概要","","auto-draft","closed","closed","","","","","2021-08-27 05:16:43","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=16","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("17","1","2021-08-27 05:16:43","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>これは、住所や電話番号などの基本的な連絡先情報が記載されたページです。 問い合わせフォームを追加するプラグインを試すこともできます。</p>
<!-- /wp:paragraph -->","お問い合わせ","","auto-draft","closed","closed","","","","","2021-08-27 05:16:43","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=17","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("18","1","2021-08-27 05:16:43","0000-00-00 00:00:00","","ブログ","","auto-draft","closed","closed","","","","","2021-08-27 05:16:43","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=18","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("19","1","2021-08-27 05:16:43","0000-00-00 00:00:00","{
    \"nav_menus_created_posts\": {
        \"starter_content\": true,
        \"value\": [
            15,
            16,
            17,
            18
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30e1\\u30a4\\u30f3\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu_item[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"custom\",
            \"title\": \"\\u30db\\u30fc\\u30e0\\u30da\\u30fc\\u30b8\",
            \"url\": \"http://tmusfc.jp/\",
            \"position\": 0,
            \"nav_menu_term_id\": -1,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu_item[-2]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 16,
            \"position\": 1,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u4f1a\\u793e\\u6982\\u8981\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu_item[-3]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 18,
            \"position\": 2,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u30d6\\u30ed\\u30b0\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu_item[-4]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 17,
            \"position\": 3,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"twentytwentyone::nav_menu_locations[primary]\": {
        \"starter_content\": true,
        \"value\": -1,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30b5\\u30d6\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu_item[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Facebook\",
            \"url\": \"https://www.facebook.com/wordpress\",
            \"position\": 0,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu_item[-6]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Twitter\",
            \"url\": \"https://twitter.com/wordpress\",
            \"position\": 1,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu_item[-7]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Instagram\",
            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",
            \"position\": 2,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"nav_menu_item[-8]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"\\u30e1\\u30fc\\u30eb\",
            \"url\": \"mailto:wordpress@example.com\",
            \"position\": 3,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"twentytwentyone::nav_menu_locations[footer]\": {
        \"starter_content\": true,
        \"value\": -5,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"show_on_front\": {
        \"starter_content\": true,
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"page_on_front\": {
        \"starter_content\": true,
        \"value\": 15,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    },
    \"page_for_posts\": {
        \"starter_content\": true,
        \"value\": 18,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-26 20:16:43\"
    }
}","","","auto-draft","closed","closed","","8c2d8777-fe77-4397-b29d-acaeaa84dde5","","","2021-08-27 05:16:43","0000-00-00 00:00:00","","0","http://tmusfc.jp/?p=19","0","customize_changeset","","0");
INSERT INTO `wp20210827044706_posts` VALUES("20","1","2021-08-30 13:56:31","2021-08-30 04:56:31","<label> 氏名
    [text* your-name] </label>

<label> メールアドレス
    [email* your-email] </label>

<label> 題名
    [text* your-subject] </label>

<label> メッセージ本文 (任意)
    [textarea your-message] </label>

[submit \"送信\"]
[_site_title] \"[your-subject]\"
[_site_title] <wordpress@tmusfc.jp>
差出人: [your-name] <[your-email]>
題名: [your-subject]

メッセージ本文:
[your-message]

-- 
このメールは [_site_title] ([_site_url]) のお問い合わせフォームから送信されました
[_site_admin_email]
Reply-To: [your-email]

0
0

[_site_title] \"[your-subject]\"
[_site_title] <wordpress@tmusfc.jp>
メッセージ本文:
[your-message]

-- 
このメールは [_site_title] ([_site_url]) のお問い合わせフォームから送信されました
[your-email]
Reply-To: [_site_admin_email]

0
0
ありがとうございます。メッセージは送信されました。
メッセージの送信に失敗しました。後でまたお試しください。
入力内容に問題があります。確認して再度お試しください。
メッセージの送信に失敗しました。後でまたお試しください。
メッセージを送信する前に承諾確認が必要です。
必須項目に入力してください。
入力されたテキストが長すぎます。
入力されたテキストが短すぎます。
ファイルのアップロード時に不明なエラーが発生しました。
この形式のファイルはアップロードできません。
ファイルが大きすぎます。
ファイルのアップロード中にエラーが発生しました。","コンタクトフォーム 1","","publish","closed","closed","","%e3%82%b3%e3%83%b3%e3%82%bf%e3%82%af%e3%83%88%e3%83%95%e3%82%a9%e3%83%bc%e3%83%a0-1","","","2021-08-30 13:56:31","2021-08-30 04:56:31","","0","http://tmusfc.jp/?post_type=wpcf7_contact_form&p=20","0","wpcf7_contact_form","","0");
INSERT INTO `wp20210827044706_posts` VALUES("21","1","2021-08-30 14:06:04","2021-08-30 05:06:04","<label> <b>代表者氏名(必須)</b>
    [text* your-name class:name placeholder \"お名前を入力してください\" ] </label>


<label> メールアドレス(必須)
[email* your-email class:email \"メールアドレスを入力してください\"] </label>


体験実験参加日（必須）
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]

参加実験を選ぶ(必須)
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加実験を選ぶ(必須)
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加時間帯を選ぶ(必須)
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]

<label> 質問内容 (任意)
    [textarea your-message class:message] </label>

[submit \"送信\"]
1
体験！！化学実験 \"[your-subject]\"
首都大学東京 化学実験サークル TMU-SFC <wordpress@tmusfc.jp>
jmpringonoki@gmail.com
差出人: [your-name]

差出人メールアドレス:[your-email]

参加日:[your-date]

参加時間:[your-time]

参加実験:[your-experiment]


質問など:[your-message]

-- 
このメールは [_site_title] ([_site_url]) のお問い合わせフォームから送信されました
Reply-To: [your-email]




[_site_title] \"[your-subject]\"
[_site_title] <wordpress@tmusfc.jp>
[your-email]
メッセージ本文:
[your-message]

-- 
このメールは [_site_title] ([_site_url]) のお問い合わせフォームから送信されました
Reply-To: [_site_admin_email]



ありがとうございます、参加予約を承りました。
メッセージの送信に失敗しました。入力項目をご確認ください。
入力内容に問題があります。確認して再度お試しください。
メッセージの送信に失敗しました。後でまたお試しください。
メッセージを送信する前に承諾確認が必要です。
必須項目に入力してください。
入力されたテキストが長すぎます。
入力されたテキストが短すぎます。
ファイルのアップロード時に不明なエラーが発生しました。
この形式のファイルはアップロードできません。
ファイルが大きすぎます。
ファイルのアップロード中にエラーが発生しました。
日付の形式が正しくありません。
選択された日付は早すぎます。
選択された日付は遅すぎます。
数値の形式に間違いがあります。
入力された数値が小さすぎます。
数値が最大許容値を超えています。
クイズの答えが正しくありません。
入力されたメールアドレスに間違いがあります。
URL に間違いがあります。
電話番号に間違いがあります。","2021　festival","","publish","closed","closed","","%e7%84%a1%e9%a1%8c","","","2021-09-01 06:38:14","2021-08-31 21:38:14","","0","http://tmusfc.jp/?post_type=wpcf7_contact_form&#038;p=21","0","wpcf7_contact_form","","0");
INSERT INTO `wp20210827044706_posts` VALUES("22","1","2021-08-30 14:07:05","0000-00-00 00:00:00","
					<!-- wp:heading {\"align\":\"wide\",\"fontSize\":\"gigantic\",\"style\":{\"typography\":{\"lineHeight\":\"1.1\"}}} -->
					<h2 class=\"alignwide has-text-align-wide has-gigantic-font-size\" style=\"line-height:1.1\">ブロックでサイトを作成</h2>
					<!-- /wp:heading -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-columns-overlap\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-center is-style-twentytwentyone-columns-overlap\"><!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\"} -->
					<figure class=\"wp-block-image alignfull size-large\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg\" alt=\"「立葵」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\",\"className\":\"is-style-twentytwentyone-image-frame\"} -->
					<figure class=\"wp-block-image alignfull size-large is-style-twentytwentyone-image-frame\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg\" alt=\"「ブローニュの森で」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"sizeSlug\":\"large\",\"className\":\"alignfull size-full is-style-twentytwentyone-border\"} -->
					<figure class=\"wp-block-image size-large alignfull size-full is-style-twentytwentyone-border\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg\" alt=\"「モーブで若い女性」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":50} -->
					<div style=\"height:50px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"top\",\"align\":\"wide\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>ブロックパターンを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>ブロックパターンは、あらかじめデザインされたブロックのグループです。追加するには、エディターの上部にあるツールバーでブロック追加ボタン [+] を選択してください。そして、検索バーの下のパターンタブに切り替え、パターンを選択してください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>画像にフレームを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマには、コンテンツのためのスタイリッシュなフレームが含まれています。画像ブロックを選択した状態で、エディターのサイドバーにある「スタイル」パネルを開いてください。その後、「フレーム」ブロックスタイルを選択して有効化します。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>重ね合わせカラム</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマにはさらに、カラムブロックの重ね合わせスタイルも含まれます。カラムブロックを選択した状態でエディターのサイドバーの「スタイル」パネルを開きます。「重ね合わせ」ブロックスタイルを選択して試してみてください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:cover {\"overlayColor\":\"green\",\"contentPosition\":\"center center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-border\"} -->
					<div class=\"wp-block-cover alignwide has-green-background-color has-background-dim is-style-twentytwentyone-border\"><div class=\"wp-block-cover__inner-container\"><!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:paragraph {\"fontSize\":\"huge\"} -->
					<p class=\"has-huge-font-size\">サポートが必要ですか ?</p>
					<!-- /wp:paragraph -->

					<!-- wp:spacer {\"height\":75} -->
					<div style=\"height:75px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns -->
					<div class=\"wp-block-columns\"><!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/article/twenty-twenty-one/\">テーマのドキュメンテーションを読む</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/theme/twentytwentyone/\">サポートフォーラムを確認する</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer --></div></div>
					<!-- /wp:cover -->","ブロックでサイトを作成","","auto-draft","closed","closed","","","","","2021-08-30 14:07:05","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=22","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("23","1","2021-08-30 14:07:05","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>あなたは自身や自身の作品を紹介したいアーティストかもしれないし、あるいは、説明するべきミッションを持つ企業かもしれません。</p>
<!-- /wp:paragraph -->","会社概要","","auto-draft","closed","closed","","","","","2021-08-30 14:07:05","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=23","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("24","1","2021-08-30 14:07:05","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>これは、住所や電話番号などの基本的な連絡先情報が記載されたページです。 問い合わせフォームを追加するプラグインを試すこともできます。</p>
<!-- /wp:paragraph -->","お問い合わせ","","auto-draft","closed","closed","","","","","2021-08-30 14:07:05","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=24","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("25","1","2021-08-30 14:07:05","0000-00-00 00:00:00","","ブログ","","auto-draft","closed","closed","","","","","2021-08-30 14:07:05","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=25","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("26","1","2021-08-30 14:07:05","0000-00-00 00:00:00","{
    \"nav_menus_created_posts\": {
        \"starter_content\": true,
        \"value\": [
            22,
            23,
            24,
            25
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30e1\\u30a4\\u30f3\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu_item[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"custom\",
            \"title\": \"\\u30db\\u30fc\\u30e0\\u30da\\u30fc\\u30b8\",
            \"url\": \"http://tmusfc.jp/\",
            \"position\": 0,
            \"nav_menu_term_id\": -1,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu_item[-2]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 23,
            \"position\": 1,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u4f1a\\u793e\\u6982\\u8981\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu_item[-3]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 25,
            \"position\": 2,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u30d6\\u30ed\\u30b0\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu_item[-4]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 24,
            \"position\": 3,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"twentytwentyone::nav_menu_locations[primary]\": {
        \"starter_content\": true,
        \"value\": -1,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30b5\\u30d6\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu_item[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Facebook\",
            \"url\": \"https://www.facebook.com/wordpress\",
            \"position\": 0,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu_item[-6]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Twitter\",
            \"url\": \"https://twitter.com/wordpress\",
            \"position\": 1,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu_item[-7]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Instagram\",
            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",
            \"position\": 2,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"nav_menu_item[-8]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"\\u30e1\\u30fc\\u30eb\",
            \"url\": \"mailto:wordpress@example.com\",
            \"position\": 3,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"twentytwentyone::nav_menu_locations[footer]\": {
        \"starter_content\": true,
        \"value\": -5,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"show_on_front\": {
        \"starter_content\": true,
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"page_on_front\": {
        \"starter_content\": true,
        \"value\": 22,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    },
    \"page_for_posts\": {
        \"starter_content\": true,
        \"value\": 25,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:07:05\"
    }
}","","","auto-draft","closed","closed","","11d02196-8baf-4d6a-9d67-f295c7fc573a","","","2021-08-30 14:07:05","0000-00-00 00:00:00","","0","http://tmusfc.jp/?p=26","0","customize_changeset","","0");
INSERT INTO `wp20210827044706_posts` VALUES("27","1","2021-08-30 14:08:16","0000-00-00 00:00:00","","asa","","auto-draft","closed","closed","","","","","2021-08-30 14:08:16","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=27","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("28","1","2021-08-30 14:08:49","0000-00-00 00:00:00","
					<!-- wp:heading {\"align\":\"wide\",\"fontSize\":\"gigantic\",\"style\":{\"typography\":{\"lineHeight\":\"1.1\"}}} -->
					<h2 class=\"alignwide has-text-align-wide has-gigantic-font-size\" style=\"line-height:1.1\">ブロックでサイトを作成</h2>
					<!-- /wp:heading -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-columns-overlap\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-center is-style-twentytwentyone-columns-overlap\"><!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\"} -->
					<figure class=\"wp-block-image alignfull size-large\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg\" alt=\"「立葵」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\",\"className\":\"is-style-twentytwentyone-image-frame\"} -->
					<figure class=\"wp-block-image alignfull size-large is-style-twentytwentyone-image-frame\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg\" alt=\"「ブローニュの森で」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"center\"} -->
					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:image {\"sizeSlug\":\"large\",\"className\":\"alignfull size-full is-style-twentytwentyone-border\"} -->
					<figure class=\"wp-block-image size-large alignfull size-full is-style-twentytwentyone-border\"><img src=\"http://tmusfc.jp/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg\" alt=\"「モーブで若い女性」ベルト・モリゾ作\"/></figure>
					<!-- /wp:image --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":50} -->
					<div style=\"height:50px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns {\"verticalAlignment\":\"top\",\"align\":\"wide\"} -->
					<div class=\"wp-block-columns alignwide are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>ブロックパターンを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>ブロックパターンは、あらかじめデザインされたブロックのグループです。追加するには、エディターの上部にあるツールバーでブロック追加ボタン [+] を選択してください。そして、検索バーの下のパターンタブに切り替え、パターンを選択してください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>画像にフレームを追加</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマには、コンテンツのためのスタイリッシュなフレームが含まれています。画像ブロックを選択した状態で、エディターのサイドバーにある「スタイル」パネルを開いてください。その後、「フレーム」ブロックスタイルを選択して有効化します。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column {\"verticalAlignment\":\"top\"} -->
					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->
					<h3>重ね合わせカラム</h3>
					<!-- /wp:heading -->

					<!-- wp:paragraph -->
					<p>Twenty Twenty-One テーマにはさらに、カラムブロックの重ね合わせスタイルも含まれます。カラムブロックを選択した状態でエディターのサイドバーの「スタイル」パネルを開きます。「重ね合わせ」ブロックスタイルを選択して試してみてください。</p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer -->
					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:cover {\"overlayColor\":\"green\",\"contentPosition\":\"center center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-border\"} -->
					<div class=\"wp-block-cover alignwide has-green-background-color has-background-dim is-style-twentytwentyone-border\"><div class=\"wp-block-cover__inner-container\"><!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:paragraph {\"fontSize\":\"huge\"} -->
					<p class=\"has-huge-font-size\">サポートが必要ですか ?</p>
					<!-- /wp:paragraph -->

					<!-- wp:spacer {\"height\":75} -->
					<div style=\"height:75px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer -->

					<!-- wp:columns -->
					<div class=\"wp-block-columns\"><!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/article/twenty-twenty-one/\">テーマのドキュメンテーションを読む</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column -->

					<!-- wp:column -->
					<div class=\"wp-block-column\"><!-- wp:paragraph -->
					<p><a href=\"https://wordpress.org/support/theme/twentytwentyone/\">サポートフォーラムを確認する</a></p>
					<!-- /wp:paragraph --></div>
					<!-- /wp:column --></div>
					<!-- /wp:columns -->

					<!-- wp:spacer {\"height\":20} -->
					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
					<!-- /wp:spacer --></div></div>
					<!-- /wp:cover -->","ブロックでサイトを作成","","auto-draft","closed","closed","","","","","2021-08-30 14:08:49","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=28","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("29","1","2021-08-30 14:08:49","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>あなたは自身や自身の作品を紹介したいアーティストかもしれないし、あるいは、説明するべきミッションを持つ企業かもしれません。</p>
<!-- /wp:paragraph -->","会社概要","","auto-draft","closed","closed","","","","","2021-08-30 14:08:49","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=29","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("30","1","2021-08-30 14:08:49","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>これは、住所や電話番号などの基本的な連絡先情報が記載されたページです。 問い合わせフォームを追加するプラグインを試すこともできます。</p>
<!-- /wp:paragraph -->","お問い合わせ","","auto-draft","closed","closed","","","","","2021-08-30 14:08:49","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=30","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("31","1","2021-08-30 14:08:49","0000-00-00 00:00:00","","ブログ","","auto-draft","closed","closed","","","","","2021-08-30 14:08:49","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=31","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("32","1","2021-08-30 14:08:49","0000-00-00 00:00:00","{
    \"nav_menus_created_posts\": {
        \"starter_content\": true,
        \"value\": [
            28,
            29,
            30,
            31
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30e1\\u30a4\\u30f3\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu_item[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"custom\",
            \"title\": \"\\u30db\\u30fc\\u30e0\\u30da\\u30fc\\u30b8\",
            \"url\": \"http://tmusfc.jp/\",
            \"position\": 0,
            \"nav_menu_term_id\": -1,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu_item[-2]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 29,
            \"position\": 1,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u4f1a\\u793e\\u6982\\u8981\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu_item[-3]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 31,
            \"position\": 2,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u30d6\\u30ed\\u30b0\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu_item[-4]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 30,
            \"position\": 3,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"twentytwentyone::nav_menu_locations[primary]\": {
        \"starter_content\": true,
        \"value\": -1,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u30b5\\u30d6\\u30e1\\u30cb\\u30e5\\u30fc\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu_item[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Facebook\",
            \"url\": \"https://www.facebook.com/wordpress\",
            \"position\": 0,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu_item[-6]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Twitter\",
            \"url\": \"https://twitter.com/wordpress\",
            \"position\": 1,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu_item[-7]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Instagram\",
            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",
            \"position\": 2,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"nav_menu_item[-8]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"\\u30e1\\u30fc\\u30eb\",
            \"url\": \"mailto:wordpress@example.com\",
            \"position\": 3,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"twentytwentyone::nav_menu_locations[footer]\": {
        \"starter_content\": true,
        \"value\": -5,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"show_on_front\": {
        \"starter_content\": true,
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"page_on_front\": {
        \"starter_content\": true,
        \"value\": 28,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    },
    \"page_for_posts\": {
        \"starter_content\": true,
        \"value\": 31,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:08:49\"
    }
}","","","auto-draft","closed","closed","","4d0d35aa-1cba-4f47-9a9c-1f3e41d1e5d4","","","2021-08-30 14:08:49","0000-00-00 00:00:00","","0","http://tmusfc.jp/?p=32","0","customize_changeset","","0");
INSERT INTO `wp20210827044706_posts` VALUES("33","1","2021-08-30 14:11:01","2021-08-30 05:11:01","<!-- wp:shortcode -->
[contact-form-7 id=\"21\" title=\"無題\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","asa","","publish","open","open","","asa","","","2021-08-30 14:11:01","2021-08-30 05:11:01","","0","http://tmusfc.jp/?p=33","0","post","","0");
INSERT INTO `wp20210827044706_posts` VALUES("34","1","2021-08-30 14:10:34","2021-08-30 05:10:34","<!-- wp:shortcode -->
[contact-form-7 id=\"21\" title=\"無題\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","asa","","inherit","closed","closed","","33-revision-v1","","","2021-08-30 14:10:34","2021-08-30 05:10:34","","33","http://tmusfc.jp/?p=34","0","revision","","0");
INSERT INTO `wp20210827044706_posts` VALUES("35","1","2021-08-30 14:24:44","2021-08-30 05:24:44","{
    \"blogname\": {
        \"value\": \"\\u6771\\u4eac\\u90fd\\u7acb\\u5927\\u5b66 \\u5316\\u5b66\\u5b9f\\u9a13\\u30b5\\u30fc\\u30af\\u30eb TMU-SFC\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:21:57\"
    },
    \"blogdescription\": {
        \"value\": \"\\u3088\\u308a\\u591a\\u304f\\u306e\\u4eba\\u306b\\u5316\\u5b66\\u306e\\u9762\\u767d\\u3055\\u3092\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:22:38\"
    }
}","","","trash","closed","closed","","833a3ae4-9878-4c6b-bb07-9bb6d366d1ed","","","2021-08-30 14:24:44","2021-08-30 05:24:44","","0","http://tmusfc.jp/?p=35","0","customize_changeset","","0");
INSERT INTO `wp20210827044706_posts` VALUES("36","1","2021-08-30 14:29:52","2021-08-30 05:29:52","","memphis-colorful","","inherit","open","closed","","memphis-colorful","","","2021-08-30 14:29:52","2021-08-30 05:29:52","","0","http://tmusfc.jp/wp-content/uploads/2021/08/memphis-colorful.png","0","attachment","image/png","0");
INSERT INTO `wp20210827044706_posts` VALUES("37","1","2021-08-30 14:30:16","2021-08-30 05:30:16","{
    \"twentytwentyone::background_image\": {
        \"value\": \"http://tmusfc.jp/wp-content/uploads/2021/08/memphis-colorful.png\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:30:16\"
    },
    \"twentytwentyone::background_size\": {
        \"value\": \"contain\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-08-30 05:30:16\"
    }
}","","","trash","closed","closed","","6edf9547-75a3-41c0-90cc-28e8fbec6b47","","","2021-08-30 14:30:16","2021-08-30 05:30:16","","0","http://tmusfc.jp/2021/08/30/6edf9547-75a3-41c0-90cc-28e8fbec6b47/","0","customize_changeset","","0");
INSERT INTO `wp20210827044706_posts` VALUES("38","1","2021-08-30 14:57:51","0000-00-00 00:00:00","","自動下書き","","auto-draft","closed","closed","","","","","2021-08-30 14:57:51","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=38","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("39","1","2021-09-01 02:06:30","0000-00-00 00:00:00","","自動下書き","","auto-draft","closed","closed","","","","","2021-09-01 02:06:30","0000-00-00 00:00:00","","0","http://tmusfc.jp/?page_id=39","0","page","","0");
INSERT INTO `wp20210827044706_posts` VALUES("40","1","2021-09-01 05:47:56","2021-08-31 20:47:56","/* ここにCSSコードを追加

例:
.example {
    color: red;
}

CSS の知識に磨きをかけるためにご覧ください。
http://www.w3schools.com/css/css_syntax.asp

コメント終わり */ 

.name{
  color :#ff8c00;
  background-color :#00ff00;
}

.wpcf7 input[type=\"text\"]{
  font-size:20px;
  
}
input.name {
  border:none;
  border-radius:10px;
  box-shadow: none;
  padding: 2px 8px;
}

input.name:focus {
  outline: none;
}
","learning","","publish","closed","closed","","40","","","2021-09-03 01:41:54","2021-09-02 16:41:54","","0","http://tmusfc.jp/?post_type=custom-css-js&#038;p=40","0","custom-css-js","","0");
INSERT INTO `wp20210827044706_posts` VALUES("41","1","2021-09-01 05:53:47","0000-00-00 00:00:00","","自動下書き","","auto-draft","closed","closed","","","","","2021-09-01 05:53:47","0000-00-00 00:00:00","","0","http://tmusfc.jp/?post_type=custom-css-js&p=41","0","custom-css-js","","0");
INSERT INTO `wp20210827044706_posts` VALUES("42","1","2021-09-01 06:08:50","2021-08-31 21:08:50","<!-- wp:paragraph -->
<p>代表者氏名(必須) [text* your-name class:name]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>メールアドレス(必須) [email* your-email class:email \"メールアドレスを入力してください\"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>体験実験参加日（必須）<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加時間帯を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:group -->
<div class=\"wp-block-group\"><!-- wp:shortcode -->
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]
<!-- /wp:shortcode --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class=\"wp-block-group\"><!-- wp:paragraph -->
<p>質問内容 (任意) [textarea your-message class:message]</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class=\"wp-block-group\"><!-- wp:shortcode -->
[submit \"送信\"]
<!-- /wp:shortcode --></div>
<!-- /wp:group -->

<pre>&lt;label&gt; 代表者氏名(必須)<br />[text* your-name class:name] &lt;/label&gt;<br /><br /><br />&lt;label&gt; メールアドレス(必須)<br />[email* your-email class:email \"メールアドレスを入力してください\"] &lt;/label&gt;<br /><br /><br />体験実験参加日（必須）<br />[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]<br /><br />参加実験を選ぶ(必須)<br />[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]<br /><br />参加実験を選ぶ(必須)<br />[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]<br /><br />参加時間帯を選ぶ(必須)<br />[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]<br /><br />&lt;label&gt; 質問内容 (任意)<br />[textarea your-message class:message] &lt;/label&gt;<br /><br />[submit \"送信\"]</pre>

<!-- wp:paragraph -->
<p>代表者氏名(必須) [text* your-name class:name]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>メールアドレス(必須) [email* your-email class:email \"メールアドレスを入力してください\"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>体験実験参加日（必須）<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加時間帯を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>質問内容 (任意) [textarea your-message class:message]</p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[submit \"送信\"]
<!-- /wp:shortcode -->

<!-- wp:contact-form-7/contact-form-selector -->
<div class=\"wp-block-contact-form-7-contact-form-selector\">[contact-form-7 id=\"\" title=\"\"]</div>
<!-- /wp:contact-form-7/contact-form-selector -->

<!-- wp:html -->
<label> 代表者氏名(必須)
    [text* your-name class:name] </label>


<label> メールアドレス(必須)
[email* your-email class:email \"メールアドレスを入力してください\"] </label>


体験実験参加日（必須）
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]

参加実験を選ぶ(必須)
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加実験を選ぶ(必須)
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加時間帯を選ぶ(必須)
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]

<label> 質問内容 (任意)
    [textarea your-message class:message] </label>

[submit \"送信\"]
<!-- /wp:html -->","","","trash","open","open","","__trashed","","","2021-09-01 06:08:50","2021-08-31 21:08:50","","0","http://tmusfc.jp/?p=42","0","post","","0");
INSERT INTO `wp20210827044706_posts` VALUES("43","1","2021-09-01 06:08:50","2021-08-31 21:08:50","<!-- wp:paragraph -->
<p>代表者氏名(必須) [text* your-name class:name]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>メールアドレス(必須) [email* your-email class:email \"メールアドレスを入力してください\"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>体験実験参加日（必須）<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加時間帯を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:group -->
<div class=\"wp-block-group\"><!-- wp:shortcode -->
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]
<!-- /wp:shortcode --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class=\"wp-block-group\"><!-- wp:paragraph -->
<p>質問内容 (任意) [textarea your-message class:message]</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class=\"wp-block-group\"><!-- wp:shortcode -->
[submit \"送信\"]
<!-- /wp:shortcode --></div>
<!-- /wp:group -->

<pre>&lt;label&gt; 代表者氏名(必須)<br />[text* your-name class:name] &lt;/label&gt;<br /><br /><br />&lt;label&gt; メールアドレス(必須)<br />[email* your-email class:email \"メールアドレスを入力してください\"] &lt;/label&gt;<br /><br /><br />体験実験参加日（必須）<br />[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]<br /><br />参加実験を選ぶ(必須)<br />[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]<br /><br />参加実験を選ぶ(必須)<br />[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]<br /><br />参加時間帯を選ぶ(必須)<br />[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]<br /><br />&lt;label&gt; 質問内容 (任意)<br />[textarea your-message class:message] &lt;/label&gt;<br /><br />[submit \"送信\"]</pre>

<!-- wp:paragraph -->
<p>代表者氏名(必須) [text* your-name class:name]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>メールアドレス(必須) [email* your-email class:email \"メールアドレスを入力してください\"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>体験実験参加日（必須）<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>参加時間帯を選ぶ(必須)<br></p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p>質問内容 (任意) [textarea your-message class:message]</p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[submit \"送信\"]
<!-- /wp:shortcode -->

<!-- wp:contact-form-7/contact-form-selector -->
<div class=\"wp-block-contact-form-7-contact-form-selector\">[contact-form-7 id=\"\" title=\"\"]</div>
<!-- /wp:contact-form-7/contact-form-selector -->

<!-- wp:html -->
<label> 代表者氏名(必須)
    [text* your-name class:name] </label>


<label> メールアドレス(必須)
[email* your-email class:email \"メールアドレスを入力してください\"] </label>


体験実験参加日（必須）
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]

参加実験を選ぶ(必須)
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加実験を選ぶ(必須)
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加時間帯を選ぶ(必須)
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]

<label> 質問内容 (任意)
    [textarea your-message class:message] </label>

[submit \"送信\"]
<!-- /wp:html -->","","","inherit","closed","closed","","42-revision-v1","","","2021-09-01 06:08:50","2021-08-31 21:08:50","","42","http://tmusfc.jp/?p=43","0","revision","","0");
INSERT INTO `wp20210827044706_posts` VALUES("44","1","2021-09-01 06:09:06","0000-00-00 00:00:00","","自動下書き","","auto-draft","closed","closed","","","","","2021-09-01 06:09:06","0000-00-00 00:00:00","","0","http://tmusfc.jp/?post_type=custom-css-js&p=44","0","custom-css-js","","0");
INSERT INTO `wp20210827044706_posts` VALUES("45","1","2021-09-01 06:19:25","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>&lt;label&gt; 代表者氏名(必須)<br>[text* your-name class:name] &lt;/label&gt;</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
 <label> <font size=\"3\" color=\"#00FF00\"><b>さあさ</b></font>代表者氏名(必須)
    [text* your-name class:name] </label>


<label> メールアドレス(必須)
[email* your-email class:email \"メールアドレスを入力してください\"] </label>


体験実験参加日（必須）
[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]

参加実験を選ぶ(必須)
[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加実験を選ぶ(必須)
[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]

参加時間帯を選ぶ(必須)
[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]

<label> 質問内容 (任意)
    [textarea your-message class:message] </label>

[submit \"送信\"]
<!-- /wp:html -->

<!-- wp:paragraph -->
<p><br>&lt;label&gt; メールアドレス(必須)<br>[email* your-email class:email \"メールアドレスを入力してください\"] &lt;/label&gt;</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><br>体験実験参加日（必須）<br>[checkbox* your-date class:date use_label_element \"2021-11-01\" \"2021-11-02\" \"2021-11-03\"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br>[radio your-experiment1 class:experiment1 label_first default:2 \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>参加実験を選ぶ(必須)<br>[checkbox* your-experiment2 class:experiment2 exclusive \"ゴムづくり\" \"線香花火\" \"あぶり出しお絵かき\"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>参加時間帯を選ぶ(必須)<br>[select* your-time class:time include_blank \"10:30~11:00\" \"11:30~12:00\" \"12:30~13:00\" \"13:30~14:00\"]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>&lt;label&gt; 質問内容 (任意)<br>[textarea your-message class:message] &lt;/label&gt;</p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[submit \"送信\"]
<!-- /wp:shortcode -->","","","draft","open","open","","","","","2021-09-01 06:19:25","2021-08-31 21:19:25","","0","http://tmusfc.jp/?p=45","0","post","","0");
INSERT INTO `wp20210827044706_posts` VALUES("46","1","2021-09-03 02:08:45","2021-09-02 17:08:45","","TMU-SFC メンバー","","inherit","open","closed","","olympus-digital-camera","","","2021-09-03 02:09:51","2021-09-02 17:09:51","","0","http://tmusfc.jp/wp-content/uploads/2021/09/IMG_7420.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("47","1","2021-09-03 02:47:45","2021-09-02 17:47:45","","OLYMPUS DIGITAL CAMERA","OLYMPUS DIGITAL CAMERA","inherit","open","closed","","olympus-digital-camera-2","","","2021-09-03 02:47:45","2021-09-02 17:47:45","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P6223651.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("48","1","2021-09-03 02:48:00","2021-09-02 17:48:00","","ビスマス","","inherit","open","closed","","olympus-digital-camera-3","","","2021-09-03 02:48:41","2021-09-02 17:48:41","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P6223651-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("49","1","2021-09-03 02:49:47","2021-09-02 17:49:47","","OLYMPUS DIGITAL CAMERA","OLYMPUS DIGITAL CAMERA","inherit","open","closed","","olympus-digital-camera-4","","","2021-09-03 02:49:47","2021-09-02 17:49:47","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P6223702.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("50","1","2021-09-03 02:49:56","2021-09-02 17:49:56","","OLYMPUS DIGITAL CAMERA","OLYMPUS DIGITAL CAMERA","inherit","open","closed","","olympus-digital-camera-5","","","2021-09-03 02:49:56","2021-09-02 17:49:56","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P6223702-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("51","1","2021-09-03 02:50:06","2021-09-02 17:50:06","","OLYMPUS DIGITAL CAMERA","OLYMPUS DIGITAL CAMERA","inherit","open","closed","","olympus-digital-camera-6","","","2021-09-03 02:50:06","2021-09-02 17:50:06","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P6223702-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("52","1","2021-09-03 02:53:16","2021-09-02 17:53:16","","葉脈標本","","inherit","open","closed","","p6223702-2","","","2021-09-03 02:53:47","2021-09-02 17:53:47","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P6223702-2-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("53","1","2021-09-03 02:55:13","2021-09-02 17:55:13","","OLYMPUS DIGITAL CAMERA","OLYMPUS DIGITAL CAMERA","inherit","open","closed","","olympus-digital-camera-7","","","2021-09-03 02:55:13","2021-09-02 17:55:13","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P6223658.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("56","1","2021-09-03 02:56:22","2021-09-02 17:56:22","","電気でお絵かき","","inherit","open","closed","","p6223658-1","","","2021-09-03 02:56:36","2021-09-02 17:56:36","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P6223658-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp20210827044706_posts` VALUES("57","1","2021-09-03 02:57:49","2021-09-02 17:57:49","","ケミカルライト","","inherit","open","closed","","olympus-digital-camera-8","","","2021-09-03 02:58:10","2021-09-02 17:58:10","","0","http://tmusfc.jp/wp-content/uploads/2021/09/P8054173.jpg","0","attachment","image/jpeg","0");


DROP TABLE IF EXISTS `wp20210827044706_term_relationships`;

CREATE TABLE `wp20210827044706_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_term_relationships` VALUES("1","1","0");
INSERT INTO `wp20210827044706_term_relationships` VALUES("33","1","0");
INSERT INTO `wp20210827044706_term_relationships` VALUES("42","1","0");
INSERT INTO `wp20210827044706_term_relationships` VALUES("45","1","0");


DROP TABLE IF EXISTS `wp20210827044706_term_taxonomy`;

CREATE TABLE `wp20210827044706_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_term_taxonomy` VALUES("1","1","category","","0","2");
INSERT INTO `wp20210827044706_term_taxonomy` VALUES("2","2","nav_menu","","0","0");


DROP TABLE IF EXISTS `wp20210827044706_termmeta`;

CREATE TABLE `wp20210827044706_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp20210827044706_terms`;

CREATE TABLE `wp20210827044706_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_terms` VALUES("1","未分類","uncategorized","0");
INSERT INTO `wp20210827044706_terms` VALUES("2","メイン","%e3%83%a1%e3%82%a4%e3%83%b3","0");


DROP TABLE IF EXISTS `wp20210827044706_usermeta`;

CREATE TABLE `wp20210827044706_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_usermeta` VALUES("1","1","nickname","tmu-sfc");
INSERT INTO `wp20210827044706_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp20210827044706_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp20210827044706_usermeta` VALUES("4","1","description","");
INSERT INTO `wp20210827044706_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp20210827044706_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp20210827044706_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp20210827044706_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp20210827044706_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp20210827044706_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp20210827044706_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp20210827044706_usermeta` VALUES("12","1","wp20210827044706_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp20210827044706_usermeta` VALUES("13","1","wp20210827044706_user_level","10");
INSERT INTO `wp20210827044706_usermeta` VALUES("14","1","dismissed_wp_pointers","theme_editor_notice");
INSERT INTO `wp20210827044706_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp20210827044706_usermeta` VALUES("16","1","session_tokens","a:4:{s:64:\"0af94207cda411a518019fd75708f5889a252b3b45db5f08d640aab774174018\";a:4:{s:10:\"expiration\";i:1630638838;s:2:\"ip\";s:13:\"133.202.123.1\";s:2:\"ua\";s:137:\"Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Mobile/15E148 Safari/604.1\";s:5:\"login\";i:1630466038;}s:64:\"06d48e990c5683cb275ee4f1e71c587b35c1750acf9f743684fccdae10914155\";a:4:{s:10:\"expiration\";i:1631675742;s:2:\"ip\";s:13:\"133.202.123.1\";s:2:\"ua\";s:124:\"Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 wp-iphone/18.0\";s:5:\"login\";i:1630466142;}s:64:\"9024018d65b3ce94b7d5866089f2eec75ce2892ecb5fab6c9595d828b20eea48\";a:4:{s:10:\"expiration\";i:1630658319;s:2:\"ip\";s:13:\"133.202.123.1\";s:2:\"ua\";s:137:\"Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Mobile/15E148 Safari/604.1\";s:5:\"login\";i:1630485519;}s:64:\"f8a24adbe1e9481b7cacc6c2e0833a01daf821986a4985aafd1f3f28836aae86\";a:4:{s:10:\"expiration\";i:1631810470;s:2:\"ip\";s:13:\"27.92.236.205\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36\";s:5:\"login\";i:1630600870;}}");
INSERT INTO `wp20210827044706_usermeta` VALUES("17","1","wp20210827044706_dashboard_quick_press_last_post_id","4");
INSERT INTO `wp20210827044706_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:11:\"27.92.236.0\";}");
INSERT INTO `wp20210827044706_usermeta` VALUES("19","1","wp20210827044706_user-settings","libraryContent=browse&hidetb=1&editor_plain_text_paste_warning=2");
INSERT INTO `wp20210827044706_usermeta` VALUES("20","1","wp20210827044706_user-settings-time","1630602777");
INSERT INTO `wp20210827044706_usermeta` VALUES("21","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wp20210827044706_usermeta` VALUES("22","1","metaboxhidden_nav-menus","a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}");
INSERT INTO `wp20210827044706_usermeta` VALUES("23","1","nav_menu_recently_edited","2");
INSERT INTO `wp20210827044706_usermeta` VALUES("24","1","closedpostboxes_custom-css-js","a:1:{i:0;s:10:\"previewdiv\";}");
INSERT INTO `wp20210827044706_usermeta` VALUES("25","1","metaboxhidden_custom-css-js","a:0:{}");


DROP TABLE IF EXISTS `wp20210827044706_users`;

CREATE TABLE `wp20210827044706_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp20210827044706_users` VALUES("1","tmu-sfc","$P$BFlbPz98gE/KAKAJeYYYGcksWVNbAO.","tmu-sfc","tmusfc@gmail.com","http://tmusfc.jp","2021-08-26 20:14:11","","0","tmu-sfc");


